from __future__ import annotations

import tarfile

import pytest

from cases.e1_rouaix_hpc_restart.run_restart import (
    DT_S,
    END_TIME_S,
    PARENT_TIME_S,
    RestartConfig,
    RestartError,
    RestartOutputMonitor,
    build_terminal_status,
    rewrite_control_dict,
    select_seed_members,
)


def test_restart_config_is_exact_ten_step_smoke() -> None:
    assert RestartConfig().validate().end_time_s == 0.201
    with pytest.raises(RestartError, match="exactly 0.2 -> 0.201"):
        RestartConfig(end_time_s=0.202).validate()


def test_control_dict_changes_only_restart_window(tmp_path) -> None:
    path = tmp_path / "controlDict"
    path.write_text(
        "application interIsoFoam;\n"
        "startFrom startTime;\nstartTime 0;\nstopAt endTime;\nendTime 0.2;\n"
        "deltaT 0.0001;\nadjustTimeStep no;\nwriteControl runTime;\nwriteInterval 0.2;\n"
        "div(rhoPhi,U) Gauss linearUpwind grad(U);\n",
        encoding="utf-8",
    )

    hashes = rewrite_control_dict(path, RestartConfig())
    updated = path.read_text(encoding="utf-8")

    assert "startFrom latestTime;" in updated
    assert "startTime 0.2;" in updated
    assert "endTime 0.201;" in updated
    assert "writeInterval 0.001;" in updated
    assert "deltaT 0.0001;" in updated
    assert "div(rhoPhi,U) Gauss linearUpwind grad(U);" in updated
    assert hashes["before_sha256"] != hashes["after_sha256"]


def test_restart_monitor_counts_absolute_times_after_checkpoint() -> None:
    tracker = RestartOutputMonitor(
        last_progress_monotonic=0.0, horizon_s=END_TIME_S, delta_t_s=DT_S
    )
    now = 1.0
    tracker.feed("Time = 0.2", now)
    tracker.feed("min / max (mag(U)) = 0 100", now)
    for step in range(1, 11):
        now += 1.0
        current = PARENT_TIME_S + step * DT_S
        tracker.feed(f"Time = {current:.4f}", now)
        tracker.feed("min / max (mag(U)) = 0 101", now)
    tracker.feed("End", now)
    tracker.finish()

    assert len(tracker.rows) == 10
    assert tracker.rows[0][0] == pytest.approx(0.2001)
    assert tracker.rows[-1][0] == pytest.approx(0.201)
    assert tracker.completion_fault() is None


def test_terminal_receipt_requires_verified_u_guard_stop() -> None:
    partial = build_terminal_status(
        return_code=0,
        end_marker=True,
        actual_time_s=0.2001,
        step_count=1,
        stop_detail="operational stop: max|U|=1000.2 m/s exceeds 1000 m/s",
        pause_observed=False,
        stop_signals=["12"],
        endpoint_verified=True,
    )
    assert partial["state"] == "guarded_partial"
    assert partial["stop_reason"] == "max_abs_U_exceeded_1000.0_m_s"
    assert partial["write_and_stop_requested"] is True
    assert partial["write_and_stop_acknowledged"] is True

    unacknowledged = build_terminal_status(
        return_code=1,
        end_marker=False,
        actual_time_s=0.2001,
        step_count=1,
        stop_detail="operational stop: max|U|=1000.2 m/s exceeds 1000 m/s",
        pause_observed=False,
        stop_signals=[],
        endpoint_verified=False,
    )
    assert unacknowledged["state"] == "incomplete"
    assert unacknowledged["write_and_stop_acknowledged"] is False


def test_seed_selection_requires_checkpoint_and_rejects_links() -> None:
    required = {
        "attempt/manifest.json",
        "attempt/ledger/summary.json",
        "attempt/case/case-inputs.json",
        *(
            f"attempt/case/system/{name}"
            for name in ("controlDict", "decomposeParDict", "fvSchemes", "fvSolution")
        ),
        *(
            f"attempt/case/constant/polyMesh/{name}"
            for name in ("points", "faces", "owner", "neighbour", "boundary")
        ),
        *(
            f"attempt/case/processors120/constant/polyMesh/{name}"
            for name in ("points", "faces", "owner", "neighbour", "boundary")
        ),
        *(
            f"attempt/case/processors120/0.200000000000/{name}"
            for name in (
                "U",
                "alpha.water",
                "epsilon",
                "k",
                "nut",
                "p",
                "p_rgh",
                "phi",
                "uniform/cumulativeContErr",
                "uniform/functionObjects/functionObjectProperties",
                "uniform/time",
            )
        ),
    }
    members = []
    for name in sorted(required):
        info = tarfile.TarInfo(name)
        info.size = 0
        members.append(info)
    assert len(select_seed_members(members)) == len(members)

    link = tarfile.TarInfo("attempt/case/processors120/0.200000000000/foreign")
    link.type = tarfile.SYMTYPE
    with pytest.raises(RestartError, match="link or special file"):
        select_seed_members([*members, link])
