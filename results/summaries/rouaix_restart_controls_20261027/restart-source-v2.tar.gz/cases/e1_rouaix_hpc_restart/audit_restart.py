#!/usr/bin/env python3
"""Audit one native Rouaix continuation interval from its measured checkpoint."""

from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path
from typing import Any

from scripts.continue_rouaix_case import (
    RHO_WATER_KG_M3,
    _right_endpoint_step_integral,
)

PARENT_LEDGER_SHA256 = "0baa380005d188edf6c94a0c175b790a5a8af5fa79773ff37ace5da5dda2f300"
PARENT_ARCHIVE_SHA256 = "31010755e705010771de7ed00fb5fb9990e7d2621237c3d881ee22b826cf25c9"
PARENT_ENDPOINT_MEMBER = "attempt/case/processors120/0.200000000000/alpha.water"
PATCHES = (
    "gasInlet",
    "downstreamOutlet",
    "bottomOutlet",
    "aircraftWall",
    "spanwiseMinus",
    "spanwisePlus",
    "nozzle",
)
TIME_TOL_S = 1e-10
DT_TOL_S = 1e-9
INVENTORY_TOL_M3 = 1e-10


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _read_json(path: Path) -> tuple[dict[str, Any], bytes]:
    raw = path.read_bytes()
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object in {path}")
    return value, raw


def _parent_summary(source: Path | str | dict[str, Any]) -> tuple[dict[str, Any], str, str]:
    if isinstance(source, (Path, str)):
        path = Path(source)
        summary, raw = _read_json(path)
        declared_sha256 = _sha256(raw)
    elif isinstance(source, dict):
        try:
            path = Path(source["source_path"])
            declared_sha256 = str(source["source_sha256"])
        except (KeyError, TypeError) as exc:
            raise ValueError("parent ledger dict requires source_path and source_sha256") from exc
        summary, raw = _read_json(path)
        if "summary" in source and source["summary"] != summary:
            raise ValueError("provided parent summary differs from its hash-bound source file")
        if _sha256(raw) != declared_sha256:
            raise ValueError("parent ledger dict source_sha256 does not match its source file")
    else:
        raise TypeError("parent_ledger must be a Path or a hash-bound source dict")
    if declared_sha256 != PARENT_LEDGER_SHA256:
        raise ValueError("parent ledger summary SHA-256 does not match the qualified .2 ledger")
    return summary, declared_sha256, str(path)


def _series_file(run_dir: Path, object_names: tuple[str, ...], filename: str) -> tuple[Path, str]:
    found: list[tuple[Path, str]] = []
    for object_name in object_names:
        files = sorted((run_dir / "postProcessing" / object_name).glob(f"**/{filename}"))
        found.extend((path, object_name) for path in files)
    if len(found) != 1:
        raise ValueError(f"expected exactly one {filename} for {object_names}, found {len(found)}")
    return found[0]


def _read_native_series(
    path: Path, *, required_field: str
) -> tuple[list[tuple[float, float]], str, str]:
    """Read a native function-object table and select its named output column."""
    raw = path.read_bytes()
    header: list[str] | None = None
    data: list[tuple[float, float]] = []
    field_index: int | None = None
    for line_number, raw_line in enumerate(raw.splitlines(), start=1):
        try:
            line = raw_line.decode("ascii").strip()
        except UnicodeDecodeError as exc:
            raise ValueError(f"non-ASCII row {line_number} in {path}") from exc
        if not line:
            continue
        if line.startswith("#"):
            candidate = line[1:].strip().split()
            if candidate and candidate[0].casefold() in {"time", "t"}:
                if header is not None:
                    raise ValueError(f"duplicate time header in {path}")
                header = candidate
                matches = [i for i, name in enumerate(header) if required_field in name]
                if len(matches) != 1:
                    raise ValueError(
                        f"expected one `{required_field}` column in {path}, found {len(matches)}"
                    )
                field_index = matches[0]
            continue
        if header is None or field_index is None:
            raise ValueError(f"missing named native time header in {path}")
        fields = line.split()
        if len(fields) != len(header):
            raise ValueError(f"incomplete native row {line_number} in {path}")
        try:
            values = [float(value) for value in fields]
        except ValueError as exc:
            raise ValueError(f"non-numeric native row {line_number} in {path}") from exc
        if not all(math.isfinite(value) for value in values):
            raise ValueError(f"non-finite native row {line_number} in {path}")
        instant = values[0]
        if data and instant <= data[-1][0]:
            raise ValueError(f"native times are not strictly increasing in {path}")
        data.append((instant, values[field_index]))
    if not data:
        raise ValueError(f"no complete native samples in {path}")
    return data, _sha256(raw), " ".join(header or [])


def _validate_parent(
    run_dir: Path,
    parent: dict[str, Any],
    parent_sha256: str,
    parent_path: str,
    start_time_s: float,
) -> tuple[dict[str, Any], str]:
    integration = parent.get("integration", {})
    coverage = parent.get("coverage", {})
    parent_end = float(coverage.get("last_matched_printed_time_s", math.nan))
    parent_inventory = float(integration.get("final_inventory_m3", math.nan))
    density = float(integration.get("density_kg_m3", math.nan))
    if (
        coverage.get("configured_horizon_reached") is not True
        or coverage.get("requested_end_reached") is not True
    ):
        raise ValueError("parent ledger does not certify complete coverage through its endpoint")
    if not math.isclose(parent_end, 0.2, rel_tol=0.0, abs_tol=TIME_TOL_S):
        raise ValueError("hash-bound parent ledger does not end at checkpoint t=0.2 s")
    if not math.isclose(start_time_s, parent_end, rel_tol=0.0, abs_tol=TIME_TOL_S):
        raise ValueError("restart start time differs from the audited parent checkpoint")
    if not math.isfinite(parent_inventory) or parent_inventory < 0:
        raise ValueError("parent ledger has no finite non-negative final inventory")
    if density != RHO_WATER_KG_M3:
        raise ValueError("parent ledger water density differs from 997.6 kg/m3")

    receipt_path = run_dir / "parent-checkpoint-receipt.json"
    receipt, raw = _read_json(receipt_path)
    expected = {
        "archive_sha256": PARENT_ARCHIVE_SHA256,
        "checkpoint_time_s": 0.2,
        "archive_status": "verified_crc_hash_and_member_list",
        "selected_endpoint_member": PARENT_ENDPOINT_MEMBER,
    }
    for key, value in expected.items():
        actual = receipt.get(key)
        if key == "checkpoint_time_s":
            if not math.isclose(float(actual), value, rel_tol=0.0, abs_tol=TIME_TOL_S):
                raise ValueError("parent checkpoint receipt time is not exactly 0.2 s")
        elif actual != value:
            raise ValueError(f"parent checkpoint receipt {key} does not match verified evidence")
    receipt_inventory = float(receipt.get("inventory_m3", math.nan))
    if not math.isclose(receipt_inventory, parent_inventory, rel_tol=0.0, abs_tol=INVENTORY_TOL_M3):
        raise ValueError("parent receipt inventory differs from hash-bound parent ledger")
    receipt_binding = {
        "path": str(receipt_path),
        "sha256": _sha256(raw),
        "archive_sha256": receipt["archive_sha256"],
        "checkpoint_time_s": float(receipt["checkpoint_time_s"]),
        "inventory_m3": receipt_inventory,
        "archive_status": receipt["archive_status"],
        "selected_endpoint_member": receipt["selected_endpoint_member"],
    }
    parent_binding = {
        "summary_path": parent_path,
        "summary_sha256": parent_sha256,
        "checkpoint_time_s": parent_end,
        "initial_inventory_m3": parent_inventory,
        "initial_inventory_kg": parent_inventory * density,
        "density_kg_m3": density,
        "prior_injected_kg_context_only": integration.get("injected_kg"),
        "prior_escape_kg_context_only": integration.get("signed_net_escape_kg"),
        "prior_residual_kg_context_only": integration.get("closure_residual_kg"),
        "cumulative_offsets_recounted": False,
    }
    return {"parent": parent_binding, "receipt": receipt_binding}, _sha256(raw)


def _validate_terminal(
    run_dir: Path, start_time_s: float, target_time_s: float, delta_t_s: float
) -> dict[str, Any]:
    path = run_dir / "terminal-status.json"
    terminal, raw = _read_json(path)
    exact = {
        "solver_end_marker": True,
        "solver_exit_code": 0,
        "pause_observed": False,
    }
    for key, expected in exact.items():
        if terminal.get(key) != expected:
            raise ValueError(f"terminal-status.json {key} is not {expected!r}")
    for key, expected in (
        ("target_time_s", target_time_s),
        ("requested_start_time_s", start_time_s),
    ):
        if key not in terminal or not math.isclose(
            float(terminal[key]), expected, rel_tol=0.0, abs_tol=TIME_TOL_S
        ):
            raise ValueError(f"terminal-status.json {key} does not match the requested interval")
    actual_time_s = float(terminal.get("solver_time_s", math.nan))
    if (
        not math.isfinite(actual_time_s)
        or actual_time_s <= start_time_s
        or actual_time_s > target_time_s + TIME_TOL_S
    ):
        raise ValueError(
            "terminal-status.json actual solver time is outside the requested interval"
        )
    steps_float = (actual_time_s - start_time_s) / delta_t_s
    actual_steps = round(steps_float)
    if actual_steps < 1 or not math.isclose(
        steps_float, actual_steps, rel_tol=0.0, abs_tol=DT_TOL_S
    ):
        raise ValueError("terminal solver time is not an exact fixed-deltaT endpoint")
    if terminal.get("solver_time_steps_recorded") != actual_steps:
        raise ValueError(
            "terminal-status.json solver_time_steps_recorded differs from actual endpoint"
        )
    target_reached = abs(actual_time_s - target_time_s) <= TIME_TOL_S
    stop_reason = terminal.get("stop_reason")
    if target_reached:
        if terminal.get("state") != "terminal" or stop_reason is not None:
            raise ValueError("target terminal endpoint has a non-natural stop reason")
    elif (
        terminal.get("state") != "guarded_partial"
        or stop_reason != "max_abs_U_exceeded_1000.0_m_s"
        or terminal.get("write_and_stop_requested") is not True
        or terminal.get("write_and_stop_acknowledged") is not True
    ):
        raise ValueError("partial target requires the runner's acknowledged U-guard receipt")
    terminal["requested_target_reached"] = target_reached
    terminal["actual_step_count"] = actual_steps
    return {"path": str(path), "sha256": _sha256(raw), **terminal}


def audit_restart(
    run_dir: Path,
    parent_ledger: Path | str | dict[str, Any],
    start_time_s: float,
    end_time_s: float,
    delta_t_s: float,
) -> dict[str, Any]:
    """Audit only the continuation interval, seeded by the parent's measured inventory."""
    run_dir = Path(run_dir)
    values = (start_time_s, end_time_s, delta_t_s)
    if not all(math.isfinite(float(value)) for value in values):
        raise ValueError("restart interval values must be finite")
    start_time_s, end_time_s, delta_t_s = map(float, values)
    if start_time_s < 0 or end_time_s <= start_time_s or delta_t_s <= 0:
        raise ValueError("restart interval must have start < end and positive deltaT")
    target_steps_float = (end_time_s - start_time_s) / delta_t_s
    target_steps = round(target_steps_float)
    if target_steps < 1 or not math.isclose(
        target_steps_float, target_steps, rel_tol=0.0, abs_tol=DT_TOL_S
    ):
        raise ValueError("requested restart interval is not an integer number of fixed steps")

    parent, parent_sha, parent_path = _parent_summary(parent_ledger)
    parent_binding, _ = _validate_parent(run_dir, parent, parent_sha, parent_path, start_time_s)
    terminal = _validate_terminal(run_dir, start_time_s, end_time_s, delta_t_s)
    actual_end_time_s = float(terminal["solver_time_s"])
    actual_steps = int(terminal["actual_step_count"])

    inventory_path, inventory_name = _series_file(
        run_dir, ("waterInventory", "waterVolume"), "volFieldValue.dat"
    )
    inventory_rows, inventory_sha, inventory_header = _read_native_series(
        inventory_path, required_field="alpha.water"
    )
    histories: dict[str, list[tuple[float, float]]] = {"inventory": inventory_rows}
    input_hashes = {
        "water_inventory": {
            "path": str(inventory_path),
            "sha256": inventory_sha,
            "header": inventory_header,
        }
    }
    flux_headers: dict[str, str] = {}
    for patch in PATCHES:
        path, object_name = _series_file(
            run_dir,
            (f"liquidFlux_{patch}", f"{patch}Flux"),
            "surfaceFieldValue.dat",
        )
        rows, digest, header = _read_native_series(path, required_field="alphaPhi_")
        histories[patch] = rows
        flux_headers[patch] = header
        input_hashes[patch] = {
            "path": str(path),
            "sha256": digest,
            "object_name": object_name,
            "header": header,
        }

    parent_inventory_m3 = float(parent["integration"]["final_inventory_m3"])
    all_times: dict[str, list[float]] = {}
    selected: dict[str, dict[float, float]] = {}
    for name, rows in histories.items():
        if any(time_s > actual_end_time_s + TIME_TOL_S for time_s, _ in rows):
            raise ValueError(f"{name} history contains samples after the terminal endpoint")
        at_checkpoint = [
            value for instant, value in rows if abs(instant - start_time_s) <= TIME_TOL_S
        ]
        if (
            name == "inventory"
            and at_checkpoint
            and not math.isclose(
                at_checkpoint[0], parent_inventory_m3, rel_tol=0.0, abs_tol=INVENTORY_TOL_M3
            )
        ):
            raise ValueError(
                "restart inventory at checkpoint disagrees with parent measured inventory"
            )
        later = [(instant, value) for instant, value in rows if instant > start_time_s + TIME_TOL_S]
        if len(later) != actual_steps:
            raise ValueError(
                f"{name} has {len(later)} post-checkpoint rows; expected {actual_steps}"
            )
        if abs(later[-1][0] - actual_end_time_s) > TIME_TOL_S:
            raise ValueError(f"{name} lacks the exact actual terminal endpoint")
        all_times[name] = [instant for instant, _ in later]
        selected[name] = dict(later)

    canonical_times = all_times["inventory"]
    for name, times in all_times.items():
        if len(times) != len(canonical_times) or any(
            abs(a - b) > TIME_TOL_S for a, b in zip(times, canonical_times, strict=True)
        ):
            raise ValueError(f"time mismatch between inventory and {name} samples")
        values_after_start = [
            value for instant, value in histories[name] if instant > start_time_s + TIME_TOL_S
        ]
        selected[name] = dict(zip(canonical_times, values_after_start, strict=True))
    intervals = [canonical_times[0] - start_time_s]
    intervals.extend(b - a for a, b in zip(canonical_times[:-1], canonical_times[1:], strict=True))
    if any(abs(interval - delta_t_s) > DT_TOL_S for interval in intervals):
        raise ValueError("post-checkpoint native samples do not align with fixed deltaT")

    # Use the same right-endpoint convention as existing continuation audits.
    import numpy as np

    per_patch_integrals = {
        patch: _right_endpoint_step_integral(
            start_time_s,
            np.asarray(canonical_times, dtype=np.float64),
            np.asarray([selected[patch][instant] for instant in canonical_times], dtype=np.float64),
            delta_t_s,
        )
        for patch in PATCHES
    }
    total_flux = [sum(selected[patch][instant] for patch in PATCHES) for instant in canonical_times]
    total_boundary_integral = _right_endpoint_step_integral(
        start_time_s,
        np.asarray(canonical_times, dtype=np.float64),
        np.asarray(total_flux, dtype=np.float64),
        delta_t_s,
    )
    density = RHO_WATER_KG_M3
    prior_inventory_m3 = parent_inventory_m3
    ledger_rows: list[dict[str, Any]] = []
    residuals_kg: list[float] = []
    cumulative_residual_kg = 0.0
    for index, instant in enumerate(canonical_times, start=1):
        inventory_m3 = selected["inventory"][instant]
        delta_inventory_m3 = inventory_m3 - prior_inventory_m3
        fluxes = {patch: selected[patch][instant] for patch in PATCHES}
        boundary_step_m3 = sum(fluxes.values()) * delta_t_s
        residual_m3 = delta_inventory_m3 + boundary_step_m3
        residual_kg = residual_m3 * density
        cumulative_residual_kg += residual_kg
        row: dict[str, Any] = {
            "step_index": index,
            "interval_start_s": f"{instant - delta_t_s:.12g}",
            "time_s": f"{instant:.12g}",
            "delta_t_s": f"{delta_t_s:.12g}",
            "water_inventory_m3": f"{inventory_m3:.12g}",
            "water_inventory_kg": f"{inventory_m3 * density:.12g}",
            "delta_inventory_m3": f"{delta_inventory_m3:.12g}",
            "delta_inventory_kg": f"{delta_inventory_m3 * density:.12g}",
        }
        row.update({f"alphaPhi_{patch}_outward_m3_s": f"{fluxes[patch]:.12g}" for patch in PATCHES})
        row.update(
            {
                f"alphaPhi_{patch}_integral_m3": f"{fluxes[patch] * delta_t_s:.12g}"
                for patch in PATCHES
            }
        )
        row.update(
            {
                "alphaPhi_all_boundaries_outward_m3_s": f"{sum(fluxes.values()):.12g}",
                "alphaPhi_all_boundaries_integral_m3": f"{boundary_step_m3:.12g}",
                "nozzle_inflow_volume_m3": f"{-fluxes['nozzle'] * delta_t_s:.12g}",
                "external_patch_outflow_volume_m3": f"{sum(fluxes[p] for p in PATCHES if p != 'nozzle') * delta_t_s:.12g}",
                "balance_residual_m3": f"{residual_m3:.12g}",
                "balance_residual_kg": f"{residual_kg:.12g}",
                "balance_residual_cumulative_kg": f"{cumulative_residual_kg:.12g}",
            }
        )
        ledger_rows.append(row)
        residuals_kg.append(residual_kg)
        prior_inventory_m3 = inventory_m3

    final_inventory_m3 = selected["inventory"][canonical_times[-1]]
    incremental_source_m3 = -per_patch_integrals["nozzle"]
    incremental_external_outflow_m3 = sum(
        per_patch_integrals[patch] for patch in PATCHES if patch != "nozzle"
    )
    incremental_residual_kg = (
        final_inventory_m3 - parent_inventory_m3 + total_boundary_integral
    ) * density
    injected_kg = incremental_source_m3 * density
    signed_net_escape_kg = incremental_external_outflow_m3 * density
    coverage_status = (
        "requested_horizon_reached_exploratory_only"
        if terminal["requested_target_reached"]
        else "u_guard_partial_exploratory_only"
    )
    audit = {
        "schema_version": 1,
        "scope": "Exploratory incremental restart interval balance only; not a validation or conservation gate.",
        "formal_validation_gate": None,
        "run_dir": str(run_dir),
        "interval": {
            "start_time_s": start_time_s,
            "requested_target_time_s": end_time_s,
            "actual_terminal_time_s": actual_end_time_s,
            "delta_t_s": delta_t_s,
            "step_count": actual_steps,
            "actual_terminal_endpoint_present": True,
            "solver_end_exit_and_no_pause_verified": True,
            "requested_target_reached": bool(terminal["requested_target_reached"]),
            "partial_u_guard_stop": not bool(terminal["requested_target_reached"]),
        },
        "parent_checkpoint": parent_binding["parent"],
        "parent_checkpoint_receipt": parent_binding["receipt"],
        "terminal_status_receipt": terminal,
        "coverage": {
            "status": coverage_status,
            "requested_target_reached": bool(terminal["requested_target_reached"]),
            "requested_end_time_s": end_time_s,
            "actual_end_time_s": actual_end_time_s,
            "coverage_fraction_of_requested_interval": (actual_end_time_s - start_time_s)
            / (end_time_s - start_time_s),
            "interpretation": "A U-guard stop is retained as an actual partial interval and is not labeled target completion.",
        },
        "integration": {
            "scope": "New restart interval only: start from the hash-bound measured parent .2 s inventory; no parent cumulative source or escape is re-added.",
            "method": "Right endpoint: each completed-step alphaPhi_ sample multiplied by the preceding fixed deltaT.",
            "density_kg_m3": density,
            "initial_inventory_kg": parent_binding["parent"]["initial_inventory_kg"],
            "initial_inventory_m3": parent_inventory_m3,
            "injected_kg": injected_kg,
            "final_inventory_m3": final_inventory_m3,
            "signed_net_escape_kg": signed_net_escape_kg,
            "max_abs_per_step_closure_residual_kg": max(map(abs, residuals_kg)),
            "max_abs_cumulative_closure_residual_kg": max(
                abs(float(row["balance_residual_cumulative_kg"])) for row in ledger_rows
            ),
            "closure_residual_kg": incremental_residual_kg,
            "known_closure_caveat": parent["integration"].get(
                "known_closure_caveat",
                "Native alpha snap/bounding may contribute to the water-inventory residual after conservative alphaPhi_ fluxes are recorded.",
            ),
        },
        "formal_validation_decision": None,
        "density_kg_m3": density,
        "flux_orientation": "Native alphaPhi_ on all seven patches is outward-positive; inward nozzle flow is negative.",
        "integration_method": "Right endpoint: each completed-step alphaPhi_ sample multiplied by the preceding fixed deltaT.",
        "incremental_only": {
            "source_inflow_volume_m3": incremental_source_m3,
            "external_patch_outflow_volume_m3": incremental_external_outflow_m3,
            "all_boundary_outward_integral_m3": total_boundary_integral,
            "stored_inventory_change_m3": final_inventory_m3 - parent_inventory_m3,
            "stored_inventory_change_kg": (final_inventory_m3 - parent_inventory_m3) * density,
            "final_inventory_m3": final_inventory_m3,
            "final_inventory_kg": final_inventory_m3 * density,
            "signed_balance_residual_m3": incremental_residual_kg / density,
            "signed_balance_residual_kg": incremental_residual_kg,
            "max_abs_per_step_residual_kg": max(map(abs, residuals_kg)),
            "sum_of_per_step_residuals_kg": sum(residuals_kg),
            "per_patch_outward_integrals_m3": per_patch_integrals,
            "parent cumulative source/escape were not added to this interval balance": True,
        },
        "input_sources": {
            "parent_ledger": {
                "path": parent_binding["parent"]["summary_path"],
                "sha256": parent_binding["parent"]["summary_sha256"],
            },
            "parent_checkpoint_receipt": {
                "path": parent_binding["receipt"]["path"],
                "sha256": parent_binding["receipt"]["sha256"],
            },
            "terminal_status_receipt": {"path": terminal["path"], "sha256": terminal["sha256"]},
            "native_histories": input_hashes,
            "audit_helper_sha256": _sha256(Path(__file__).read_bytes()),
        },
        "native_snap_and_bounding_caveat": parent["integration"].get(
            "known_closure_caveat",
            "alphaPhi_ is the conservative flux-limited sweep; later native alpha snapping or clipping can appear in the inventory residual.",
        ),
        "interpretation_limit": "Raw numerical residuals are reported without a pass threshold; this audit does not validate physical fidelity or establish a conservation gate.",
        "output_files": ["restart-ledger.csv", "restart-audit.json"],
    }

    csv_path = run_dir / "restart-ledger.csv"
    json_path = run_dir / "restart-audit.json"
    csv_tmp = csv_path.with_name(f".{csv_path.name}.tmp")
    json_tmp = json_path.with_name(f".{json_path.name}.tmp")
    with csv_tmp.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(ledger_rows[0]))
        writer.writeheader()
        writer.writerows(ledger_rows)
    json_tmp.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    csv_tmp.replace(csv_path)
    json_tmp.replace(json_path)
    return audit
