#!/usr/bin/env bash
preserve_failure() {
    rc=$?
    if ((rc != 0)); then
        mkdir -p /rescue/failure/logs 2>/dev/null || true
        printf 'exit_code=%s\n' "$rc" > /rescue/failure/exit-status.txt 2>/dev/null || true
        for item in /workspace/status.json /workspace/stages.log /workspace/READY.json /workspace/guard.json; do
            [[ -f $item ]] && cp "$item" /rescue/failure/ 2>/dev/null || true
        done
        if [[ -d /workspace/logs ]]; then
            cp -r /workspace/logs/. /rescue/failure/logs/ 2>/dev/null || true
        fi
    fi
}
trap preserve_failure EXIT
source /usr/lib/openfoam/openfoam2512/etc/bashrc
set -Eeuo pipefail
cd /workspace
umask 022
mkdir -p /workspace/logs /workspace/evidence
stage=${RUN_STAGE:?RUN_STAGE required}
status_file=/workspace/status.json
write_status() {
    local state=$1 detail=${2:-}
    printf '{"state":"%s","detail":"%s","utc":"%s"}\n' \
        "$state" "${detail//\"/\\\"}" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$status_file"
}
run_stage() {
    local label=$1
    shift
    local rc=0
    printf 'stage=%s command=' "$label" >> /workspace/stages.log
    printf '%q ' "$@" >> /workspace/stages.log
    printf '\n' >> /workspace/stages.log
    if timeout --signal=TERM --kill-after=20 600 "$@" >"/workspace/logs/$label.log" 2>&1; then
        rc=0
    else
        rc=$?
    fi
    printf 'PILOT_STAGE_EXIT stage=%s code=%s\n' "$label" "$rc" >> /workspace/stages.log
    return "$rc"
}

if [[ $stage == mesh ]]; then
    mkdir -p /workspace/case
    cp -r /input/mesh-input/. /workspace/case/
    cd /workspace/case
    mesh_ok=1
    for step in blockMesh snappyHexMesh topoSet createPatch checkMesh; do
        case $step in
            blockMesh) args=(blockMesh) ;;
            snappyHexMesh) args=(snappyHexMesh -overwrite) ;;
            topoSet) args=(topoSet -constant) ;;
            createPatch) args=(createPatch -overwrite) ;;
            checkMesh) args=(checkMesh -allTopology -allGeometry) ;;
        esac
        if ! run_stage "$step" "${args[@]}"; then
            mesh_ok=0
            break
        fi
    done
    patch_ok=1
    boundary=/workspace/case/constant/polyMesh/boundary
    for patch in nozzle gasInlet aircraftWall downstreamOutlet bottomOutlet spanwiseMinus spanwisePlus; do
        if ! grep -Eq "^[[:space:]]*$patch[[:space:]]*$" "$boundary"; then
            printf 'missing_patch=%s\n' "$patch" >> /workspace/stages.log
            patch_ok=0
        fi
    done
    if [[ $mesh_ok == 1 && $patch_ok == 1 ]] && grep -q 'Mesh OK\.' /workspace/logs/checkMesh.log; then
        qa=passed
    else
        qa=failed
    fi
    mkdir -p /workspace/evidence/mesh-input
    cp -r /workspace/case/system /workspace/evidence/mesh-input/
    cp -r /workspace/case/constant/polyMesh /workspace/evidence/polyMesh 2>/dev/null || true
    cp -r /workspace/logs /workspace/evidence/
    cp /workspace/stages.log /workspace/evidence/
    cp /input/mesh-input/mesh-input.json /workspace/evidence/
    write_status "$qa" "native mesh preparation and checkMesh completed"
    printf '{"native_mesh_qa":"%s","patch_inventory_ok":%s}\n' \
        "$qa" "$([[ $patch_ok == 1 ]] && printf true || printf false)" > /workspace/evidence/mesh-qa.json
    tar -czf /workspace/result.tar.gz -C /workspace/evidence .
    (cd /workspace && sha256sum result.tar.gz > result.tar.gz.sha256)
    cp /workspace/result.tar.gz /rescue/result.tar.gz
    cp /workspace/result.tar.gz.sha256 /rescue/result.tar.gz.sha256
    touch /workspace/DONE
elif [[ $stage == solver ]]; then
    mkdir -p /workspace/case
    cp -r /input/case/. /workspace/case/
    cd /workspace/case
    if ! sha256sum -c /input/case-files.sha256 > /workspace/input-hash-check.txt 2>&1; then
        write_status failed 'input hash verification failed'
        exit 40
    fi
    control=system/controlDict
    grep -q 'writeNowSignal 10' "$control"
    grep -q 'stopAtWriteNowSignal 12' "$control"
    grep -q 'speedExtrema' "$control"
    grep -q 'location true' "$control"
    if [[ ! -x /input/solver-supervisor.sh ]]; then
        write_status failed 'missing U guard supervisor'
        exit 41
    fi
    u_guard=$(sed -n -E 's/.*"max_abs_U_m_s": ([0-9]+([.][0-9]+)?).*/\1/p' case-inputs.json | head -1)
    hard_wall=$(sed -n -E 's/.*"hard_wall_seconds": ([0-9]+).*/\1/p' case-inputs.json | head -1)
    grace_wall=$(sed -n -E 's/.*"grace_seconds": ([0-9]+).*/\1/p' case-inputs.json | head -1)
    if [[ ! $u_guard =~ ^[0-9]+([.][0-9]+)?$ ]]; then
        write_status failed 'U guard threshold is missing or invalid in case inputs'
        exit 42
    fi
    if [[ ! $hard_wall =~ ^[0-9]+$ || ! $grace_wall =~ ^[0-9]+$ ]]; then
        write_status failed 'wall deadline or grace is missing or invalid in case inputs'
        exit 46
    fi
    printf '{"ready":true,"stage":"solver","case_id":"%s","hashes_verified":true,"u_guard_m_s":%s,"write_and_stop_signal":12,"hard_wall_s":%s,"grace_s":%s}\n' \
        "$(sed -n 's/.*"case_id": "\([^"]*\)".*/\1/p' case-inputs.json | head -1)" "$u_guard" "$hard_wall" "$grace_wall" > /workspace/READY.json
    for _ in $(seq 1 600); do
        [[ -f /workspace/GO ]] && break
        sleep 0.2
    done
    if [[ ! -f /workspace/GO || ! -f /workspace/pre-go-manifest.json ]]; then
        write_status failed 'GO or pre-GO manifest missing before bounded wait expired'
        exit 43
    fi
    write_status started 'pre-GO inputs and signal guard verified'
    run_started_epoch=$(date +%s)
    if ! run_stage decomposePar decomposePar -force; then
        write_status failed 'decomposePar failed'
        exit 44
    fi
    set +e
    /input/solver-supervisor.sh /workspace/case /workspace/logs/interIsoFoam.log /workspace/guard.json /workspace/status.json "$run_started_epoch" "$u_guard" "$hard_wall" "$grace_wall"
    solver_rc=$?
    set -e
    mkdir -p /workspace/evidence/case
    cp case-inputs.json /workspace/evidence/case/
    cp system/controlDict system/fvSchemes system/fvSolution system/decomposeParDict /workspace/evidence/case/
    cp -r /workspace/case/postProcessing /workspace/evidence/case/ 2>/dev/null || true
    mkdir -p /workspace/evidence/case/times
    mapfile -t field_write_times < <(
        sed -n '/"field_write_times_s": \[/,/\]/p' case-inputs.json \
            | sed -nE 's/^[[:space:]]*([0-9]+([.][0-9]+)?),?[[:space:]]*$/\1/p' \
            | sort -u
    )
    terminal_time=$(sed -n -E 's/.*"solver_time_s":"?([0-9]+([.][0-9]+)?).*/\1/p' /workspace/status.json | head -1)
    if [[ $terminal_time =~ ^[0-9]+([.][0-9]+)?$ ]]; then
        field_write_times+=("$terminal_time")
    fi
    is_declared_field_time() {
        local candidate=$1 declared
        for declared in "${field_write_times[@]}"; do
            if awk -v a="$candidate" -v b="$declared" 'BEGIN { exit !(a == b) }'; then
                return 0
            fi
        done
        return 1
    }
    for dir in /workspace/case/[0-9]*/; do
        [[ -d $dir ]] || continue
        base=${dir%/}; base=${base##*/}
        if [[ $base =~ ^[0-9]+([.][0-9]+)?$ ]] && is_declared_field_time "$base"; then
            mkdir -p "/workspace/evidence/case/times/$base"
            cp -r "$dir". "/workspace/evidence/case/times/$base/"
        fi
    done
    for proc_dir in /workspace/case/processor[0-9]* /workspace/case/processors[0-9]*; do
        [[ -d $proc_dir ]] || continue
        processor=${proc_dir##*/}
        for dir in "$proc_dir"/[0-9]*/; do
            [[ -d $dir ]] || continue
            base=${dir%/}; base=${base##*/}
            if [[ $base =~ ^[0-9]+([.][0-9]+)?$ ]] && is_declared_field_time "$base"; then
                mkdir -p "/workspace/evidence/case/times/$processor/$base"
                cp -r "$dir". "/workspace/evidence/case/times/$processor/$base/"
            fi
        done
    done
    cp /workspace/logs/interIsoFoam.log /workspace/evidence/ 2>/dev/null || true
    cp /workspace/logs/decomposePar.log /workspace/evidence/ 2>/dev/null || true
    cp /workspace/guard.json /workspace/evidence/ 2>/dev/null || true
    cp /workspace/status.json /workspace/evidence/ 2>/dev/null || true
    cp /workspace/input-hash-check.txt /workspace/evidence/ 2>/dev/null || true
    printf '{"solver_exit_code":%s,"end_marker":%s}\n' \
        "$solver_rc" "$(grep -q '^End$' /workspace/logs/interIsoFoam.log && printf true || printf false)" \
        > /workspace/evidence/terminal.json
    cp /workspace/pre-go-manifest.json /workspace/evidence/ 2>/dev/null || true
    tar -czf /workspace/result.tar.gz -C /workspace/evidence .
    (cd /workspace && sha256sum result.tar.gz > result.tar.gz.sha256)
    cp /workspace/result.tar.gz /rescue/result.tar.gz
    cp /workspace/result.tar.gz.sha256 /rescue/result.tar.gz.sha256
    touch /workspace/DONE
else
    write_status failed "unknown stage $stage"
    exit 45
fi

# Keep tmpfs alive only long enough for the workstation to retrieve the archive.
for _ in $(seq 1 180); do
    [[ -f /workspace/STREAMED ]] && exit 0
    sleep 1
done
exit 0
