#!/usr/bin/env python3
"""Finite queue: 8-rank timing pilot, measured forecast gate, then matched 0.30 s air pair."""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import math
import os
import re
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[4]
QUEUE_ID = "q20261027"
WAIT_BUDGET_S = 6 * 60 * 60
POLL_S = 30
CPU_THRESHOLD = 11.0
REQUIRED_LOW_SAMPLES = 2
REMOTE_SAMPLE_SECONDS = 5
PROJECT_PAUSE = ROOT / "PAUSE"
GOBLIN_REPO = "/home/v/proj/bene/fire-track2"
HPC_PROJECT = "/project/nk_meshapplied/bene/fire-track2-hpc"
GOBLIN_SSH = [
    "ssh",
    "-oBatchMode=yes",
    "-oConnectTimeout=8",
    "-oServerAliveInterval=3",
    "-oServerAliveCountMax=1",
    "goblin",
]
HPC_SSH = [
    "ssh",
    "-S",
    "/tmp/fire-track2-komondor-%C",
    "-oBatchMode=yes",
    "-oConnectTimeout=8",
    "-oServerAliveInterval=3",
    "-oServerAliveCountMax=1",
    "nk_memj@komondor.hpc.kifu.hu",
]
VENV_PY = ROOT / ".venv/bin/python"
RUN_LOCAL = ROOT / "scripts/run_local.py"
RUNNER = RUN / "run_remote.py"
STATE_PATH = RUN / "dispatcher-state.json"
EVENT_PATH = RUN / "dispatcher-events.jsonl"
LOCK_PATH = RUN / "dispatcher.lock"
FORECAST_PATH = RUN / "pilot-030-forecast.json"

REMOTE_SAMPLE = rf"""set -euo pipefail
if [[ -e {GOBLIN_REPO}/PAUSE ]]; then echo PAUSED_GOBLIN; exit 0; fi
read_cpu() {{ awk '$1=="cpu" {{ total=0; for(i=2;i<=9;i++) total+=$i; idle=$5+$6; printf "%.0f %.0f\n",total,total-idle }}' /proc/stat; }}
read -r total0 busy0 < <(read_cpu)
sleep {REMOTE_SAMPLE_SECONDS}
read -r total1 busy1 < <(read_cpu)
cpus=$(nproc)
dt=$((total1-total0)); db=$((busy1-busy0))
awk -v dt="$dt" -v db="$db" -v n="$cpus" 'BEGIN {{ if(dt<=0 || db<0) exit 2; printf "BUSY_CPU_EQUIVALENTS=%.3f\n", db/dt*n }}'
"""
HPC_PAUSE_CHECK = rf"""set -euo pipefail
if [[ -e {HPC_PROJECT}/PAUSE ]]; then echo PAUSED_HPC; else echo CLEAR_HPC; fi
"""


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def append_event(event: str, **fields: Any) -> None:
    record = {"utc": utc_now(), "event": event, **fields}
    with EVENT_PATH.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, sort_keys=True) + "\n")
    print(json.dumps(record, sort_keys=True), flush=True)


def write_state(state: str, **fields: Any) -> None:
    record = {
        "schema_version": 1,
        "queue_id": QUEUE_ID,
        "pid": os.getpid(),
        "state": state,
        "updated_utc": utc_now(),
        "wait_budget_s": WAIT_BUDGET_S,
        **fields,
    }
    tmp = STATE_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(tmp, STATE_PATH)


def load_gate(cpu_equivalents: float | None, pause_state: str, check_ok: bool = True) -> str:
    """Pure gate used by the dispatcher and its no-compute negative-case check."""
    if not check_ok or pause_state in {"paused", "unknown"} or cpu_equivalents is None:
        return "defer"
    return "ready" if cpu_equivalents <= CPU_THRESHOLD else "defer"


def remote_output(command: list[str], script: str, timeout: int = 20) -> tuple[int, str, str]:
    try:
        result = subprocess.run(
            command + ["bash", "-s"],
            input=script,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        return 255, "", f"{type(error).__name__}: {error}"
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def sample_gate() -> dict[str, Any]:
    if PROJECT_PAUSE.exists():
        return {
            "state": "paused",
            "reason": f"local sentinel {PROJECT_PAUSE}",
            "busy_cpu_equivalents": None,
        }
    rc, goblin_out, goblin_err = remote_output(GOBLIN_SSH, REMOTE_SAMPLE, timeout=20)
    if rc != 0:
        return {
            "state": "unknown",
            "reason": "Goblin CPU/PAUSE check failed",
            "detail": goblin_err[-500:],
            "busy_cpu_equivalents": None,
        }
    if goblin_out == "PAUSED_GOBLIN":
        return {
            "state": "paused",
            "reason": f"Goblin sentinel {GOBLIN_REPO}/PAUSE",
            "busy_cpu_equivalents": None,
        }
    match = re.search(r"BUSY_CPU_EQUIVALENTS=([0-9]+(?:\.[0-9]+)?)", goblin_out)
    if not match:
        return {
            "state": "unknown",
            "reason": "Goblin CPU sample malformed",
            "detail": goblin_out[-500:],
            "busy_cpu_equivalents": None,
        }
    busy = float(match.group(1))
    rc, hpc_out, hpc_err = remote_output(HPC_SSH, HPC_PAUSE_CHECK, timeout=20)
    if rc != 0:
        return {
            "state": "unknown",
            "reason": "Komondor PAUSE check unavailable",
            "detail": hpc_err[-500:],
            "busy_cpu_equivalents": busy,
        }
    if hpc_out == "PAUSED_HPC":
        return {
            "state": "paused",
            "reason": f"Komondor sentinel {HPC_PROJECT}/PAUSE",
            "busy_cpu_equivalents": busy,
        }
    if hpc_out != "CLEAR_HPC":
        return {
            "state": "unknown",
            "reason": "Komondor PAUSE check malformed",
            "detail": hpc_out[-500:],
            "busy_cpu_equivalents": busy,
        }
    return {
        "state": "ready" if busy <= CPU_THRESHOLD else "busy",
        "reason": "all pause checks clear; system-wide busy CPU-equivalent sample",
        "busy_cpu_equivalents": busy,
    }


def wait_for_capacity(stage: str, wait_used: float, low_samples: int) -> tuple[bool, float]:
    while wait_used < WAIT_BUDGET_S:
        start = time.monotonic()
        gate = sample_gate()
        wait_used += time.monotonic() - start
        if gate["state"] == "paused":
            write_state("paused", stage=stage, wait_used_s=round(wait_used, 2), latest_gate=gate)
            append_event("queue_paused", stage=stage, wait_used_s=round(wait_used, 2), **gate)
            return False, wait_used
        if gate["state"] == "ready":
            low_samples += 1
        else:
            low_samples = 0
        write_state(
            "waiting_for_capacity"
            if gate["state"] in {"busy", "unknown", "paused"}
            else "capacity_sampled",
            stage=stage,
            wait_used_s=round(wait_used, 2),
            consecutive_low_samples=low_samples,
            latest_gate=gate,
        )
        append_event(
            "capacity_sample",
            stage=stage,
            wait_used_s=round(wait_used, 2),
            consecutive_low_samples=low_samples,
            **gate,
        )
        if low_samples >= REQUIRED_LOW_SAMPLES:
            # Recheck immediately before GO; an unavailable check remains a defer.
            start = time.monotonic()
            final = sample_gate()
            wait_used += time.monotonic() - start
            if final["state"] == "ready":
                write_state(
                    "launching", stage=stage, wait_used_s=round(wait_used, 2), final_gate=final
                )
                append_event("capacity_gate_passed", stage=stage, final_gate=final)
                return True, wait_used
            low_samples = 0
            append_event("capacity_gate_reset", stage=stage, final_gate=final)
        remaining = WAIT_BUDGET_S - wait_used
        if remaining <= 0:
            break
        sleep_s = min(POLL_S, remaining)
        time.sleep(sleep_s)
        wait_used += sleep_s
    write_state(
        "deferred_timeout",
        stage=stage,
        wait_used_s=round(wait_used, 2),
        reason="six-hour shared wait budget exhausted",
    )
    append_event("wait_budget_exhausted", stage=stage, wait_used_s=round(wait_used, 2))
    return False, wait_used


def run_case(case_name: str, timeout_s: int, wait_used: float) -> tuple[int, dict[str, Any] | None]:
    case_log = RUN / f"{case_name}.runner.log"
    command = [
        str(VENV_PY),
        str(RUN_LOCAL),
        "--threads",
        "1",
        "--timeout",
        str(timeout_s),
        "--",
        str(VENV_PY),
        str(RUNNER),
        "solver",
        "--case",
        case_name,
        "--cpus",
        "8",
    ]
    append_event("case_start", case=case_name, command=command, wait_used_s=round(wait_used, 2))
    write_state(
        "case_running", stage=case_name, case_log=str(case_log), wait_used_s=round(wait_used, 2)
    )
    with case_log.open("w", encoding="utf-8") as stream:
        result = subprocess.run(
            command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False
        )
    run_result_path = RUN / "container-runs" / case_name / "run-result.json"
    run_result = json.loads(run_result_path.read_text()) if run_result_path.is_file() else None
    archive_ok = bool(
        run_result
        and run_result.get("released") is True
        and (RUN / "container-runs" / case_name / "archive-verification.json").is_file()
    )
    append_event(
        "case_terminal",
        case=case_name,
        wrapper_exit_code=result.returncode,
        archive_verified=archive_ok,
        terminal=run_result.get("terminal") if run_result else None,
        run_result=str(run_result_path) if run_result else None,
    )
    return result.returncode, run_result if archive_ok else None


def forecast_030(log_path: Path) -> dict[str, Any]:
    text = log_path.read_text(errors="replace")
    records = []
    current_time = None
    for line in text.splitlines():
        m = re.match(r"^Time =\s*([0-9.eE+-]+)", line)
        if m:
            current_time = float(m.group(1))
            continue
        m = re.match(r"^ExecutionTime =\s*([0-9.eE+-]+) s\s+ClockTime =\s*([0-9.eE+-]+) s", line)
        if m and current_time is not None:
            records.append((current_time, float(m.group(1)), float(m.group(2))))
            current_time = None
    unique_times = {row[0] for row in records}
    ended = bool(re.search(r"^End$", text, re.MULTILINE))
    warm = [row for row in records if 0.002 - 1e-12 <= row[0] <= 0.01 + 1e-12]
    result: dict[str, Any] = {
        "pilot_log": str(log_path.relative_to(RUN)),
        "pilot_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
        "step_record_count": len(records),
        "unique_time_count": len(unique_times),
        "end_marker": ended,
        "warm_window_start": warm[0][0] if warm else None,
        "warm_window_end": warm[-1][0] if warm else None,
        "warm_window_step_count": len(warm) - 1 if len(warm) > 1 else 0,
        "target_steps": 3000,
        "branch_hard_solver_wall_s": 1680,
        "branch_grace_s": 120,
    }
    valid = (
        len(records) == 100
        and len(unique_times) == 100
        and ended
        and len(warm) >= 2
        and warm[0][0] <= 0.002 + 1e-12
        and warm[-1][0] >= 0.01 - 1e-12
    )
    if valid:
        n = len(warm)
        xs = list(range(n))
        ys = [r[2] for r in warm]
        xb = sum(xs) / n
        yb = sum(ys) / n
        slope = sum((x - xb) * (y - yb) for x, y in zip(xs, ys)) / sum((x - xb) ** 2 for x in xs)
        exec_slope = (warm[-1][1] - warm[0][1]) / (len(warm) - 1)
        result.update(
            {
                "forecast_valid": True,
                "warm_window_clock_ols_s_per_step": slope,
                "warm_window_execution_delta_s_per_step": exec_slope,
                "projected_3000_step_clock_s": slope * 3000,
                "pair_affordable": slope * 3000 <= 1680,
                "projection_scope": "solver ClockTime only; excludes container setup and archive transfer",
            }
        )
    else:
        result.update(
            {
                "forecast_valid": False,
                "pair_affordable": False,
                "reason": "pilot must have exactly 100 unique step records and End, with complete t=0.002..0.010 warm window",
            }
        )
    FORECAST_PATH.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    return result


def branch_terminal_ok(result: dict[str, Any], *, target_time_s: float) -> bool:
    terminal = result.get("terminal") or {}
    inventory = result.get("snapshot_inventory") or {}
    if (
        result.get("pause_observed")
        or result.get("pause_stop_requested")
        or not inventory.get("passed")
        or terminal.get("solver_exit_code") != 0
        or terminal.get("end_marker") is not True
    ):
        return False
    reason = terminal.get("guard_reason")
    if reason == "horizon_end":
        try:
            return math.isclose(
                float(terminal.get("solver_time_s")), target_time_s, rel_tol=0.0, abs_tol=1e-10
            )
        except (TypeError, ValueError):
            return False
    if reason != "max_abs_U_exceeded_1000.0_m_s":
        return False
    guard = result.get("guard") or {}
    if (
        guard.get("reason") != reason
        or guard.get("end_marker") is not True
        or guard.get("solver_exit_code") != 0
    ):
        return False
    try:
        terminal_time = float(terminal["solver_time_s"])
        terminal_u = float(terminal["max_U_m_s"])
        trigger_u = float(guard["trigger_max_U_m_s"])
        return (
            math.isfinite(terminal_time)
            and terminal_time <= target_time_s + 1e-10
            and math.isfinite(terminal_u)
            and float(guard["threshold_m_s"]) == 1000.0
            and math.isfinite(trigger_u)
            and trigger_u > 1000.0
        )
    except (KeyError, TypeError, ValueError):
        return False


def _selftest() -> None:
    assert load_gate(11.0, "clear") == "ready"
    assert load_gate(11.01, "clear") == "defer"
    assert load_gate(12.0, "clear") == "defer"
    assert load_gate(None, "clear") == "defer"
    assert load_gate(0.0, "paused") == "defer"
    assert load_gate(0.0, "unknown") == "defer"
    original_run = subprocess.run
    try:

        def timeout(*args: Any, **kwargs: Any) -> Any:
            raise subprocess.TimeoutExpired(args[0], kwargs.get("timeout", 1))

        subprocess.run = timeout
        assert remote_output(["ssh"], "true", timeout=1)[0] != 0
    finally:
        subprocess.run = original_run
    assert branch_terminal_ok(
        {
            "terminal": {
                "solver_exit_code": 0,
                "end_marker": True,
                "solver_time_s": "0.300000000000",
                "guard_reason": "horizon_end",
            },
            "snapshot_inventory": {"passed": True},
        },
        target_time_s=0.3,
    )
    overrun_result = {
        "terminal": {
            "solver_exit_code": 0,
            "end_marker": True,
            "solver_time_s": "0.301000000000",
            "max_U_m_s": "1002.0",
            "guard_reason": "max_abs_U_exceeded_1000.0_m_s",
        },
        "guard": {
            "reason": "max_abs_U_exceeded_1000.0_m_s",
            "end_marker": True,
            "solver_exit_code": 0,
            "threshold_m_s": 1000.0,
            "trigger_max_U_m_s": "1.2e3",
        },
        "snapshot_inventory": {"passed": True},
    }
    assert not branch_terminal_ok(overrun_result, target_time_s=0.3)
    assert not branch_terminal_ok(
        {
            "terminal": {
                "solver_exit_code": 0,
                "end_marker": True,
                "solver_time_s": "0.120000000000",
                "guard_reason": "horizon_end",
            }
        },
        target_time_s=0.3,
    )
    assert not branch_terminal_ok(
        {
            "terminal": {
                "solver_exit_code": 0,
                "end_marker": True,
                "solver_time_s": "0.300000000000",
                "guard_reason": "hard_30_minute_wall_deadline",
            }
        },
        target_time_s=0.3,
    )
    assert not branch_terminal_ok(
        {
            "terminal": {
                "solver_exit_code": 0,
                "end_marker": False,
                "solver_time_s": "0.300000000000",
                "guard_reason": "max_abs_U_exceeded_1000.0_m_s",
            },
            "guard": {
                "reason": "max_abs_U_exceeded_1000.0_m_s",
                "end_marker": False,
                "solver_exit_code": 0,
                "threshold_m_s": 1000.0,
                "trigger_max_U_m_s": "1001.0",
            },
        },
        target_time_s=0.3,
    )
    assert branch_terminal_ok(
        {
            "terminal": {
                "solver_exit_code": 0,
                "end_marker": True,
                "solver_time_s": "0.200000000000",
                "max_U_m_s": "1002.0",
                "guard_reason": "max_abs_U_exceeded_1000.0_m_s",
            },
            "guard": {
                "reason": "max_abs_U_exceeded_1000.0_m_s",
                "end_marker": True,
                "solver_exit_code": 0,
                "threshold_m_s": 1000.0,
                "trigger_max_U_m_s": "1.2e3",
            },
            "snapshot_inventory": {"passed": True},
        },
        target_time_s=0.3,
    )
    assert not branch_terminal_ok(
        {
            "terminal": {
                "solver_exit_code": 0,
                "end_marker": True,
                "solver_time_s": "0.300000000000",
                "guard_reason": "horizon_end",
            },
            "snapshot_inventory": {"passed": True},
            "pause_observed": True,
            "pause_stop_requested": False,
        },
        target_time_s=0.3,
    )
    assert not branch_terminal_ok(
        {
            "terminal": {
                "solver_exit_code": 0,
                "end_marker": True,
                "solver_time_s": "0.300000000000",
                "guard_reason": "horizon_end",
            },
            "pause_stop_requested": True,
        },
        target_time_s=0.3,
    )
    print("QUEUE_GUARD_SELFTEST_PASSED threshold_cpu_equivalents=11.0 fail_closed=true")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selftest", action="store_true")
    parser.add_argument("--sample-gate", action="store_true")
    args = parser.parse_args()
    if args.selftest:
        _selftest()
        return 0
    if args.sample_gate:
        result = sample_gate()
        print(json.dumps({"sampled_utc": utc_now(), **result}, sort_keys=True))
        return 0 if result["state"] in {"ready", "busy"} else 2
    log_file = RUN / "dispatcher.log"
    sys.stdout = log_file.open("a", encoding="utf-8", buffering=1)
    sys.stderr = sys.stdout
    lock_fd = os.open(LOCK_PATH, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print(f"QUEUE_DUPLICATE_REFUSED pid={os.getpid()} lock={LOCK_PATH}", flush=True)
        return 73
    os.ftruncate(lock_fd, 0)
    os.write(lock_fd, f"pid={os.getpid()} queue_id={QUEUE_ID}\n".encode())
    wait_used = 0.0
    start_utc = utc_now()
    append_event(
        "queue_started",
        queue_id=QUEUE_ID,
        wait_budget_s=WAIT_BUDGET_S,
        local_pause_path=str(PROJECT_PAUSE),
        remote_pause_paths=[f"{GOBLIN_REPO}/PAUSE", f"{HPC_PROJECT}/PAUSE"],
    )
    write_state("waiting_for_capacity", stage="air-a-pilot-8rank", wait_used_s=wait_used)
    ready, wait_used = wait_for_capacity("air-a-pilot-8rank", wait_used, 0)
    if not ready:
        return 2
    rc, pilot = run_case("air-a-pilot-8rank", 2400, wait_used)
    if rc != 0 or pilot is None:
        write_state(
            "stopped_pilot_infrastructure_or_archive_failure",
            stage="air-a-pilot-8rank",
            wrapper_exit_code=rc,
            wait_used_s=round(wait_used, 2),
        )
        return 3
    terminal = pilot.get("terminal", {})
    if (
        terminal.get("solver_exit_code") != 0
        or terminal.get("end_marker") is not True
        or terminal.get("solver_time_s") != "0.010000000000"
    ):
        write_state(
            "stopped_pilot_incomplete",
            stage="air-a-pilot-8rank",
            terminal=terminal,
            wait_used_s=round(wait_used, 2),
        )
        return 4
    if (
        pilot.get("pause_observed")
        or pilot.get("pause_stop_requested")
        or not (pilot.get("snapshot_inventory") or {}).get("passed")
    ):
        write_state(
            "stopped_pilot_snapshot_or_pause_check",
            stage="air-a-pilot-8rank",
            snapshot_inventory=pilot.get("snapshot_inventory"),
            pause_observed=pilot.get("pause_observed"),
            pause_stop_requested=pilot.get("pause_stop_requested"),
            wait_used_s=round(wait_used, 2),
        )
        return 8
    pilot_log = RUN / "container-runs/air-a-pilot-8rank/evidence/interIsoFoam.log"
    forecast = forecast_030(pilot_log)
    append_event("forecast_complete", forecast=forecast)
    if not forecast.get("forecast_valid") or not forecast.get("pair_affordable"):
        write_state(
            "forecast_gate_rejected",
            stage="pair-not-started",
            forecast=forecast,
            wait_used_s=round(wait_used, 2),
        )
        return 5
    # A scientifically valid U-guard terminal still permits the matched B run; only broken telemetry or archive stops the pair.
    for case_name in ("air-original-030", "air-upwind-030"):
        ready, wait_used = wait_for_capacity(case_name, wait_used, 0)
        if not ready:
            return 2
        rc, result = run_case(case_name, 2100, wait_used)
        if rc != 0 or result is None:
            write_state(
                "stopped_infrastructure_or_archive_failure",
                stage=case_name,
                wrapper_exit_code=rc,
                wait_used_s=round(wait_used, 2),
            )
            return 6
        branch_terminal = result.get("terminal", {})
        if not branch_terminal_ok(result, target_time_s=0.3):
            write_state(
                "stopped_nonfinite_or_timeout",
                stage=case_name,
                terminal=branch_terminal,
                wait_used_s=round(wait_used, 2),
            )
            return 7
    write_state(
        "complete",
        stage="air-upwind-030",
        wait_used_s=round(wait_used, 2),
        forecast=forecast,
        started_utc=start_utc,
    )
    append_event("queue_complete", wait_used_s=round(wait_used, 2), forecast=forecast)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
