#!/usr/bin/env python3
"""Prepare the frozen 8-rank reprofile and matched 0.30 s air siblings."""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[4]
SOURCE_ROOT = RUN / "source-code"
sys.path.insert(0, str(SOURCE_ROOT))
from cases.e1_rouaix_fast_diagnostics import build_cases  # noqa: E402

OLD = ROOT / "results/runs/rouaix-fast-local-20261027/cases-and-runs/attempt-002"
MESH_SOURCE = OLD / "container-runs/mesh/evidence/polyMesh"
MESH_QA = OLD / "mesh-qa.json"
MESH_INPUT = OLD / "mesh-input/mesh-input.json"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    mesh = RUN / "native-mesh"
    shutil.copytree(MESH_SOURCE, mesh)
    qa_sha = sha(MESH_QA)
    mesh_input_sha = sha(MESH_INPUT)
    specs = (
        ("air-a-pilot-8rank", "original", 0.01),
        ("air-original-030", "original", 0.30),
        ("air-upwind-030", "upwind", 0.30),
    )
    manifest = {
        "schema_version": 1,
        "prepared_utc": __import__("datetime")
        .datetime.now(__import__("datetime").timezone.utc)
        .isoformat(),
        "source_root": "source-code",
        "field_handler": "collated",
        "mesh_qa_sha256": qa_sha,
        "mesh_input_sha256": mesh_input_sha,
        "mesh_archive_sha256": json.loads(MESH_QA.read_text())["mesh_archive_sha256"],
        "cases": {},
    }
    for name, variant, horizon in specs:
        destination = RUN / name
        meta = build_cases.write_case(destination, variant, horizon_s=horizon, ranks=8)
        mesh_hashes = build_cases.attach_mesh(destination, mesh)
        meta = json.loads((destination / "case-inputs.json").read_text())
        meta["queue_run_name"] = name
        meta["mesh_qa_sha256"] = qa_sha
        meta["mesh_input_sha256"] = mesh_input_sha
        meta["mesh_files_sha256"] = mesh_hashes
        meta["case_files_sha256"] = build_cases.tree_hashes(
            destination, exclude=("case-inputs.json",)
        )
        meta["case_files_total_bytes"] = sum(
            p.stat().st_size
            for p in destination.rglob("*")
            if p.is_file() and p.name != "case-inputs.json"
        )
        (destination / "case-inputs.json").write_text(
            json.dumps(meta, indent=2, sort_keys=True) + "\n"
        )
        entry = {
            "case_id": meta["case_id"],
            "variant": variant,
            "scheme": meta["momentum_convection"],
            "horizon_s": horizon,
            "delta_t_s": meta["delta_t_s"],
            "expected_steps": meta["expected_steps"],
            "mpi_ranks": meta["mpi_ranks"],
            "field_handler": "collated",
            "required_snapshot_fields": ["U", "alpha.water", "p_rgh"],
            "write_interval_s": meta["write_interval_s"],
            "field_write_times_s": meta["field_write_times_s"],
            "case_inputs_sha256": sha(destination / "case-inputs.json"),
            "case_files_sha256": meta["case_files_sha256"],
            "case_files_total_bytes": meta["case_files_total_bytes"],
            "mesh_files_sha256": meta["mesh_files_sha256"],
            "runtime_guard": meta["runtime_guard"],
        }
        manifest["cases"][name] = entry
    (RUN / "queue-cases-manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n"
    )
    source_hashes = {
        str(p.relative_to(SOURCE_ROOT)): sha(p)
        for p in sorted(SOURCE_ROOT.rglob("*"))
        if p.is_file() and "__pycache__" not in p.parts
    }
    revision = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, capture_output=True, check=True
    ).stdout.strip()
    active = {
        "schema_version": 1,
        "prepared_utc": manifest["prepared_utc"],
        "purpose": "bounded exploratory all-air queue; not E1 validation",
        "git_revision": revision,
        "source_snapshot_root": "source-code",
        "source_files_sha256": source_hashes,
        "mesh_input_sha256": mesh_input_sha,
        "mesh_qa_sha256": qa_sha,
        "mesh_archive_sha256": manifest["mesh_archive_sha256"],
        "mesh_cells": json.loads(MESH_QA.read_text())["native_checkMesh"]["cells"],
        "field_handler": "collated",
        "queue_cases_manifest_sha256": sha(RUN / "queue-cases-manifest.json"),
        "cases": manifest["cases"],
    }
    (RUN / "preparation-manifest.json").write_text(
        json.dumps(active, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
