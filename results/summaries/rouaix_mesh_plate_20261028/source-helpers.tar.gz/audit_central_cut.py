#!/usr/bin/env pvpython
"""Check native cell identity and coincident polygons in the z=0 mesh cut."""

from __future__ import annotations

import hashlib
import importlib
import json
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from vtk import VTK_HEXAHEDRON, VTK_POLYHEDRON, vtkCutter, vtkPlane
from vtk.util.numpy_support import numpy_to_vtkIdTypeArray, vtk_to_numpy

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "results/runs/rouaix-mesh-plate-20261028"
SUMMARY = ROOT / "results/summaries/rouaix_mesh_plate_20261028"
GEOMETRY = ROOT / "results/runs/rouaix-fine-water-view-20261028/staging/native-cell-centres-volumes.npz"
GEOMETRY_RECEIPT = ROOT / "results/runs/rouaix-fine-water-view-20261028/staging/native-cell-centres-volumes.json"
EXPECTED_CELLS = 10_099_265
REGIONS = {
    "fine_nozzle": {"x": [-0.4, 0.4], "y": [-0.8, 0.0]},
    "coarse_downstream": {"x": [6.0, 6.5], "y": [-6.5, -6.0]},
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def region_summary(polydata, cell_ids: np.ndarray, cell_types: np.ndarray, points: np.ndarray, offsets: np.ndarray, connectivity: np.ndarray, name: str, bounds: dict) -> dict:
    polygon_centers = []
    widths = []
    heights = []
    vertex_counts = []
    selected_indices = []
    for index in range(len(offsets) - 1):
        start, end = int(offsets[index]), int(offsets[index + 1])
        polygon = points[connectivity[start:end], :2]
        center = polygon.mean(axis=0)
        if not (
            bounds["x"][0] <= center[0] <= bounds["x"][1]
            and bounds["y"][0] <= center[1] <= bounds["y"][1]
        ):
            continue
        extent = polygon.max(axis=0) - polygon.min(axis=0)
        polygon_centers.append(center)
        widths.append(float(extent[0]))
        heights.append(float(extent[1]))
        vertex_counts.append(end - start)
        selected_indices.append(index)
    del polydata
    if not polygon_centers:
        return {"bounds_m": bounds, "cut_polygons": 0}
    selected_cells = np.asarray(cell_ids[selected_indices], dtype=np.int64)
    unique_cells, counts = np.unique(selected_cells, return_counts=True)
    types = Counter(int(cell_types[cell_id]) for cell_id in unique_cells)
    type_labels = {VTK_HEXAHEDRON: "VTK_HEXAHEDRON", VTK_POLYHEDRON: "VTK_POLYHEDRON"}
    return {
        "bounds_m": bounds,
        "cut_polygons": len(polygon_centers),
        "unique_native_cells": int(len(unique_cells)),
        "native_cells_with_multiple_cut_polygons": int((counts > 1).sum()),
        "native_cell_types": {type_labels.get(k, f"VTK_TYPE_{k}"): int(v) for k, v in sorted(types.items())},
        "polygon_vertex_count_min_max": [int(min(vertex_counts)), int(max(vertex_counts))],
        "cut_polygon_x_span_p10_median_p90": [float(np.quantile(widths, q)) for q in (0.1, 0.5, 0.9)],
        "cut_polygon_y_span_p10_median_p90": [float(np.quantile(heights, q)) for q in (0.1, 0.5, 0.9)],
    }


def main() -> None:
    started = time.monotonic()
    sys.path.insert(0, str(ROOT / "results/runs/rouaix-fine-water-view-20261028"))
    fine_view = importlib.import_module("render_fine_water_view")
    with np.load(GEOMETRY) as geometry:
        centers = geometry["centres_m"].copy()
        volumes = geometry["volumes_m3"].copy()
    reader, grid, order_receipt = fine_view.read_native_grid(centers, volumes)
    if grid.GetNumberOfCells() != EXPECTED_CELLS:
        raise RuntimeError("native grid count differs from qualified mesh")

    ids = np.arange(EXPECTED_CELLS, dtype=np.int64)
    id_array = numpy_to_vtkIdTypeArray(ids, deep=True)
    id_array.SetName("native_global_cell_id")
    grid.GetCellData().AddArray(id_array)
    del id_array, ids, centers, volumes

    plane = vtkPlane()
    plane.SetOrigin(0.0, 0.0, 0.0)
    plane.SetNormal(0.0, 0.0, 1.0)
    cutter = vtkCutter()
    cutter.SetInputData(grid)
    cutter.SetCutFunction(plane)
    cutter.GenerateTrianglesOff()
    cutter.Update()
    cut = cutter.GetOutput()
    polygons = cut.GetPolys()
    offsets = vtk_to_numpy(polygons.GetOffsetsArray())
    connectivity = vtk_to_numpy(polygons.GetConnectivityArray())
    points = vtk_to_numpy(cut.GetPoints().GetData())
    ids_out = cut.GetCellData().GetArray("native_global_cell_id")
    if ids_out is None:
        raise RuntimeError("vtkCutter did not preserve source native-cell IDs")
    cell_ids = vtk_to_numpy(ids_out).astype(np.int64, copy=False)
    if len(cell_ids) != cut.GetNumberOfPolys() or int(cell_ids.min()) < 0 or int(cell_ids.max()) >= EXPECTED_CELLS:
        raise RuntimeError("cut polygons do not map one-to-one to valid native cell IDs")

    cell_types = vtk_to_numpy(grid.GetCellTypesArray())
    if cell_types.shape != (EXPECTED_CELLS,):
        raise RuntimeError("native grid cell-type array has the wrong size")

    # Canonicalize each cut polygon's coordinates at sub-micrometre tolerance.
    # Identical keys indicate duplicate geometry (for example a cut exactly on
    # a shared face), independent of point ordering/orientation.
    geometry_counts: Counter[bytes] = Counter()
    geometry_cells: dict[bytes, list[int]] = defaultdict(list)
    for index in range(len(offsets) - 1):
        poly = points[connectivity[int(offsets[index]) : int(offsets[index + 1])], :]
        quantized = np.rint(poly / 1e-9).astype(np.int64)
        order = np.lexsort((quantized[:, 2], quantized[:, 1], quantized[:, 0]))
        key = quantized[order].tobytes()
        geometry_counts[key] += 1
        if len(geometry_cells[key]) < 4:
            geometry_cells[key].append(int(cell_ids[index]))
    duplicate_groups = {key: count for key, count in geometry_counts.items() if count > 1}
    duplicate_examples = []
    for key, count in list(duplicate_groups.items())[:8]:
        duplicate_examples.append({"duplicate_count": count, "native_cell_ids": geometry_cells[key]})

    local_regions = {
        name: region_summary(cut, cell_ids, cell_types, points, offsets, connectivity, name, bounds)
        for name, bounds in REGIONS.items()
    }
    source_cell_ids, polygons_per_cell = np.unique(cell_ids, return_counts=True)
    unique_cell_type_hist = Counter(int(cell_types[cell_id]) for cell_id in source_cell_ids)
    repeated_cell_ids = source_cell_ids[polygons_per_cell > 1]
    repeated_cell_type_hist = Counter(int(cell_types[cell_id]) for cell_id in repeated_cell_ids)
    type_labels = {VTK_HEXAHEDRON: "VTK_HEXAHEDRON", VTK_POLYHEDRON: "VTK_POLYHEDRON"}
    receipt = {
        "schema_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "mesh_cells": EXPECTED_CELLS,
        "source_mesh_geometry_npz_sha256": sha256(GEOMETRY),
        "native_reader_cell_order_check": order_receipt,
        "cut": {
            "plane_origin_m": [0.0, 0.0, 0.0],
            "plane_normal": [0.0, 0.0, 1.0],
            "native_cut_polygons": int(cut.GetNumberOfPolys()),
            "cut_polygons_with_valid_native_cell_id": int(len(cell_ids)),
            "cut_polygons_unique_native_cell_ids": int(len(np.unique(cell_ids))),
            "native_cell_types_by_cut_polygon": {type_labels.get(k, f"VTK_TYPE_{k}"): int(v) for k, v in sorted(Counter(int(cell_types[cid]) for cid in cell_ids).items())},
            "native_cell_types_by_unique_cut_cell": {type_labels.get(k, f"VTK_TYPE_{k}"): int(v) for k, v in sorted(unique_cell_type_hist.items())},
            "native_cells_with_multiple_cut_polygons": int(len(repeated_cell_ids)),
            "repeated_polygon_native_cell_types": {type_labels.get(k, f"VTK_TYPE_{k}"): int(v) for k, v in sorted(repeated_cell_type_hist.items())},
            "duplicate_polygon_geometry_groups_at_1nm_quantization": int(len(duplicate_groups)),
            "duplicate_polygon_instances": int(sum(count - 1 for count in duplicate_groups.values())),
            "duplicate_geometry_examples": duplicate_examples,
            "polygons_per_native_cell_max": int(polygons_per_cell.max()),
        },
        "local_regions": local_regions,
        "interpretation": (
            "The plotted curves are unique edges of exact vtkCutter plane-intersection polygons, "
            "each carrying a native global cell ID. They include edges of irregular/polyhedral "
            "cell intersections; they are not an interpolated alpha/interface contour. Identical "
            "polygon geometry is counted separately to detect coincident cut faces."
        ),
        "processing": {"elapsed_s": round(time.monotonic() - started, 2)},
    }
    output = SUMMARY / "cut-intersection-audit.json"
    output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == "__main__":
    main()
