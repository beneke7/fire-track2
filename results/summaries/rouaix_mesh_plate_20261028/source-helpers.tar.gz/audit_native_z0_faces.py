#!/usr/bin/env python3
"""Extract exact z=0 internal faces directly from the binary native polyMesh."""

from __future__ import annotations

import hashlib
import json
import mmap
import re
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
MESH = ROOT / "results/runs/rouaix-matched-mesh-mac-20261025/final-cast-only-transfer-core/constant/polyMesh"
GEOMETRY = ROOT / "results/runs/rouaix-fine-water-view-20261028/staging/native-cell-centres-volumes.npz"
SUMMARY = ROOT / "results/summaries/rouaix_mesh_plate_20261028"
ROIS = {
    "fine_nozzle": {"x": [-0.4, 0.4], "y": [-0.8, 0.0]},
    "coarse_downstream": {"x": [1.5, 2.0], "y": [-4.5, -4.0]},
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def binary_header(path: Path) -> tuple[int, int]:
    with path.open("rb") as stream:
        header = stream.read(8192)
    end = header.find(b"\n}\n")
    if end < 0:
        raise ValueError(f"OpenFOAM header not found: {path}")
    match = re.search(rb"(?m)^(\d+)\n\(", header[end + 3 :])
    if not match:
        raise ValueError(f"binary list header not found: {path}")
    return int(match.group(1)), end + 3 + match.end()


def polygon_area_xy(xy: np.ndarray) -> float:
    return abs(float(np.dot(xy[:, 0], np.roll(xy[:, 1], -1)) - np.dot(xy[:, 1], np.roll(xy[:, 0], -1)))) * 0.5


def main() -> None:
    started = time.monotonic()
    points_path, faces_path = MESH / "points", MESH / "faces"
    owner_path, neighbour_path = MESH / "owner", MESH / "neighbour"
    n_points, points_start = binary_header(points_path)
    n_offsets, offsets_start = binary_header(faces_path)
    n_owner, owner_start = binary_header(owner_path)
    n_internal, neighbour_start = binary_header(neighbour_path)
    if n_owner != n_offsets - 1 or n_internal >= n_owner:
        raise ValueError("native face, owner and neighbour counts disagree")

    with points_path.open("rb") as points_stream, faces_path.open("rb") as faces_stream, owner_path.open("rb") as owner_stream, neighbour_path.open("rb") as neighbour_stream:
        points_map = mmap.mmap(points_stream.fileno(), 0, access=mmap.ACCESS_READ)
        faces_map = mmap.mmap(faces_stream.fileno(), 0, access=mmap.ACCESS_READ)
        owner_map = mmap.mmap(owner_stream.fileno(), 0, access=mmap.ACCESS_READ)
        neighbour_map = mmap.mmap(neighbour_stream.fileno(), 0, access=mmap.ACCESS_READ)
        try:
            points = np.ndarray((n_points, 3), dtype="<f8", buffer=points_map, offset=points_start)
            offsets = np.ndarray((n_offsets,), dtype="<i4", buffer=faces_map, offset=offsets_start)
            after_offsets = offsets_start + n_offsets * 4
            if faces_map[after_offsets : after_offsets + 2] != b")\n":
                raise ValueError("compact face offsets have invalid terminator")
            labels_header = re.match(rb"(\d+)\n\(", faces_map[after_offsets + 2 : after_offsets + 64])
            if not labels_header:
                raise ValueError("compact face-label list header not found")
            n_labels = int(labels_header.group(1))
            labels_start = after_offsets + 2 + labels_header.end()
            labels = np.ndarray((n_labels,), dtype="<i4", buffer=faces_map, offset=labels_start)
            owner = np.ndarray((n_owner,), dtype="<i4", buffer=owner_map, offset=owner_start)
            neighbour = np.ndarray((n_internal,), dtype="<i4", buffer=neighbour_map, offset=neighbour_start)
            if int(offsets[-1]) != n_labels:
                raise ValueError("native face connectivity count mismatch")

            on_plane_point = np.abs(points[:, 2]) <= 1e-12
            on_plane_face = np.logical_and.reduceat(on_plane_point[labels], offsets[:-1])
            face_ids = np.flatnonzero(on_plane_face[:n_internal]).astype(np.int64)
            if not len(face_ids):
                raise RuntimeError("no native internal face lies on z=0 within 1e-12 m")

            face_polygons: list[np.ndarray] = []
            face_centres: list[np.ndarray] = []
            spans: list[np.ndarray] = []
            areas: list[float] = []
            edge_pairs: list[np.ndarray] = []
            vertex_hist = Counter()
            duplicate_keys = Counter()
            region_indices: dict[str, list[int]] = {key: [] for key in ROIS}
            max_face_by_region: dict[str, tuple[float, int]] = {}
            for row, face_id in enumerate(face_ids):
                start, stop = int(offsets[face_id]), int(offsets[face_id + 1])
                point_ids = labels[start:stop].astype(np.int64, copy=False)
                xyz = points[point_ids]
                xy = xyz[:, :2].copy()
                face_polygons.append(xy)
                center = xy.mean(axis=0)
                extent = xy.max(axis=0) - xy.min(axis=0)
                area = polygon_area_xy(xy)
                face_centres.append(center)
                spans.append(extent)
                areas.append(area)
                vertex_hist[len(point_ids)] += 1
                q = np.rint(xyz / 1e-9).astype(np.int64)
                order = np.lexsort((q[:, 2], q[:, 1], q[:, 0]))
                duplicate_keys[q[order].tobytes()] += 1
                pairs = np.column_stack((point_ids, np.roll(point_ids, -1)))
                edge_pairs.append(np.sort(pairs, axis=1))
                for name, bounds in ROIS.items():
                    if bounds["x"][0] <= center[0] <= bounds["x"][1] and bounds["y"][0] <= center[1] <= bounds["y"][1]:
                        region_indices[name].append(row)
                        score = float(extent.max())
                        if name not in max_face_by_region or score > max_face_by_region[name][0]:
                            max_face_by_region[name] = (score, row)

            all_pairs = np.concatenate(edge_pairs, axis=0)
            unique_pairs = np.unique(all_pairs, axis=0)
            unique_edges_xyz = points[unique_pairs]
            edge_segments = unique_edges_xyz[:, :, :2].astype(np.float64, copy=False)
            edge_midpoints = edge_segments.mean(axis=1)
            edge_lengths = np.linalg.norm(edge_segments[:, 1] - edge_segments[:, 0], axis=1)
            result_regions = {}
            with np.load(GEOMETRY) as cached:
                centres = cached["centres_m"].copy()
                volumes = cached["volumes_m3"].copy()
            for name, indexes in region_indices.items():
                if not indexes:
                    raise RuntimeError(f"no native z=0 faces in ROI {name}")
                selected_centres = np.asarray(face_centres)[indexes]
                selected_spans = np.asarray(spans)[indexes]
                local_edge = (
                    (edge_midpoints[:, 0] >= ROIS[name]["x"][0])
                    & (edge_midpoints[:, 0] <= ROIS[name]["x"][1])
                    & (edge_midpoints[:, 1] >= ROIS[name]["y"][0])
                    & (edge_midpoints[:, 1] <= ROIS[name]["y"][1])
                )
                local_lengths = edge_lengths[local_edge]
                target_row = max_face_by_region[name][1]
                face_id = int(face_ids[target_row])
                owner_id = int(owner[face_id])
                neighbour_id = int(neighbour[face_id])
                result_regions[name] = {
                    "roi_bounds_m": ROIS[name],
                    "native_internal_faces": int(len(indexes)),
                    "unique_native_cells_on_faces": int(len(set([owner[face_ids[i]] for i in indexes] + [neighbour[face_ids[i]] for i in indexes]))),
                    "native_face_vertex_count_min_max": [
                        int(min(len(face_polygons[i]) for i in indexes)),
                        int(max(len(face_polygons[i]) for i in indexes)),
                    ],
                    "face_span_x_p10_median_p90_m": [float(np.quantile(selected_spans[:, 0], q)) for q in (0.1, 0.5, 0.9)],
                    "face_span_y_p10_median_p90_m": [float(np.quantile(selected_spans[:, 1], q)) for q in (0.1, 0.5, 0.9)],
                    "unique_edge_segments_in_roi": int(len(local_lengths)),
                    "edge_length_p10_median_p90_m": [float(np.quantile(local_lengths, q)) for q in (0.1, 0.5, 0.9)],
                    "largest_face_in_roi": {
                        "native_face_id": face_id,
                        "span_xy_m": [float(v) for v in spans[target_row]],
                        "area_m2": float(areas[target_row]),
                        "point_count": int(len(face_polygons[target_row])),
                        "polygon_xy_m": face_polygons[target_row].tolist(),
                        "owner_cell_id": owner_id,
                        "neighbour_cell_id": neighbour_id,
                        "owner_cell_centre_m": [float(v) for v in centres[owner_id]],
                        "owner_cell_volume_m3": float(volumes[owner_id]),
                        "neighbour_cell_centre_m": [float(v) for v in centres[neighbour_id]],
                        "neighbour_cell_volume_m3": float(volumes[neighbour_id]),
                    },
                }

            total_area = float(np.sum(areas))
            bounds_xy = np.asarray(face_centres)
            receipt = {
                "schema_version": 1,
                "created_utc": datetime.now(timezone.utc).isoformat(),
                "source_mesh": str(MESH),
                "source_mesh_sha256": {name: sha256(MESH / name) for name in ("points", "faces", "owner", "neighbour", "boundary")},
                "geometry_cache_sha256": sha256(GEOMETRY),
                "binary_counts": {"points": n_points, "faces": n_owner, "internal_faces": n_internal, "native_cells_from_qualified_mesh": 10_099_265},
                "plane": {"z_m": 0.0, "criterion": "every face vertex satisfies abs(z) <= 1e-12 m", "selected_internal_face_count": int(len(face_ids)), "unique_native_face_edges": int(len(unique_pairs)), "face_vertex_histogram": {str(k): int(v) for k, v in sorted(vertex_hist.items())}, "projected_area_sum_m2": total_area, "expected_rectangular_section_area_m2": 200.0, "projected_area_relative_residual": (total_area - 200.0) / 200.0, "face_centroid_bounds_m": {axis: [float(bounds_xy[:, i].min()), float(bounds_xy[:, i].max())] for i, axis in enumerate(("x", "y"))}, "duplicate_face_geometry_groups_at_1nm": int(sum(1 for v in duplicate_keys.values() if v > 1)), "duplicate_face_instances": int(sum(v - 1 for v in duplicate_keys.values() if v > 1))},
                "regions": result_regions,
                "interpretation": "This diagnostic selects internal native polyMesh faces whose vertices lie on z=0; it does not use vtkCutter. Unique section edges are deduplicated by their native point-label pairs.",
                "processing": {"elapsed_s": round(time.monotonic() - started, 2)},
            }
            (SUMMARY / "native-z0-face-audit.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
            print(json.dumps(receipt, indent=2), flush=True)
        finally:
            del labels, offsets, points, owner, neighbour, on_plane_point, on_plane_face
            neighbour_map.close()
            owner_map.close()
            faces_map.close()
            points_map.close()


if __name__ == "__main__":
    main()
