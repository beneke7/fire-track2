#!/usr/bin/env pvpython
"""Compare exact and micrometre-offset native z cuts and map ROI cells."""

from __future__ import annotations

import hashlib
import importlib
import json
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from vtk import VTK_HEXAHEDRON, VTK_POLYHEDRON, vtkCutter, vtkExtractEdges, vtkPlane
from vtk.util.numpy_support import numpy_to_vtkIdTypeArray, vtk_to_numpy

ROOT = Path(__file__).resolve().parents[3]
SUMMARY = ROOT / "results/summaries/rouaix_mesh_plate_20261028"
GEOMETRY = ROOT / "results/runs/rouaix-fine-water-view-20261028/staging/native-cell-centres-volumes.npz"
GEOMETRY_RECEIPT = ROOT / "results/runs/rouaix-fine-water-view-20261028/staging/native-cell-centres-volumes.json"
EXPECTED_CELLS = 10_099_265
REGIONS = {
    "fine_nozzle": {"x": [-0.4, 0.4], "y": [-0.8, 0.0]},
    "coarse_downstream": {"x": [6.0, 6.5], "y": [-6.5, -6.0]},
}
TYPE_NAMES = {VTK_HEXAHEDRON: "VTK_HEXAHEDRON", VTK_POLYHEDRON: "VTK_POLYHEDRON"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _canonical_points(points: np.ndarray) -> bytes:
    quantized = np.rint(points / 1e-9).astype(np.int64)
    order = np.lexsort((quantized[:, 2], quantized[:, 1], quantized[:, 0]))
    return quantized[order].tobytes()


def cell_detail(grid, cell_id: int, centres: np.ndarray, volumes: np.ndarray, cut_polygon_xyz: np.ndarray) -> dict:
    cell = grid.GetCell(int(cell_id))
    bounds = cell.GetBounds()
    get_faces = getattr(cell, "GetNumberOfFaces", None)
    face_count = int(get_faces()) if get_faces else None
    coplanar_faces = []
    exact_face_match = False
    if get_faces:
        polygon_key = _canonical_points(cut_polygon_xyz) if np.all(np.abs(cut_polygon_xyz[:, 2]) <= 1e-12) else None
        for face_index in range(face_count):
            face = cell.GetFace(face_index)
            face_points = vtk_to_numpy(face.GetPoints().GetData())
            if not np.all(np.abs(face_points[:, 2]) <= 1e-12):
                continue
            if polygon_key == _canonical_points(face_points):
                exact_face_match = True
            coplanar_faces.append({
                "face_index": face_index,
                "point_count": int(len(face_points)),
                "bounds_xy_m": [
                    [float(face_points[:, 0].min()), float(face_points[:, 0].max())],
                    [float(face_points[:, 1].min()), float(face_points[:, 1].max())],
                ],
            })
    return {
        "native_global_cell_id": int(cell_id),
        "vtk_type": TYPE_NAMES.get(int(grid.GetCellType(int(cell_id))), f"VTK_TYPE_{grid.GetCellType(int(cell_id))}"),
        "native_cell_centre_m": [float(v) for v in centres[cell_id]],
        "native_cell_volume_m3": float(volumes[cell_id]),
        "native_cell_bounds_m": {
            "x": [float(bounds[0]), float(bounds[1])],
            "y": [float(bounds[2]), float(bounds[3])],
            "z": [float(bounds[4]), float(bounds[5])],
        },
        "native_cell_point_count": int(cell.GetNumberOfPoints()),
        "native_cell_face_count": face_count,
        "native_cell_edge_count": int(cell.GetNumberOfEdges()),
        "native_faces_coplanar_with_z0": coplanar_faces,
        "cut_polygon_matches_native_z0_face": exact_face_match,
    }


def measure_cut(grid, z: float, centres: np.ndarray, volumes: np.ndarray) -> dict:
    plane = vtkPlane()
    plane.SetOrigin(0.0, 0.0, z)
    plane.SetNormal(0.0, 0.0, 1.0)
    cutter = vtkCutter()
    cutter.SetInputData(grid)
    cutter.SetCutFunction(plane)
    cutter.GenerateTrianglesOff()
    cutter.Update()
    cut = cutter.GetOutput()
    if cut.GetNumberOfCells() != cut.GetNumberOfPolys():
        raise RuntimeError("offset cut contains non-polygon output cells")
    source_ids_array = cut.GetCellData().GetArray("native_global_cell_id")
    if source_ids_array is None:
        raise RuntimeError("offset cutter did not preserve native global cell ids")
    source_ids = vtk_to_numpy(source_ids_array).astype(np.int64, copy=False)
    offsets = vtk_to_numpy(cut.GetPolys().GetOffsetsArray())
    connectivity = vtk_to_numpy(cut.GetPolys().GetConnectivityArray())
    points = vtk_to_numpy(cut.GetPoints().GetData())
    edge_filter = vtkExtractEdges()
    edge_filter.SetInputData(cut)
    edge_filter.Update()
    edge_poly = edge_filter.GetOutput()
    edge_ids = vtk_to_numpy(edge_poly.GetLines().GetConnectivityArray()).reshape(-1, 2)
    edge_points = vtk_to_numpy(edge_poly.GetPoints().GetData())
    segments = edge_points[edge_ids][:, :, :2]
    segment_lengths = np.linalg.norm(segments[:, 1] - segments[:, 0], axis=1)
    valid_edges = np.isfinite(segments).all(axis=(1, 2)) & np.isfinite(segment_lengths) & (segment_lengths > 1e-6)
    segment_mid = segments.mean(axis=1)
    local_edge_stats = {}
    local_cell_stats = {}
    for name, bounds in REGIONS.items():
        selected_edges = (
            valid_edges
            & (segment_mid[:, 0] >= bounds["x"][0])
            & (segment_mid[:, 0] <= bounds["x"][1])
            & (segment_mid[:, 1] >= bounds["y"][0])
            & (segment_mid[:, 1] <= bounds["y"][1])
        )
        local_lengths = segment_lengths[selected_edges]
        poly_centres = []
        spans = []
        selected_ids = []
        touching_plane = []
        largest = None
        for index in range(len(offsets) - 1):
            poly = points[connectivity[int(offsets[index]) : int(offsets[index + 1])], :2]
            centre = poly.mean(axis=0)
            if not (bounds["x"][0] <= centre[0] <= bounds["x"][1] and bounds["y"][0] <= centre[1] <= bounds["y"][1]):
                continue
            span = poly.max(axis=0) - poly.min(axis=0)
            score = float(span.max())
            poly_centres.append(centre)
            spans.append(span)
            selected_ids.append(int(source_ids[index]))
            cell_bounds = grid.GetCell(int(source_ids[index])).GetBounds()
            if abs(cell_bounds[4] - z) <= 1e-12 or abs(cell_bounds[5] - z) <= 1e-12:
                touching_plane.append(int(source_ids[index]))
            if largest is None or score > largest[0]:
                largest = (score, index, span)
        if not len(local_lengths) or not selected_ids:
            raise RuntimeError(f"empty local cut at z={z:g} in {name}")
        ids_unique, multiplicity = np.unique(np.asarray(selected_ids, dtype=np.int64), return_counts=True)
        type_counts = Counter(int(grid.GetCellType(int(cell_id))) for cell_id in ids_unique)
        local_edge_stats[name] = {
            "unique_edge_segments": int(len(local_lengths)),
            "edge_length_p10_median_p90_m": [float(np.quantile(local_lengths, q)) for q in (0.1, 0.5, 0.9)],
            "segments_le_1e-6m_removed": int((~(np.isfinite(segments).all(axis=(1, 2)) & (segment_lengths > 1e-6))).sum()),
        }
        local_cell_stats[name] = {
            "cut_polygons": int(len(selected_ids)),
            "unique_native_cells": int(len(ids_unique)),
            "cells_with_multiple_cut_polygons": int((multiplicity > 1).sum()),
            "native_cells_with_a_bbox_face_on_requested_plane": int(len(touching_plane)),
            "unique_native_cells_with_a_bbox_face_on_requested_plane": int(len(set(touching_plane))),
            "native_cell_types_by_unique_cell": {TYPE_NAMES.get(k, f"VTK_TYPE_{k}"): int(v) for k, v in sorted(type_counts.items())},
            "cut_polygon_span_x_p10_median_p90_m": [float(np.quantile(np.asarray(spans)[:, 0], q)) for q in (0.1, 0.5, 0.9)],
            "cut_polygon_span_y_p10_median_p90_m": [float(np.quantile(np.asarray(spans)[:, 1], q)) for q in (0.1, 0.5, 0.9)],
            "largest_polygon_span_m": [float(v) for v in largest[2]],
            "largest_polygon_native_cell": cell_detail(
                grid,
                source_ids[largest[1]],
                centres,
                volumes,
                points[connectivity[int(offsets[largest[1]]) : int(offsets[largest[1] + 1])]],
            ),
        }
    unique_ids, counts = np.unique(source_ids, return_counts=True)
    repeated = unique_ids[counts > 1]
    repeated_type_counts = Counter(int(grid.GetCellType(int(cell_id))) for cell_id in repeated)

    # Exact geometric duplicate check within this plane, independent of point order.
    keys = Counter()
    for index in range(len(offsets) - 1):
        poly = points[connectivity[int(offsets[index]) : int(offsets[index + 1])], :]
        keys[_canonical_points(poly)] += 1

    return {
        "plane_z_m": z,
        "cut_polygons": int(cut.GetNumberOfPolys()),
        "unique_native_cells": int(len(unique_ids)),
        "native_cells_with_multiple_polygons": int(len(repeated)),
        "repeated_cell_types": {TYPE_NAMES.get(k, f"VTK_TYPE_{k}"): int(v) for k, v in sorted(repeated_type_counts.items())},
        "duplicate_polygon_geometry_groups_at_1nm": int(sum(1 for count in keys.values() if count > 1)),
        "duplicate_polygon_instances": int(sum(count - 1 for count in keys.values() if count > 1)),
        "local_edges": local_edge_stats,
        "local_cells": local_cell_stats,
    }


def main() -> None:
    started = time.monotonic()
    sys.path.insert(0, str(ROOT / "results/runs/rouaix-fine-water-view-20261028"))
    fine_view = importlib.import_module("render_fine_water_view")
    with np.load(GEOMETRY) as geometry:
        centres = geometry["centres_m"].copy()
        volumes = geometry["volumes_m3"].copy()
    reader, grid, order_receipt = fine_view.read_native_grid(centres, volumes)
    ids = np.arange(EXPECTED_CELLS, dtype=np.int64)
    array = numpy_to_vtkIdTypeArray(ids, deep=True)
    array.SetName("native_global_cell_id")
    grid.GetCellData().AddArray(array)
    del array, ids
    cuts = [measure_cut(grid, z, centres, volumes) for z in (0.0, 1e-6, -1e-6)]
    receipt = {
        "schema_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_geometry_npz_sha256": sha256(GEOMETRY),
        "native_reader_cell_order_check": order_receipt,
        "offsets_m": [0.0, 1e-6, -1e-6],
        "offset_results": cuts,
        "interpretation": (
            "Each ROI cut polygon carries its source native cell ID. Plane offsets test whether "
            "the visible edge pattern depends on the exact central plane. Repeated native cell IDs "
            "mean one native cell emitted more than one cut polygon; geometric duplicates are checked separately."
        ),
        "processing": {"elapsed_s": round(time.monotonic() - started, 2)},
    }
    output = SUMMARY / "cut-offset-comparison.json"
    output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == "__main__":
    main()
