#!/usr/bin/env pvpython
"""Extract and plot the exact native-cell intersection at z=0 for Rouaix."""

from __future__ import annotations

import argparse
import gc
import hashlib
import importlib
import json
import mmap
import math
import re
import resource
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.collections import LineCollection
from matplotlib.patches import Circle, ConnectionPatch
from paraview import servermanager

REPO = Path(__file__).resolve().parents[3]
RUN = REPO / "results/runs/rouaix-mesh-plate-20261028"
SUMMARY = REPO / "results/summaries/rouaix_mesh_plate_20261028"
MESH = REPO / "results/runs/rouaix-matched-mesh-mac-20261025/final-cast-only-transfer-core/constant/polyMesh"
CASE_MARKER = REPO / "results/runs/rouaix-matched-mesh-mac-20261025/final-cast-only-transfer-core/case.foam"
GEOMETRY = REPO / "results/runs/rouaix-fine-water-view-20261028/staging/native-cell-centres-volumes.npz"
GEOMETRY_RECEIPT = REPO / "results/runs/rouaix-fine-water-view-20261028/staging/native-cell-centres-volumes.json"
EXPECTED_CELLS = 10_099_265
NOMINAL_FINE_M = 0.014
NOMINAL_COARSE_M = 0.056
DOMAIN = {"x": [-2.5, 17.5], "y": [-10.0, 0.0]}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def peak_rss_gib() -> float:
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    scale = 1024**3 if Path("/System/Library").exists() else 1024**2
    return float(value / scale)


def boundary_ranges(path: Path) -> dict[str, tuple[int, int]]:
    text = path.read_text(encoding="ascii", errors="replace")
    header_end = text.find("\n(")
    if header_end < 0:
        raise ValueError("could not locate OpenFOAM boundary patch list")
    ranges = {}
    for match in re.finditer(r"([A-Za-z0-9_.-]+)\s*\{([^{}]*)\}", text[header_end + 2 :], re.S):
        body = match.group(2)
        count = re.search(r"\bnFaces\s+(\d+)\s*;", body)
        start = re.search(r"\bstartFace\s+(\d+)\s*;", body)
        if count and start:
            ranges[match.group(1)] = (int(start.group(1)), int(count.group(1)))
    if not ranges:
        raise ValueError("no OpenFOAM boundary patches parsed")
    return ranges


def binary_list_header(path: Path) -> tuple[int, int]:
    with path.open("rb") as stream:
        header = stream.read(8192)
    header_end = header.find(b"\n}\n")
    if header_end < 0:
        raise ValueError(f"OpenFOAM file header not found: {path}")
    match = re.search(rb"(?m)^(\d+)\n\(", header[header_end + 3 :])
    if not match:
        raise ValueError(f"binary OpenFOAM list not found: {path}")
    return int(match.group(1)), header_end + 3 + match.end()


def patch_bounds(mesh: Path) -> dict[str, dict]:
    """Compute actual patch point bounds from binary points/faces, without full copies."""
    points_path = mesh / "points"
    faces_path = mesh / "faces"
    n_points, points_start = binary_list_header(points_path)
    n_offsets, offsets_start = binary_list_header(faces_path)
    if n_offsets < 2:
        raise ValueError("invalid compact face offset list")
    with points_path.open("rb") as points_stream, faces_path.open("rb") as faces_stream:
        points_map = __import__("mmap").mmap(points_stream.fileno(), 0, access=__import__("mmap").ACCESS_READ)
        faces_map = __import__("mmap").mmap(faces_stream.fileno(), 0, access=__import__("mmap").ACCESS_READ)
        try:
            points = np.ndarray((n_points, 3), dtype="<f8", buffer=points_map, offset=points_start)
            offsets = np.ndarray((n_offsets,), dtype="<i4", buffer=faces_map, offset=offsets_start)
            after_offsets = offsets_start + n_offsets * 4
            if faces_map[after_offsets : after_offsets + 2] != b")\n":
                raise ValueError("compact face offset list has an unexpected terminator")
            label_count = re.match(rb"(\d+)\n\(", faces_map[after_offsets + 2 : after_offsets + 64])
            if not label_count:
                raise ValueError("compact face connectivity count is missing")
            n_labels = int(label_count.group(1))
            labels_start = after_offsets + 2 + label_count.end()
            labels = np.ndarray((n_labels,), dtype="<i4", buffer=faces_map, offset=labels_start)
            if int(offsets[-1]) != n_labels:
                raise ValueError("face offsets/connectivity count do not agree")
            result = {}
            for patch, (first_face, face_count) in boundary_ranges(mesh / "boundary").items():
                lo = int(offsets[first_face])
                hi = int(offsets[first_face + face_count])
                point_ids = labels[lo:hi]
                if point_ids.size == 0 or int(point_ids.min()) < 0 or int(point_ids.max()) >= n_points:
                    raise ValueError(f"invalid point labels in patch {patch}")
                xyz = points[point_ids]
                result[patch] = {
                    "face_count": face_count,
                    "bounds_m": {
                        axis: [float(xyz[:, i].min()), float(xyz[:, i].max())]
                        for i, axis in enumerate(("x", "y", "z"))
                    },
                    "point_references": int(point_ids.size),
                }
            return result
        finally:
            del labels, offsets, points
            faces_map.close()
            points_map.close()


def native_z0_faces(mesh: Path) -> tuple[np.ndarray, dict, dict[str, np.ndarray]]:
    """Read exact internal faces on z=0 and unique edges by native point labels."""
    points_path, faces_path = mesh / "points", mesh / "faces"
    owner_path, neighbour_path = mesh / "owner", mesh / "neighbour"
    n_points, points_start = binary_list_header(points_path)
    n_offsets, offsets_start = binary_list_header(faces_path)
    n_owner, owner_start = binary_list_header(owner_path)
    n_internal, neighbour_start = binary_list_header(neighbour_path)
    if n_owner != n_offsets - 1 or n_internal >= n_owner:
        raise ValueError("native face, owner, and neighbour counts disagree")

    with points_path.open("rb") as point_stream, faces_path.open("rb") as face_stream, owner_path.open("rb") as owner_stream, neighbour_path.open("rb") as neighbour_stream:
        points_map = mmap.mmap(point_stream.fileno(), 0, access=mmap.ACCESS_READ)
        faces_map = mmap.mmap(face_stream.fileno(), 0, access=mmap.ACCESS_READ)
        owner_map = mmap.mmap(owner_stream.fileno(), 0, access=mmap.ACCESS_READ)
        neighbour_map = mmap.mmap(neighbour_stream.fileno(), 0, access=mmap.ACCESS_READ)
        try:
            points = np.ndarray((n_points, 3), dtype="<f8", buffer=points_map, offset=points_start)
            offsets = np.ndarray((n_offsets,), dtype="<i4", buffer=faces_map, offset=offsets_start)
            after_offsets = offsets_start + n_offsets * 4
            if faces_map[after_offsets : after_offsets + 2] != b")\n":
                raise ValueError("compact face offset list has an invalid terminator")
            labels_header = re.match(rb"(\d+)\n\(", faces_map[after_offsets + 2 : after_offsets + 64])
            if not labels_header:
                raise ValueError("compact face connectivity header is missing")
            n_labels = int(labels_header.group(1))
            labels_start = after_offsets + 2 + labels_header.end()
            labels = np.ndarray((n_labels,), dtype="<i4", buffer=faces_map, offset=labels_start)
            owner = np.ndarray((n_owner,), dtype="<i4", buffer=owner_map, offset=owner_start)
            neighbour = np.ndarray((n_internal,), dtype="<i4", buffer=neighbour_map, offset=neighbour_start)
            if int(offsets[-1]) != n_labels:
                raise ValueError("native face connectivity count mismatch")

            on_plane = np.abs(points[:, 2]) <= 1e-12
            on_plane_faces = np.logical_and.reduceat(on_plane[labels], offsets[:-1])
            face_ids = np.flatnonzero(on_plane_faces[:n_internal]).astype(np.int64)
            if not len(face_ids):
                raise RuntimeError("no native internal faces lie on z=0 within 1e-12 m")

            face_centres = []
            face_spans = []
            face_areas = []
            face_owner_ids = []
            face_neighbour_ids = []
            face_vertex_counts = []
            edge_pairs = []
            face_keys = {}
            duplicate_face_count = 0
            for face_id in face_ids:
                start, stop = int(offsets[face_id]), int(offsets[face_id + 1])
                point_ids = labels[start:stop].astype(np.int64, copy=False)
                xyz = points[point_ids]
                xy = xyz[:, :2]
                centre = xy.mean(axis=0)
                face_centres.append(centre)
                face_spans.append(xy.max(axis=0) - xy.min(axis=0))
                signed_area = 0.5 * (np.dot(xy[:, 0], np.roll(xy[:, 1], -1)) - np.dot(xy[:, 1], np.roll(xy[:, 0], -1)))
                face_areas.append(abs(float(signed_area)))
                face_owner_ids.append(int(owner[face_id]))
                face_neighbour_ids.append(int(neighbour[face_id]))
                face_vertex_counts.append(int(len(point_ids)))
                pairs = np.column_stack((point_ids, np.roll(point_ids, -1)))
                edge_pairs.append(np.sort(pairs, axis=1))
                q = np.rint(xyz / 1e-9).astype(np.int64)
                order = np.lexsort((q[:, 2], q[:, 1], q[:, 0]))
                key = q[order].tobytes()
                if key in face_keys:
                    duplicate_face_count += 1
                else:
                    face_keys[key] = int(face_id)

            unique_edges = np.unique(np.concatenate(edge_pairs, axis=0), axis=0)
            segments = points[unique_edges][:, :, :2].astype(np.float32, copy=True)
            face_data = {
                "centres_m": np.asarray(face_centres, dtype=np.float64),
                "spans_m": np.asarray(face_spans, dtype=np.float64),
                "areas_m2": np.asarray(face_areas, dtype=np.float64),
                "owner_cell_ids": np.asarray(face_owner_ids, dtype=np.int64),
                "neighbour_cell_ids": np.asarray(face_neighbour_ids, dtype=np.int64),
                "vertex_counts": np.asarray(face_vertex_counts, dtype=np.int16),
            }
            lengths = np.linalg.norm(segments[:, 1] - segments[:, 0], axis=1)
            area_sum = float(np.sum(face_areas))
            if duplicate_face_count or abs(area_sum - 200.0) > 2e-8 or np.any(lengths <= 0.0):
                raise RuntimeError(
                    "native z=0 faces failed duplicate, area-cover, or edge-length checks "
                    f"(duplicates={duplicate_face_count}, area={area_sum}, min_edge={lengths.min()})"
                )
            cut_receipt = {
                "plane_origin_m": [0.0, 0.0, 0.0],
                "plane_normal": [0.0, 0.0, 1.0],
                "selection": "native internal polyMesh faces whose every vertex has abs(z) <= 1e-12 m",
                "native_internal_face_count": int(len(face_ids)),
                "unique_native_point_label_edges": int(len(unique_edges)),
                "native_face_vertex_histogram": {str(k): int(v) for k, v in sorted(Counter(face_vertex_counts).items())},
                "projected_face_area_sum_m2": area_sum,
                "expected_x_y_section_area_m2": 200.0,
                "projected_area_relative_residual": float((area_sum - 200.0) / 200.0),
                "duplicate_face_geometry_groups_at_1nm": duplicate_face_count,
                "edge_length_min_m": float(lengths.min()),
                "edge_length_max_m": float(lengths.max()),
                "section_edge_bounds_m": {
                    axis: [float(segments[:, :, i].min()), float(segments[:, :, i].max())]
                    for i, axis in enumerate(("x", "y"))
                },
            }
            return segments, cut_receipt, face_data
        finally:
            del labels, offsets, points, owner, neighbour, on_plane, on_plane_faces, point_ids, xyz, xy
            neighbour_map.close()
            owner_map.close()
            faces_map.close()
            points_map.close()


def native_face_region_metrics(face_data: dict[str, np.ndarray], segments: np.ndarray, bounds: dict) -> dict:
    centres = face_data["centres_m"]
    selected = (
        (centres[:, 0] >= bounds["x"][0])
        & (centres[:, 0] <= bounds["x"][1])
        & (centres[:, 1] >= bounds["y"][0])
        & (centres[:, 1] <= bounds["y"][1])
    )
    if not np.any(selected):
        raise RuntimeError(f"no exact native internal faces in ROI {bounds}")
    owners = face_data["owner_cell_ids"][selected]
    neighbours = face_data["neighbour_cell_ids"][selected]
    centroids = centres[selected]
    spans = face_data["spans_m"][selected]
    vertices = face_data["vertex_counts"][selected]
    local_segments = segments_in(segments, bounds)
    return {
        "roi_bounds_m": bounds,
        "native_internal_faces": int(selected.sum()),
        "unique_adjacent_native_cells": int(len(np.unique(np.concatenate((owners, neighbours))))),
        "native_face_area_sum_m2": float(face_data["areas_m2"][selected].sum()),
        "face_vertex_count_min_max": [int(vertices.min()), int(vertices.max())],
        "face_span_x_p10_median_p90_m": [float(np.quantile(spans[:, 0], q)) for q in (0.1, 0.5, 0.9)],
        "face_span_y_p10_median_p90_m": [float(np.quantile(spans[:, 1], q)) for q in (0.1, 0.5, 0.9)],
        "unique_edge_segments_in_roi": int(len(local_segments)),
        "edge_length_p10_median_p90_m": [float(np.quantile(np.linalg.norm(local_segments[:, 1] - local_segments[:, 0], axis=1), q)) for q in (0.1, 0.5, 0.9)],
    }


def bin_spacing_table(segments: np.ndarray, tile_m: float = 0.5) -> list[dict]:
    mid = segments.mean(axis=1)
    lengths = np.linalg.norm(segments[:, 1] - segments[:, 0], axis=1)
    ix = np.floor((mid[:, 0] - DOMAIN["x"][0]) / tile_m).astype(np.int32)
    iy = np.floor((mid[:, 1] - DOMAIN["y"][0]) / tile_m).astype(np.int32)
    key = ix * 1000 + iy
    order = np.argsort(key)
    sorted_key = key[order]
    group_starts = np.r_[0, np.flatnonzero(np.diff(sorted_key)) + 1]
    group_ends = np.r_[group_starts[1:], len(order)]
    rows = []
    for start, end in zip(group_starts, group_ends, strict=True):
        value = sorted_key[start]
        x_index, y_index = divmod(int(value), 1000)
        sample = lengths[order[start:end]]
        rows.append(
            {
                "x_bounds_m": [DOMAIN["x"][0] + x_index * tile_m, DOMAIN["x"][0] + (x_index + 1) * tile_m],
                "y_bounds_m": [DOMAIN["y"][0] + y_index * tile_m, DOMAIN["y"][0] + (y_index + 1) * tile_m],
                "edge_count": int(len(sample)),
                "median_edge_length_m": float(np.median(sample)),
                "p10_edge_length_m": float(np.quantile(sample, 0.1)),
                "p90_edge_length_m": float(np.quantile(sample, 0.9)),
            }
        )
    return rows


def choose_candidate(
    rows: list[dict],
    target: float,
    avoid: tuple[float, float, float, float] | None = None,
    near: tuple[float, float] | None = None,
) -> dict:
    eligible = []
    for row in rows:
        median = row["median_edge_length_m"]
        if not target * 0.78 <= median <= target * 1.22 or row["edge_count"] < 40:
            continue
        x0, x1 = row["x_bounds_m"]
        y0, y1 = row["y_bounds_m"]
        if avoid and not (x1 <= avoid[0] or x0 >= avoid[1] or y1 <= avoid[2] or y0 >= avoid[3]):
            continue
        distance = (
            math.hypot((x0 + x1) / 2.0 - near[0], (y0 + y1) / 2.0 - near[1])
            if near is not None
            else 0.0
        )
        score = (
            (distance, abs(math.log(median / target)), -row["edge_count"])
            if near is not None
            else (abs(math.log(median / target)), -row["edge_count"])
        )
        eligible.append((score, row))
    if not eligible:
        raise RuntimeError(f"no z=0 mesh window found near nominal spacing {target:g} m")
    return min(eligible, key=lambda item: item[0])[1]


def segments_in(segments: np.ndarray, bounds: dict[str, list[float]]) -> np.ndarray:
    mid = segments.mean(axis=1)
    selected = (
        (mid[:, 0] >= bounds["x"][0])
        & (mid[:, 0] <= bounds["x"][1])
        & (mid[:, 1] >= bounds["y"][0])
        & (mid[:, 1] <= bounds["y"][1])
    )
    return segments[selected]


def spacing_stats(segments: np.ndarray, bounds: dict[str, list[float]]) -> dict:
    local = segments_in(segments, bounds)
    if not len(local):
        raise RuntimeError(f"no actual mesh edges in requested bounds {bounds}")
    lengths = np.linalg.norm(local[:, 1] - local[:, 0], axis=1)
    return {
        "roi_bounds_m": bounds,
        "unique_edge_segments": int(len(local)),
        "median_segment_length_m": float(np.median(lengths)),
        "p10_segment_length_m": float(np.quantile(lengths, 0.1)),
        "p90_segment_length_m": float(np.quantile(lengths, 0.9)),
        "mean_segment_length_m": float(lengths.mean()),
    }


def figure(segments: np.ndarray, patch_info: dict, metrics: dict, png: Path, pdf: Path) -> dict:
    nozzle = patch_info["nozzle"]["bounds_m"]
    nx = (nozzle["x"][0] + nozzle["x"][1]) / 2.0
    ny = (nozzle["y"][0] + nozzle["y"][1]) / 2.0
    rois = metrics["zoom_regions"]
    fig = plt.figure(figsize=(15.0, 9.3), facecolor="#fffdf8")
    fig.suptitle(
        "Rouaix source-inspired jet mesh • exact central section",
        fontsize=17,
        fontweight="bold",
        x=0.06,
        y=0.975,
        ha="left",
        color="#252525",
    )
    fig.text(
        0.06,
        0.94,
        "Native OpenFOAM cells at z = 0 m  |  domain x = 20 m × y = 10 m  |  x downstream, y upward  |  metres",
        fontsize=10,
        color="#5b5b55",
        ha="left",
    )

    overview = fig.add_axes([0.075, 0.505, 0.85, 0.395], facecolor="#fffdf8")
    overview.add_collection(
        LineCollection(segments, colors="#252525", linewidths=0.11, alpha=0.85, rasterized=True)
    )
    overview.set_xlim(*DOMAIN["x"])
    overview.set_ylim(*DOMAIN["y"])
    overview.set_aspect("equal", adjustable="box")
    overview.set_xlabel("x (m)  →", fontsize=9)
    overview.set_ylabel("y (m)  ↑", fontsize=9)
    overview.tick_params(labelsize=8, length=3, colors="#4d4d48")
    overview.grid(False)
    for spine in overview.spines.values():
        spine.set_color("#33332f")
        spine.set_linewidth(0.7)
    overview.set_title("Domain and central-plane cell edges", fontsize=11, loc="left", pad=5, color="#292925")

    # Patch coordinates below are computed from native boundary face point IDs.
    labels = {
        "gasInlet": (-2.38, -0.62),
        "downstreamOutlet": (17.32, -0.62),
        "bottomOutlet": (8.2, -9.72),
        "aircraftWall": (8.2, -0.27),
    }
    for patch, text_xy in labels.items():
        b = patch_info[patch]["bounds_m"]
        if patch in ("gasInlet", "downstreamOutlet"):
            coord = 0.5 * (b["x"][0] + b["x"][1])
            xy = (coord, -0.05)
            align = "left" if patch == "gasInlet" else "right"
        elif patch == "bottomOutlet":
            coord = 0.5 * (b["y"][0] + b["y"][1])
            xy = (0.5 * (b["x"][0] + b["x"][1]), coord)
            align = "center"
        else:
            coord = 0.5 * (b["y"][0] + b["y"][1])
            xy = (0.5 * (b["x"][0] + b["x"][1]), coord)
            align = "center"
        if patch in ("gasInlet", "downstreamOutlet"):
            patch_label = f"{patch}  x={coord:.1f} m"
        elif patch == "bottomOutlet":
            patch_label = f"bottomOutlet  y={coord:.1f} m"
        else:
            patch_label = "aircraftWall  y=0 m (flat)"
        overview.annotate(
            patch_label,
            xy=xy,
            xytext=text_xy,
            textcoords="data",
            fontsize=7.5,
            color="#555550",
            ha=align,
            va="center",
            arrowprops={"arrowstyle": "-", "color": "#70706a", "lw": 0.65},
            bbox={"boxstyle": "round,pad=0.12", "fc": "#fffdf8", "ec": "none", "alpha": 0.9},
            zorder=5,
        )
    overview.plot([nx], [ny], marker="o", markersize=4, markerfacecolor="#b32326", markeredgecolor="white", zorder=8)
    overview.annotate("nozzle", (nx, ny), xytext=(-32, -13), textcoords="offset points", fontsize=8, color="#932025", zorder=9)

    # These amber centerlines are the assumed source-inspired mesh refinement
    # guide; the tail beyond x=1.95 m is extrapolated, not measured geometry.
    guide_color = "#bd791d"
    overview.plot([1.95, 6.5], [-2.69, -6.0], color=guide_color, linewidth=0.8, linestyle=(0, (4, 3)), alpha=0.9, zorder=6)
    overview.plot([1.95, 6.5], [-1.89, -5.2], color=guide_color, linewidth=0.8, linestyle=(0, (4, 3)), alpha=0.9, zorder=6)
    overview.plot([1.95, 1.95], [-2.69, -1.89], color=guide_color, linewidth=1.0, linestyle=(0, (2, 2)), zorder=7)
    overview.annotate(
        "assumed refinement corridor\ntail extrapolated after x = 1.95 m",
        xy=(1.95, -2.29),
        xytext=(8.0, -2.0),
        textcoords="data",
        fontsize=7.5,
        color="#865514",
        ha="left",
        va="center",
        bbox={"boxstyle": "round,pad=0.18", "fc": "#fffdf8", "ec": "#d2b074", "lw": 0.5, "alpha": 0.95},
        arrowprops={"arrowstyle": "->", "color": guide_color, "lw": 0.65},
        zorder=9,
    )

    zoom_axes = [
        fig.add_axes([0.075, 0.095, 0.39, 0.31], facecolor="#fffdf8"),
        fig.add_axes([0.535, 0.095, 0.39, 0.31], facecolor="#fffdf8"),
    ]
    titles = ["A  Nozzle near-field", "B  Coarser downstream region"]
    for ax, key, title in zip(zoom_axes, ("fine", "coarse"), titles, strict=True):
        region = rois[key]
        bounds = region["roi_bounds_m"]
        local = segments_in(segments, bounds)
        ax.add_collection(LineCollection(local, colors="#242421", linewidths=0.45, alpha=0.94, rasterized=True))
        ax.set_xlim(*bounds["x"])
        ax.set_ylim(*bounds["y"])
        ax.set_aspect("equal", adjustable="box")
        ax.set_title(
            f"{title}  |  median Δx = {region['median_segment_length_m'] * 1000:.1f} mm",
            fontsize=10,
            loc="left",
            pad=5,
            color="#2a2a26",
        )
        ax.set_xlabel("x (m)", fontsize=8)
        ax.set_ylabel("y (m)", fontsize=8)
        ax.tick_params(labelsize=7.5, length=3, colors="#4d4d48")
        for spine in ax.spines.values():
            spine.set_color("#33332f")
            spine.set_linewidth(0.7)
        if key == "fine":
            ax.plot([nx], [ny], marker="o", markersize=3, markerfacecolor="#b32326", markeredgecolor="white", zorder=6)

        center = region["circle_center_m"]
        radius = region["circle_radius_m"]
        overview.add_patch(Circle(center, radius, fill=False, edgecolor="#bb1e22", linewidth=1.5, zorder=10))
        badge_x = center[0] + radius * 0.73
        badge_y = center[1] + radius * (0.63 if key == "coarse" else -0.70)
        overview.text(
            badge_x,
            badge_y,
            "A" if key == "fine" else "B",
            color="white",
            fontsize=8,
            ha="center",
            va="center",
            bbox={"boxstyle": "circle,pad=0.22", "fc": "#bb1e22", "ec": "white", "lw": 0.5},
            zorder=11,
        )
        fig.add_artist(
            ConnectionPatch(
                xyA=(center[0], center[1] - radius),
                coordsA=overview.transData,
                xyB=(0.5, 1.0),
                coordsB=ax.transAxes,
                color="#bb1e22",
                linewidth=0.8,
                alpha=0.85,
            )
        )

    fine_bounds = rois["fine"]["roi_bounds_m"]
    nozzle_bounds = patch_info["nozzle"]["bounds_m"]
    mouth_span_x = nozzle_bounds["x"][1] - nozzle_bounds["x"][0]
    zoom_axes[0].annotate(
        f"nozzle patch x-span {mouth_span_x:.3f} m at y=0",
        xy=(nozzle_bounds["x"][1], 0.0),
        xytext=(0.02, 0.93),
        textcoords="axes fraction",
        fontsize=7.5,
        color="#8f1c20",
        ha="left",
        va="top",
        bbox={"boxstyle": "round,pad=0.18", "fc": "#fffdf8", "ec": "#c77777", "lw": 0.5, "alpha": 0.95},
        arrowprops={"arrowstyle": "->", "color": "#bb1e22", "lw": 0.65},
    )

    fig.text(
        0.5,
        0.035,
        "Amber dashes: assumed source-inspired refinement corridor, extrapolated after x = 1.95 m. Nominal targets: 14 mm (L3), 56 mm (L1); inset Δx is measured on native z = 0 faces. "
        "No wall-layer extrusion is present in this cast-only mesh.",
        ha="center",
        va="center",
        fontsize=8.3,
        color="#555550",
    )
    png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(png, dpi=260, facecolor=fig.get_facecolor())
    fig.savefig(pdf, dpi=260, facecolor=fig.get_facecolor())
    plt.close(fig)
    return {
        "png": {"path": str(png), "sha256": sha256(png), "bytes": png.stat().st_size, "dpi": 260},
        "pdf": {"path": str(pdf), "sha256": sha256(pdf), "bytes": pdf.stat().st_size, "rasterized_mesh_edges": True},
        "backend": "Matplotlib Agg CPU; ParaView Render and OpenGL not invoked",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--probe-only", action="store_true")
    parser.add_argument("--probe-json", type=Path, default=RUN / "staging/mesh-cut-probe.json")
    args = parser.parse_args()
    if not CASE_MARKER.is_file() or not GEOMETRY.is_file() or not GEOMETRY_RECEIPT.is_file():
        raise FileNotFoundError("qualified mesh marker and geometry cache are required")
    geometry_receipt = json.loads(GEOMETRY_RECEIPT.read_text(encoding="utf-8"))
    if geometry_receipt.get("cells") != EXPECTED_CELLS:
        raise RuntimeError("geometry receipt does not match the qualified fine mesh cell count")
    source_hashes = {name: sha256(MESH / name) for name in ("points", "faces", "owner", "neighbour", "boundary")}
    sys.path.insert(0, str(REPO / "results/runs/rouaix-fine-water-view-20261028"))
    fine_view = importlib.import_module("render_fine_water_view")
    with np.load(GEOMETRY) as geometry:
        centres = geometry["centres_m"].copy()
        volumes = geometry["volumes_m3"].copy()
    started = time.monotonic()
    reader, grid, cell_order = fine_view.read_native_grid(centres, volumes)
    segments, cut_receipt, face_data = native_z0_faces(MESH)
    patches = patch_bounds(MESH)
    rows = bin_spacing_table(segments)
    nozzle = patches["nozzle"]["bounds_m"]
    nozzle_centre = [(nozzle["x"][0] + nozzle["x"][1]) / 2.0, (nozzle["y"][0] + nozzle["y"][1]) / 2.0]
    fine = choose_candidate(rows, NOMINAL_FINE_M, near=tuple(nozzle_centre))
    fine_center = [sum(fine["x_bounds_m"]) / 2.0, sum(fine["y_bounds_m"]) / 2.0]
    coarse = choose_candidate(rows, NOMINAL_COARSE_M, avoid=(*fine["x_bounds_m"], *fine["y_bounds_m"]))
    coarse_center = [sum(coarse["x_bounds_m"]) / 2.0, sum(coarse["y_bounds_m"]) / 2.0]
    receipt = {
        "schema_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_mesh": str(MESH),
        "source_mesh_files_sha256": source_hashes,
        "geometry_cache": {"path": str(GEOMETRY), "sha256": sha256(GEOMETRY), "receipt_sha256": sha256(GEOMETRY_RECEIPT)},
        "mesh_cells": EXPECTED_CELLS,
        "native_reader_cell_order_check": cell_order,
        "cut": cut_receipt,
        "patch_bounds": patches,
        "nozzle_centre_x_y_m": nozzle_centre,
        "nominal_refinement_spacing_m": {"L3_fine": NOMINAL_FINE_M, "L1_medium": NOMINAL_COARSE_M},
        "spacing_grid_tile_m": 0.5,
        "spacing_grid_rows": rows,
        "selected_spacing_windows": {"fine": fine, "coarse": coarse},
        "probe_processing": {"elapsed_s": round(time.monotonic() - started, 2), "peak_rss_gib": peak_rss_gib()},
    }
    if args.probe_only:
        args.probe_json.parent.mkdir(parents=True, exist_ok=True)
        args.probe_json.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(receipt, indent=2), flush=True)
        return

    # Equal-width windows make the 14/56 mm edge-density contrast readable.
    fine_bounds = {"x": [nozzle_centre[0] - 0.4, nozzle_centre[0] + 0.4], "y": [nozzle_centre[1] - 0.8, nozzle_centre[1]]}
    # Use the actual selected 0.5 m square for coarse so its reported median
    # describes exactly the shown ROI; the fine view stays nozzle-centred.
    coarse_bounds = {"x": coarse["x_bounds_m"], "y": coarse["y_bounds_m"]}
    zoom_regions = {
        "fine": {**spacing_stats(segments, fine_bounds), "native_face_metrics": native_face_region_metrics(face_data, segments, fine_bounds), "circle_center_m": [nozzle_centre[0], nozzle_centre[1] - 0.4], "circle_radius_m": 0.44, "measured_tile": fine},
        "coarse": {**spacing_stats(segments, coarse_bounds), "native_face_metrics": native_face_region_metrics(face_data, segments, coarse_bounds), "circle_center_m": coarse_center, "circle_radius_m": 0.50, "measured_tile": coarse},
    }
    receipt["zoom_regions"] = zoom_regions
    figure_paths = {
        "png": SUMMARY / "rouaix-mesh-z0-plate.png",
        "pdf": SUMMARY / "rouaix-mesh-z0-plate.pdf",
    }
    receipt["figure"] = figure(segments, patches, receipt, figure_paths["png"], figure_paths["pdf"])
    receipt["processing"] = {
        "elapsed_s": round(time.monotonic() - started, 2),
        "peak_rss_gib": peak_rss_gib(),
        "reader": "ParaView OpenFOAMReader on exact reconstructed internalMesh; cell centres/volumes verified against cached native order",
        "cut_method": "native internal polyMesh faces whose vertex z coordinates are all within 1e-12 m of zero; unique in-plane edges deduplicated by native point-label pairs",
        "render": "Matplotlib Agg CPU; mesh line collections rasterized for manageable PDF; no field or geometry edits",
    }
    receipt["spacing_selection_method"] = (
        "0.5 m x 0.5 m bins of unique exact z=0 native internal-face edges; choose the nearest nozzle tile "
        "with median near nominal 14 mm and a non-overlapping downstream tile near nominal 56 mm. "
        "Full bin table is retained only in the ignored probe receipt."
    )
    receipt["cut_validation"] = {
        "audit_path": "results/summaries/rouaix_mesh_plate_20261028/native-z0-face-audit.json",
        "audit_sha256": sha256(SUMMARY / "native-z0-face-audit.json"),
        "vtk_cutter_z0_audit_path": "results/summaries/rouaix_mesh_plate_20261028/vtk-cutter-z0-audit.json",
        "vtk_cutter_z0_audit_sha256": sha256(SUMMARY / "vtk-cutter-z0-audit.json"),
        "vtk_cutter_offset_comparison_path": "results/summaries/rouaix_mesh_plate_20261028/vtk-cutter-offset-comparison.json",
        "vtk_cutter_offset_comparison_sha256": sha256(SUMMARY / "vtk-cutter-offset-comparison.json"),
        "interpretation": "The initially rendered vtkCutter z=0 attempt was superseded after direct binary face audit showed z=0 is an exact internal-face plane; the final plate uses the native face polygons directly.",
    }
    receipt["assumed_refinement_guide_overlay"] = {
        "guide_segments_xy_m": [
            [[1.95, -2.69], [6.5, -6.0]],
            [[1.95, -1.89], [6.5, -5.2]],
        ],
        "tail_extrapolation_start_x_m": 1.95,
        "interpretation": "source-inspired assumed refinement guide only; not measured device geometry or a computed liquid plume",
    }
    receipt.pop("spacing_grid_rows")
    out_json = SUMMARY / "mesh-plate-provenance.json"
    out_json.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2), flush=True)
    del grid, reader, segments, face_data
    gc.collect()


if __name__ == "__main__":
    main()
