#!/usr/bin/env pvpython
"""Compare a few ParaView reconstructed cells with raw native polyMesh faces."""

from __future__ import annotations

import hashlib
import json
import mmap
import re
import resource
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

import numpy as np
from paraview import servermanager
from paraview.simple import Delete, OpenFOAMReader
from vtk.util.numpy_support import vtk_to_numpy

ROOT = Path(__file__).resolve().parents[3]
RUN = ROOT / "results/runs/rouaix-mesh-plate-20261028"
SUMMARY = ROOT / "results/summaries/rouaix_mesh_plate_20261028"
SOURCE_CASE = ROOT / "results/runs/rouaix-matched-mesh-mac-20261025/final-cast-only-transfer-core"
MESH = SOURCE_CASE / "constant/polyMesh"
ALPHA_NPZ = RUN / "staging/global-alpha-t0215.npz"
GEOMETRY_NPZ = ROOT / "results/runs/rouaix-fine-water-view-20261028/staging/native-cell-centres-volumes.npz"
OUTPUT = SUMMARY / "vtk-native-cell-identity-crosscheck.json"
EXPECTED_CELLS = 10_099_265
VTK_HEXAHEDRON = 12
VTK_POLYHEDRON = 42


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def peak_rss_gib() -> float:
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    scale = 1024**3 if Path("/System/Library").exists() else 1024**2
    return float(value / scale)


def binary_list_header(path: Path) -> tuple[int, int]:
    with path.open("rb") as stream:
        header = stream.read(8192)
    end = header.find(b"\n}\n")
    if end < 0:
        raise ValueError(f"OpenFOAM binary header not found: {path}")
    match = re.search(rb"(?m)^(\d+)\n\(", header[end + 3 :])
    if match is None:
        raise ValueError(f"OpenFOAM binary list header not found: {path}")
    return int(match.group(1)), end + 3 + match.end()


def vtk_blocks(data: Any) -> Iterator[Any]:
    if data.IsA("vtkCompositeDataSet"):
        iterator = data.NewIterator()
        iterator.SkipEmptyNodesOn()
        iterator.InitTraversal()
        while not iterator.IsDoneWithTraversal():
            item = iterator.GetCurrentDataObject()
            if item is not None:
                yield from vtk_blocks(item)
            iterator.GoToNextItem()
    else:
        yield data


def point_xyz(poly: Any, local_point_id: int) -> np.ndarray:
    return np.asarray(poly.GetPoint(local_point_id), dtype=np.float64)


def ordered_face_volume(
    points: np.ndarray,
    face_point_ids: list[int],
    reverse: bool,
    reference_point: np.ndarray,
) -> float:
    ids = face_point_ids[::-1] if reverse else face_point_ids
    q = points[np.asarray(ids, dtype=np.int64)] - reference_point
    total = 0.0
    for index in range(1, len(q) - 1):
        total += float(np.dot(q[0], np.cross(q[index], q[index + 1]))) / 6.0
    return total


def main() -> None:
    started = time.monotonic()
    if OUTPUT.exists():
        raise FileExistsError(f"refusing to overwrite {OUTPUT}")
    for path in (MESH / "points", MESH / "faces", MESH / "owner", MESH / "neighbour", ALPHA_NPZ, GEOMETRY_NPZ):
        if not path.is_file():
            raise FileNotFoundError(path)

    points_path, faces_path = MESH / "points", MESH / "faces"
    owner_path, neighbour_path = MESH / "owner", MESH / "neighbour"
    n_points, points_start = binary_list_header(points_path)
    n_offsets, offsets_start = binary_list_header(faces_path)
    n_owner, owner_start = binary_list_header(owner_path)
    n_internal, neighbour_start = binary_list_header(neighbour_path)
    if n_owner != n_offsets - 1 or n_internal >= n_owner:
        raise ValueError("native face, owner and neighbour counts disagree")

    alpha = np.load(ALPHA_NPZ)["alpha_water_global"]
    if alpha.shape != (EXPECTED_CELLS,):
        raise ValueError(f"mapped alpha has unexpected shape {alpha.shape}")
    geometry = np.load(GEOMETRY_NPZ)
    centres = geometry["centres_m"]
    volumes = geometry["volumes_m3"]
    if centres.shape != (EXPECTED_CELLS, 3) or volumes.shape != (EXPECTED_CELLS,):
        raise ValueError("cached cell geometry has unexpected shapes")

    print(json.dumps({"stage": "reader_start", "utc": datetime.now(timezone.utc).isoformat(), "cells_expected": EXPECTED_CELLS, "peak_rss_gib": peak_rss_gib()}), flush=True)
    reader = OpenFOAMReader(registrationName="Rouaix native mesh cell identity audit", FileName=str(SOURCE_CASE / "case.foam"))
    reader.CaseType = "Reconstructed Case"
    reader.SkipZeroTime = 0
    reader.MeshRegions = ["internalMesh"]
    reader.CellArrays = []
    reader.UpdatePipeline(time=0.0)
    if int(reader.GetDataInformation().GetNumberOfCells()) != EXPECTED_CELLS:
        raise RuntimeError("ParaView native mesh cell count does not match expected mesh")
    data = servermanager.Fetch(reader)
    parts = list(vtk_blocks(data))
    part_ranges = []
    cursor = 0
    part_type_arrays = []
    for part_index, part in enumerate(parts):
        count = int(part.GetNumberOfCells())
        if count:
            cell_types = part.GetCellTypesArray()
            if cell_types is None:
                raise RuntimeError(f"VTK block {part_index} has no cell type array")
            type_values = vtk_to_numpy(cell_types)
            if len(type_values) != count:
                raise RuntimeError(f"VTK block {part_index} cell type count mismatch")
            part_type_arrays.append(type_values)
            part_ranges.append({"block": part_index, "first_global_index": cursor, "cell_count": count, "last_global_index": cursor + count - 1, "vtk_class": part.GetClassName(), "point_count": int(part.GetNumberOfPoints())})
            cursor += count
        else:
            part_ranges.append({"block": part_index, "first_global_index": cursor, "cell_count": 0, "last_global_index": None, "vtk_class": part.GetClassName(), "point_count": int(part.GetNumberOfPoints())})
    if cursor != EXPECTED_CELLS:
        raise RuntimeError(f"flattened VTK cell count {cursor} does not match {EXPECTED_CELLS}")
    types = np.concatenate(part_type_arrays) if len(part_type_arrays) > 1 else part_type_arrays[0]
    if len(types) != EXPECTED_CELLS:
        raise RuntimeError("flattened VTK cell type order count mismatch")

    # Select the wettest representative in each expected VTK class, plus the parent's fixed cell ID.
    wet = alpha >= 0.5
    requested: dict[str, int] = {"suspect_cell_587633": 587_633}
    for label, vtk_type in (("wet_hexahedron", VTK_HEXAHEDRON), ("wet_polyhedron", VTK_POLYHEDRON)):
        candidates = np.flatnonzero(wet & (types == vtk_type))
        if not len(candidates):
            raise RuntimeError(f"no alpha>=0.5 VTK cells of requested type {vtk_type}")
        requested[label] = int(candidates[np.argmax(alpha[candidates])])
    target_ids = list(dict.fromkeys(requested.values()))
    print(json.dumps({"stage": "targets_selected", "targets": requested, "target_alpha": {key: float(alpha[value]) for key, value in requested.items()}, "parts": part_ranges, "elapsed_s": round(time.monotonic() - started, 2), "peak_rss_gib": peak_rss_gib()}), flush=True)

    with points_path.open("rb") as point_stream, faces_path.open("rb") as face_stream, owner_path.open("rb") as owner_stream, neighbour_path.open("rb") as neighbour_stream:
        points_map = mmap.mmap(point_stream.fileno(), 0, access=mmap.ACCESS_READ)
        faces_map = mmap.mmap(face_stream.fileno(), 0, access=mmap.ACCESS_READ)
        owner_map = mmap.mmap(owner_stream.fileno(), 0, access=mmap.ACCESS_READ)
        neighbour_map = mmap.mmap(neighbour_stream.fileno(), 0, access=mmap.ACCESS_READ)
        try:
            native_points = np.ndarray((n_points, 3), dtype="<f8", buffer=points_map, offset=points_start)
            offsets = np.ndarray((n_offsets,), dtype="<i4", buffer=faces_map, offset=offsets_start)
            after_offsets = offsets_start + n_offsets * 4
            labels_header = re.match(rb"(\d+)\n\(", faces_map[after_offsets + 2 : after_offsets + 64])
            if not labels_header or faces_map[after_offsets : after_offsets + 2] != b")\n":
                raise ValueError("native compact face connectivity header is malformed")
            n_labels = int(labels_header.group(1))
            labels_start = after_offsets + 2 + labels_header.end()
            labels = np.ndarray((n_labels,), dtype="<i4", buffer=faces_map, offset=labels_start)
            owner = np.ndarray((n_owner,), dtype="<i4", buffer=owner_map, offset=owner_start)
            neighbour = np.ndarray((n_internal,), dtype="<i4", buffer=neighbour_map, offset=neighbour_start)
            if int(offsets[-1]) != n_labels:
                raise ValueError("face offsets and connectivity count disagree")

            results: dict[str, dict[str, Any]] = {}
            label_by_cell = {cell_id: label for label, cell_id in requested.items()}
            for cell_id in target_ids:
                face_ids = np.concatenate((np.flatnonzero(owner == cell_id), np.flatnonzero(neighbour == cell_id))).astype(np.int64)
                face_ids.sort()
                if not len(face_ids):
                    raise RuntimeError(f"native cell {cell_id} has no incident faces")
                native_face_point_ids = [labels[int(offsets[fid]) : int(offsets[fid + 1])].astype(np.int64, copy=True) for fid in face_ids]
                native_vertex_ids = np.unique(np.concatenate(native_face_point_ids))
                native_xyz = np.asarray(native_points[native_vertex_ids], dtype=np.float64)
                part_index = next(i for i, part_range in enumerate(part_ranges) if part_range["cell_count"] and part_range["first_global_index"] <= cell_id <= part_range["last_global_index"])
                part = parts[part_index]
                local_cell_id = cell_id - int(part_ranges[part_index]["first_global_index"])
                cell = part.GetCell(local_cell_id)
                vtk_vertex_ids = np.asarray([int(cell.GetPointId(i)) for i in range(cell.GetNumberOfPoints())], dtype=np.int64)
                vtk_point_ids_match_native_labels = set(vtk_vertex_ids.tolist()) == set(native_vertex_ids.tolist())
                sorted_native_ids = np.sort(native_vertex_ids)
                vtk_xyz_by_point_id = np.asarray([point_xyz(part, int(pid)) for pid in sorted_native_ids], dtype=np.float64)
                native_xyz_by_point_id = np.asarray(native_points[sorted_native_ids], dtype=np.float64)
                coordinate_deltas = np.abs(vtk_xyz_by_point_id - native_xyz_by_point_id)
                max_vertex_coordinate_delta_m = float(coordinate_deltas.max(initial=0.0))
                vtk_bounds = np.asarray(cell.GetBounds(), dtype=np.float64).reshape(3, 2)
                native_bounds = np.stack((native_xyz.min(axis=0), native_xyz.max(axis=0)), axis=1)

                # Compare each VTK face against one native incident face by vertex coordinates.
                native_face_keys = []
                for face_point_ids in native_face_point_ids:
                    native_face_keys.append(tuple(sorted(int(point_id) for point_id in face_point_ids)))
                matched_native_faces: set[int] = set()
                vtk_face_matches = []
                for vtk_face_index in range(cell.GetNumberOfFaces()):
                    vtk_face = cell.GetFace(vtk_face_index)
                    key = tuple(sorted(int(vtk_face.GetPointId(j)) for j in range(vtk_face.GetNumberOfPoints())))
                    match = next((i for i, native_key in enumerate(native_face_keys) if i not in matched_native_faces and native_key == key), None)
                    vtk_face_matches.append(match is not None)
                    if match is not None:
                        matched_native_faces.add(match)

                reference_point = native_xyz.mean(axis=0)
                signed_volume = 0.0
                for face_id, face_point_ids in zip(face_ids, native_face_point_ids, strict=True):
                    reverse = int(neighbour[face_id]) == cell_id
                    signed_volume += ordered_face_volume(native_points, face_point_ids.tolist(), reverse, reference_point)
                vtk_type = int(types[cell_id])
                results[label_by_cell[cell_id]] = {
                    "assumed_global_cell_id_from_paraView_order": cell_id,
                    "native_face_owner_neighbour_incidence": {
                        "face_count": int(len(face_ids)),
                        "owner_face_count": int(np.count_nonzero(owner[face_ids] == cell_id)),
                        "neighbour_face_count": int(np.count_nonzero(neighbour[face_ids] == cell_id)),
                        "native_point_count": int(len(native_vertex_ids)),
                    },
                    "vtk_cell": {
                        "vtk_type_id": vtk_type,
                        "vtk_classification": "hexahedron" if vtk_type == VTK_HEXAHEDRON else "polyhedron" if vtk_type == VTK_POLYHEDRON else f"vtk_type_{vtk_type}",
                        "point_count": int(cell.GetNumberOfPoints()),
                        "face_count": int(cell.GetNumberOfFaces()),
                        "bounds_m": {axis: [float(vtk_bounds[i, 0]), float(vtk_bounds[i, 1])] for i, axis in enumerate(("x", "y", "z"))},
                        "coordinates_array_type": part.GetPoints().GetData().GetDataTypeAsString(),
                    },
                    "native_face_union": {
                        "bounds_m": {axis: [float(native_bounds[i, 0]), float(native_bounds[i, 1])] for i, axis in enumerate(("x", "y", "z"))},
                    "raw_oriented_face_volume_m3": float(signed_volume),
                    },
                    "cached_reader_order_geometry": {
                        "centre_m": [float(v) for v in centres[cell_id]],
                        "cell_size_volume_m3": float(volumes[cell_id]),
                    },
                    "mapped_alpha_water_t0215": float(alpha[cell_id]),
                    "comparisons": {
                        "vtk_point_ids_equal_native_global_point_labels": bool(vtk_point_ids_match_native_labels),
                        "max_abs_vtk_vs_native_vertex_coordinate_delta_m": max_vertex_coordinate_delta_m,
                        "vtk_point_coordinates_match_native_global_point_order_5e_7m": bool(max_vertex_coordinate_delta_m <= 5e-7),
                        "max_abs_vtk_vs_native_bounds_delta_m": float(np.abs(vtk_bounds - native_bounds).max()),
                        "vtk_bounds_match_native_face_union_5e_7m": bool(np.allclose(vtk_bounds, native_bounds, rtol=0.0, atol=5e-7)),
                        "vtk_face_count_matches_native_incident_face_count": bool(cell.GetNumberOfFaces() == len(face_ids)),
                        "vtk_faces_match_native_face_coordinate_sets": bool(len(vtk_face_matches) == len(face_ids) and all(vtk_face_matches) and len(matched_native_faces) == len(face_ids)),
                        "raw_vs_cached_volume_relative_delta": float(abs(abs(signed_volume) - volumes[cell_id]) / volumes[cell_id]),
                        "raw_native_volume_matches_cached_reader_volume_rel_2e_5": bool(np.isclose(abs(signed_volume), volumes[cell_id], rtol=2e-5, atol=1e-15)),
                        "vtk_cell_order_matches_native_cell_id_for_sample": bool(vtk_point_ids_match_native_labels and max_vertex_coordinate_delta_m <= 5e-7 and np.allclose(vtk_bounds, native_bounds, rtol=0.0, atol=5e-7) and len(matched_native_faces) == len(face_ids)),
                    },
                }
            # Verify VTK point IDs preserve the native global point-coordinate ordering for every audited label.
            global_point_samples = set()
            for cell_id in target_ids:
                global_point_samples.update(int(pid) for face_id in np.concatenate((np.flatnonzero(owner == cell_id), np.flatnonzero(neighbour == cell_id))) for pid in labels[int(offsets[face_id]) : int(offsets[face_id + 1])])
            point_order_checks = []
            point_order_deltas = []
            for point_id in sorted(global_point_samples):
                part_index = next(i for i, block in enumerate(part_ranges) if block["point_count"] > point_id)
                vtk_coordinate = point_xyz(parts[part_index], point_id)
                native_coordinate = np.asarray(native_points[point_id], dtype=np.float64)
                delta = float(np.abs(vtk_coordinate - native_coordinate).max())
                point_order_deltas.append(delta)
                point_order_checks.append(bool(delta <= 5e-7))
            # Include fixed global point IDs to guard against a coincident local-only match.
            fixed_ids = sorted({0, 1, n_points // 2, n_points - 1})
            fixed_order_checks = []
            fixed_order_deltas = []
            for point_id in fixed_ids:
                part_index = next((i for i, block in enumerate(part_ranges) if block["point_count"] > point_id), None)
                if part_index is None:
                    fixed_order_checks.append(False)
                    fixed_order_deltas.append(None)
                else:
                    delta = float(np.abs(point_xyz(parts[part_index], point_id) - native_points[point_id]).max())
                    fixed_order_deltas.append(delta)
                    fixed_order_checks.append(bool(delta <= 5e-7))
        finally:
            del labels, offsets, native_points, owner, neighbour
            neighbour_map.close()
            owner_map.close()
            faces_map.close()
            points_map.close()

    checks = [item["comparisons"] for item in results.values()]
    passed = all(
        value
        for item in checks
        for key, value in item.items()
        if key not in ("raw_native_volume_matches_cached_reader_volume_rel_2e_5", "raw_vs_cached_volume_relative_delta", "max_abs_vtk_vs_native_vertex_coordinate_delta_m", "max_abs_vtk_vs_native_bounds_delta_m")
    ) and all(item["comparisons"]["raw_native_volume_matches_cached_reader_volume_rel_2e_5"] for item in results.values()) and all(point_order_checks) and all(fixed_order_checks)
    receipt = {
        "schema_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "read-only representative-cell check of ParaView reconstructed internalMesh ordering and geometry against raw binary native polyMesh points/faces/owner/neighbour",
        "source_mesh": str(MESH),
        "source_case_marker": str(SOURCE_CASE / "case.foam"),
        "source_mesh_hashes": {name: sha256(MESH / name) for name in ("points", "faces", "owner", "neighbour")},
        "mapped_alpha_npz": {"path": str(ALPHA_NPZ), "sha256": sha256(ALPHA_NPZ), "time_s": 0.215, "field_mapping_receipt": str(RUN / "staging/global-alpha-t0215.json")},
        "native_cell_geometry_cache": {"path": str(GEOMETRY_NPZ), "sha256": sha256(GEOMETRY_NPZ), "cells": EXPECTED_CELLS},
        "paraView": {
            "reader": "OpenFOAMReader, Reconstructed Case, internalMesh, at time 0 geometry",
            "reader_cell_count": int(cursor),
            "reader_point_count_by_block": [int(part.GetNumberOfPoints()) for part in parts],
            "cell_order_assumption_under_test": "flatten nonempty composite blocks in iterator order; preserve cell order within each block; map flattened index to native global cell ID",
            "blocks": part_ranges,
        },
        "targets": results,
        "point_order_check": {
            "audited_native_point_ids_checked": len(point_order_checks),
            "audited_point_id_coordinates_match_native_order_5e_7m": bool(all(point_order_checks)),
            "max_audited_point_coordinate_delta_m": max(point_order_deltas, default=0.0),
            "fixed_global_point_ids": fixed_ids,
            "fixed_global_point_max_abs_coordinate_deltas_m": fixed_order_deltas,
            "fixed_global_point_coordinates_match_native_order_5e_7m": bool(all(fixed_order_checks)),
        },
        "all_geometry_and_order_checks_passed": bool(passed),
        "elapsed_s": round(time.monotonic() - started, 2),
        "peak_rss_gib": peak_rss_gib(),
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    Delete(reader)
    print(
        json.dumps(
            {
                "stage": "complete",
                "summary": {
                    "all_geometry_and_order_checks_passed": passed,
                    "targets": {
                        label: {
                            "cell_id": item["assumed_global_cell_id_from_paraView_order"],
                            "alpha": item["mapped_alpha_water_t0215"],
                            "comparisons": item["comparisons"],
                        }
                        for label, item in results.items()
                    },
                    "elapsed_s": receipt["elapsed_s"],
                    "peak_rss_gib": receipt["peak_rss_gib"],
                    "output": str(OUTPUT),
                },
            },
            indent=2,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
