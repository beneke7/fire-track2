#!/usr/bin/env pvpython
"""Extract fine native-cell centres and volumes with bounded ParaView CPU work."""

from __future__ import annotations

import gc
import hashlib
import json
import resource
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
from paraview import servermanager
from paraview.simple import CellCenters, CellSize, Delete, OpenFOAMReader
from vtk.util.numpy_support import vtk_to_numpy

REPO = Path(__file__).resolve().parents[3]
RUN = REPO / "results/runs/rouaix-fine-water-view-20261028"
SOURCE = REPO / "results/runs/rouaix-matched-mesh-mac-20261025/final-cast-only-transfer-core"
CASE_MARKER = SOURCE / "case.foam"
EXPECTED_CELLS = 10_099_265
REMOTE_MESH_MANIFEST_SHA256 = "4347c663a52b3dda878f0b32d60b4ff485a767417b784e89145c6adc0298d670"
REMOTE_MESH_SHA256 = {
    "boundary": "574392c950271c8c4c1d389bd4ca0e1424bb54a309030f57743405766d32e779",
    "faces": "189d7c0e976e7d59d00b1397209d79feec3499098b304c9c5d9c327f3462d160",
    "neighbour": "4ed021ba510f6800b7c90e90e80783cccbb1e1e5b5c9ec2a565e9e4031d661fc",
    "owner": "05a61c7b0780d1aee5d8258612b69b10263097d2f60a7dbaeb3b1ae8135d47bb",
    "points": "60fe45a13019eb5904ac21ca5ddd6c97ac581025a6d62dee91b5e8c01155298d",
}
OUTPUT_NPZ = RUN / "staging/native-cell-centres-volumes.npz"
OUTPUT_JSON = RUN / "staging/native-cell-centres-volumes.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def blocks(data: Any):
    if data.IsA("vtkCompositeDataSet"):
        iterator = data.NewIterator()
        iterator.SkipEmptyNodesOn()
        iterator.InitTraversal()
        while not iterator.IsDoneWithTraversal():
            item = iterator.GetCurrentDataObject()
            if item is not None:
                yield from blocks(item)
            iterator.GoToNextItem()
    else:
        yield data


def peak_rss_gib() -> float:
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    # Darwin reports bytes; Linux reports KiB.
    scale = 1024**3 if Path("/System/Library").exists() else 1024**2
    return float(value / scale)


def collect_arrays(data: Any, kind: str) -> list[np.ndarray]:
    output = []
    for part in blocks(data):
        if kind == "centres":
            if part.GetNumberOfPoints():
                output.append(vtk_to_numpy(part.GetPoints().GetData()))
        else:
            if part.GetNumberOfCells():
                array = part.GetCellData().GetArray("Volume")
                if array is None:
                    raise RuntimeError("CellSize filter output is missing the Volume array")
                output.append(vtk_to_numpy(array))
    if not output:
        raise RuntimeError(f"ParaView returned no {kind} arrays")
    return output


def main() -> None:
    if OUTPUT_NPZ.exists() or OUTPUT_JSON.exists():
        raise FileExistsError("refusing to overwrite fine native-cell geometry evidence")
    if not CASE_MARKER.is_file():
        raise FileNotFoundError(CASE_MARKER)
    sums = {}
    for line in (SOURCE / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, name = line.split(maxsplit=1)
        sums[name.strip()] = digest
    if sums != REMOTE_MESH_SHA256:
        raise RuntimeError("local donor mesh hashes do not match the active source input manifest")

    started_utc = datetime.now(timezone.utc).isoformat()
    started = time.monotonic()
    print(
        json.dumps(
            {
                "stage": "reader_start",
                "utc": started_utc,
                "expected_cells": EXPECTED_CELLS,
                "peak_rss_gib": peak_rss_gib(),
            }
        ),
        flush=True,
    )
    reader = OpenFOAMReader(
        registrationName="Rouaix fine native mesh",
        FileName=str(CASE_MARKER),
    )
    reader.CaseType = "Reconstructed Case"
    reader.SkipZeroTime = 0
    reader.MeshRegions = ["internalMesh"]
    reader.CellArrays = []
    reader.UpdatePipeline(time=0.0)
    reader_cells = int(reader.GetDataInformation().GetNumberOfCells())
    if reader_cells != EXPECTED_CELLS:
        raise RuntimeError(
            f"native reader cell count {reader_cells} does not match {EXPECTED_CELLS}"
        )

    centres_filter = CellCenters(
        registrationName="Rouaix fine native cell centres",
        Input=reader,
    )
    centres_filter.VertexCells = 0
    centres_filter.UpdatePipeline(time=0.0)
    centres_data = servermanager.Fetch(centres_filter)
    centres_parts = collect_arrays(centres_data, "centres")
    if len(centres_parts) == 1:
        centres = centres_parts[0].copy()
    else:
        centres = np.concatenate(centres_parts, axis=0)
    if centres.shape != (EXPECTED_CELLS, 3):
        raise RuntimeError(f"unexpected centre-array shape {centres.shape}")
    if not np.isfinite(centres).all():
        raise RuntimeError("native cell centres contain non-finite values")
    print(
        json.dumps(
            {
                "stage": "centres_fetched",
                "cells": len(centres),
                "elapsed_s": round(time.monotonic() - started, 2),
                "peak_rss_gib": peak_rss_gib(),
            }
        ),
        flush=True,
    )
    del centres_data, centres_parts
    Delete(centres_filter)
    del centres_filter
    gc.collect()

    size_filter = CellSize(
        registrationName="Rouaix fine native cell volumes",
        Input=reader,
    )
    size_filter.ComputeArea = 0
    size_filter.ComputeLength = 0
    size_filter.ComputeVertexCount = 0
    size_filter.ComputeVolume = 1
    size_filter.UpdatePipeline(time=0.0)
    volume_data = servermanager.Fetch(size_filter)
    volume_parts = collect_arrays(volume_data, "volumes")
    if len(volume_parts) == 1:
        volumes = volume_parts[0].copy()
    else:
        volumes = np.concatenate(volume_parts, axis=0)
    if volumes.shape != (EXPECTED_CELLS,):
        raise RuntimeError(f"unexpected cell-volume shape {volumes.shape}")
    if not np.isfinite(volumes).all() or np.any(volumes <= 0.0):
        raise RuntimeError("native mesh contains non-finite or non-positive cell volumes")
    if len(centres) != len(volumes):
        raise RuntimeError("cell centre and volume counts do not agree")

    del volume_data, volume_parts
    Delete(size_filter)
    Delete(reader)
    del size_filter, reader
    gc.collect()
    OUTPUT_NPZ.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(OUTPUT_NPZ, centres_m=centres, volumes_m3=volumes)
    bounds = [
        float(centres[:, 0].min()),
        float(centres[:, 0].max()),
        float(centres[:, 1].min()),
        float(centres[:, 1].max()),
        float(centres[:, 2].min()),
        float(centres[:, 2].max()),
    ]
    receipt = {
        "schema_version": 1,
        "created_utc": started_utc,
        "source_mesh_case": str(CASE_MARKER),
        "source_mesh_manifest_sha256": REMOTE_MESH_MANIFEST_SHA256,
        "source_mesh_file_hashes": sums,
        "source_mesh_hashes_match_active_case_inputs": True,
        "reader": "ParaView OpenFOAMReader, Reconstructed Case, internalMesh",
        "reader_cells": reader_cells,
        "cell_centre_volume_order": (
            "ParaView reconstructed internalMesh cell order; expected to match native "
            "global cell IDs and to be checked against the mapped .25 alpha-water ledger."
        ),
        "cells": len(volumes),
        "bounds_cell_centres_m": bounds,
        "domain_volume_m3": float(volumes.sum()),
        "cell_volume_min_m3": float(volumes.min()),
        "cell_volume_max_m3": float(volumes.max()),
        "elapsed_s": round(time.monotonic() - started, 2),
        "peak_rss_gib": peak_rss_gib(),
        "npz": {
            "path": str(OUTPUT_NPZ),
            "sha256": sha256(OUTPUT_NPZ),
            "bytes": OUTPUT_NPZ.stat().st_size,
        },
    }
    OUTPUT_JSON.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"stage": "complete", **receipt}, indent=2), flush=True)


if __name__ == "__main__":
    main()
