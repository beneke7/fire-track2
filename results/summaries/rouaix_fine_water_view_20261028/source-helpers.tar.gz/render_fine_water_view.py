#!/usr/bin/env pvpython
"""Summarize and CPU-project native-cell alpha.water threshold surfaces."""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import os
import resource
import time
from datetime import datetime, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.collections import PolyCollection
from paraview import servermanager
from paraview.simple import (
    AssignViewToLayout,
    CreateLayout,
    CreateView,
    OpenFOAMReader,
    SaveState,
    Show,
    XMLPolyDataReader,
)
from vtk import (
    VTK_DOUBLE,
    vtkAppendFilter,
    vtkCellCenters,
    vtkCellSizeFilter,
    vtkDataObject,
    vtkGeometryFilter,
    vtkPolyData,
    vtkThreshold,
    vtkUnstructuredGrid,
    vtkXMLPolyDataWriter,
)
from vtk.util.numpy_support import numpy_to_vtk, vtk_to_numpy

REPO = Path(__file__).resolve().parents[3]
RUN = REPO / "results/runs/rouaix-fine-water-view-20261028"
SUMMARY = REPO / "results/summaries/rouaix_fine_water_view_20261028"
SOURCE_CASE = REPO / "results/runs/rouaix-matched-mesh-mac-20261025/final-cast-only-transfer-core"
PLOT_BOUNDS_M = {"x": [-0.5, 15.5], "y": [-6.2, 0.65]}
ZOOM_BOUNDS_M = {"x": [-0.4, 3.6], "y": [-3.0, 0.35]}
THRESHOLDS = (0.01, 0.1)
EXPECTED_CELLS = 10_099_265


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def blocks(data):
    if data.IsA("vtkCompositeDataSet"):
        iterator = data.NewIterator()
        iterator.SkipEmptyNodesOn()
        iterator.InitTraversal()
        while not iterator.IsDoneWithTraversal():
            item = iterator.GetCurrentDataObject()
            if item is not None:
                yield from blocks(item)
            iterator.GoToNextItem()
    else:
        yield data


def as_unstructured_grid(data) -> vtkUnstructuredGrid:
    parts = [part for part in blocks(data) if part.GetNumberOfCells()]
    if len(parts) == 1 and parts[0].IsA("vtkUnstructuredGrid"):
        return vtkUnstructuredGrid.SafeDownCast(parts[0])
    append = vtkAppendFilter()
    append.MergePointsOff()
    for part in parts:
        append.AddInputData(part)
    append.Update()
    return append.GetOutput()


def peak_rss_gib() -> float:
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    scale = 1024**3 if Path("/System/Library").exists() else 1024**2
    return float(value / scale)


def verify_native_cell_order(
    grid: vtkUnstructuredGrid, expected_centres: np.ndarray, expected_volumes: np.ndarray
) -> dict:
    centre_filter = vtkCellCenters()
    centre_filter.SetInputData(grid)
    centre_filter.Update()
    centres = vtk_to_numpy(centre_filter.GetOutput().GetPoints().GetData())

    size_filter = vtkCellSizeFilter()
    size_filter.SetInputData(grid)
    size_filter.ComputeVertexCountOff()
    size_filter.ComputeLengthOff()
    size_filter.ComputeAreaOff()
    size_filter.ComputeVolumeOn()
    size_filter.Update()
    volumes = vtk_to_numpy(size_filter.GetOutput().GetCellData().GetArray("Volume"))
    if centres.shape != expected_centres.shape or volumes.shape != expected_volumes.shape:
        raise RuntimeError("native mesh reader changed the validated cell inventory")
    centre_error = float(np.max(np.abs(centres - expected_centres)))
    volume_error = float(np.max(np.abs(volumes - expected_volumes)))
    if centre_error > 1e-10 or volume_error > 1e-10:
        raise RuntimeError(
            "native mesh cell order differs from the global alpha/geometry order "
            f"(centre error {centre_error}, volume error {volume_error})"
        )
    return {
        "cells": len(volumes),
        "max_abs_centre_difference_m": centre_error,
        "max_abs_volume_difference_m3": volume_error,
        "volume_sum_m3": float(volumes.sum()),
    }


def read_native_grid(expected_centres: np.ndarray, expected_volumes: np.ndarray):
    if not (SOURCE_CASE / "case.foam").is_file():
        raise FileNotFoundError(SOURCE_CASE / "case.foam")
    reader = OpenFOAMReader(
        registrationName="Fine Rouaix native mesh", FileName=str(SOURCE_CASE / "case.foam")
    )
    reader.CaseType = "Reconstructed Case"
    reader.SkipZeroTime = 0
    reader.MeshRegions = ["internalMesh"]
    reader.CellArrays = []
    reader.UpdatePipeline(time=0.0)
    reader_cells = int(reader.GetDataInformation().GetNumberOfCells())
    if reader_cells != EXPECTED_CELLS:
        raise RuntimeError(f"native mesh reader returned {reader_cells} cells")
    grid = as_unstructured_grid(servermanager.Fetch(reader))
    if grid.GetNumberOfCells() != EXPECTED_CELLS:
        raise RuntimeError(f"flattened native mesh has {grid.GetNumberOfCells()} cells")
    order_receipt = verify_native_cell_order(grid, expected_centres, expected_volumes)
    return reader, grid, order_receipt


def make_threshold_surface(
    grid: vtkUnstructuredGrid, threshold_value: float, destination: Path
) -> tuple[vtkPolyData, dict]:
    threshold = vtkThreshold()
    threshold.SetInputData(grid)
    threshold.SetInputArrayToProcess(0, 0, 0, vtkDataObject.FIELD_ASSOCIATION_CELLS, "alpha.water")
    # THRESHOLD_UPPER selects values >= UpperThreshold without clipping alpha to 1.
    threshold.SetUpperThreshold(threshold_value)
    threshold.SetThresholdFunction(vtkThreshold.THRESHOLD_UPPER)
    threshold.Update()

    geometry = vtkGeometryFilter()
    geometry.SetInputConnection(threshold.GetOutputPort())
    geometry.Update()
    polydata = vtkPolyData.SafeDownCast(geometry.GetOutput())
    if polydata is None or polydata.GetNumberOfPolys() == 0:
        raise RuntimeError(f"native alpha.water >= {threshold_value:g} surface is empty")

    destination.parent.mkdir(parents=True, exist_ok=True)
    writer = vtkXMLPolyDataWriter()
    writer.SetFileName(str(destination))
    writer.SetInputData(polydata)
    writer.SetDataModeToBinary()
    writer.SetCompressorTypeToZLib()
    if writer.Write() != 1:
        raise RuntimeError(f"could not write {destination}")
    receipt = {
        "threshold": threshold_value,
        "threshold_semantics": "native cell alpha.water >= threshold; raw values not clipped",
        "selected_cells": int(threshold.GetOutput().GetNumberOfCells()),
        "surface_points": int(polydata.GetNumberOfPoints()),
        "surface_polygons": int(polydata.GetNumberOfPolys()),
        "path": str(destination),
        "sha256": sha256(destination),
        "bytes": destination.stat().st_size,
    }
    return polydata, receipt


def projected_polygons(polydata: vtkPolyData) -> list[np.ndarray]:
    points = vtk_to_numpy(polydata.GetPoints().GetData())
    polys = polydata.GetPolys()
    offsets = vtk_to_numpy(polys.GetOffsetsArray())
    connectivity = vtk_to_numpy(polys.GetConnectivityArray())
    output = []
    for index in range(len(offsets) - 1):
        point_ids = connectivity[offsets[index] : offsets[index + 1]]
        if len(point_ids) >= 3:
            output.append(points[point_ids, :2].copy())
    return output


def save_pv_state(surface_paths: list[Path], state_path: Path) -> dict:
    readers = []
    absolute_paths = [path.resolve() for path in surface_paths]
    for path in absolute_paths:
        proxy = XMLPolyDataReader(registrationName=path.stem, FileName=[str(path)])
        proxy.UpdatePipeline()
        readers.append(proxy)
    layout = CreateLayout("Rouaix fine water plume")
    view = CreateView("RenderView")
    view.ViewSize = [1200, 1005]
    view.CameraPosition = [1.6, -1.325, 10.0]
    view.CameraFocalPoint = [1.6, -1.325, 0.0]
    view.CameraViewUp = [0.0, 1.0, 0.0]
    view.CameraParallelProjection = 1
    view.CameraParallelScale = 1.675
    view.UseColorPaletteForBackground = 0
    view.Background = [1.0, 1.0, 1.0]
    view.OrientationAxesVisibility = 0
    AssignViewToLayout(view, layout, 0)
    display = Show(readers[0], view)
    display.Representation = "Surface"
    display.ColorArrayName = [None, ""]
    display.DiffuseColor = [0.09, 0.41, 0.67]
    relative_paths = [os.path.relpath(path, state_path.resolve().parent) for path in absolute_paths]
    for proxy, relative_path in zip(readers, relative_paths, strict=True):
        proxy.FileName = [relative_path]
    SaveState(str(state_path))
    return {
        "camera_projection": "parallel, +z view",
        "camera_position_m": list(view.CameraPosition),
        "camera_focal_point_m": list(view.CameraFocalPoint),
        "camera_view_up": list(view.CameraViewUp),
        "camera_parallel_scale_m": float(view.CameraParallelScale),
        "view_size_px": list(view.ViewSize),
        "view_bounds_m": ZOOM_BOUNDS_M,
        "surface_file_names_relative_to_state": relative_paths,
        "visible_surface": surface_paths[0].name,
        "second_threshold_reader_available_but_hidden": surface_paths[1].name,
        "render_invoked": False,
        "screenshot_invoked": False,
    }


def threshold_metrics(
    alpha: np.ndarray,
    centres: np.ndarray,
    volumes: np.ndarray,
    threshold: float,
) -> dict:
    selected = alpha >= threshold
    if not np.any(selected):
        return {
            "threshold": threshold,
            "cell_count": 0,
            "cell_support_volume_m3": 0.0,
            "water_volume_in_selected_cells_m3": 0.0,
            "cell_center_extents_m": None,
            "selected_water_centroid_m": None,
            "cells_inside_plot_bounds": 0,
            "cells_outside_plot_bounds": 0,
        }
    selected_centres = centres[selected]
    selected_volumes = volumes[selected]
    selected_alpha = alpha[selected]
    water_volume = float(np.dot(selected_alpha, selected_volumes))
    water_weights = selected_alpha * selected_volumes
    centroid = np.einsum("i,ij->j", water_weights, selected_centres) / water_volume
    in_view = (
        (selected_centres[:, 0] >= PLOT_BOUNDS_M["x"][0])
        & (selected_centres[:, 0] <= PLOT_BOUNDS_M["x"][1])
        & (selected_centres[:, 1] >= PLOT_BOUNDS_M["y"][0])
        & (selected_centres[:, 1] <= PLOT_BOUNDS_M["y"][1])
    )
    return {
        "threshold": threshold,
        "cell_count": int(selected.sum()),
        "cell_support_volume_m3": float(selected_volumes.sum()),
        "water_volume_in_selected_cells_m3": water_volume,
        "cell_center_extents_m": {
            axis: [
                float(selected_centres[:, index].min()),
                float(selected_centres[:, index].max()),
            ]
            for index, axis in enumerate(("x", "y", "z"))
        },
        "selected_water_centroid_m": [float(value) for value in centroid],
        "cells_inside_plot_bounds": int(in_view.sum()),
        "cells_outside_plot_bounds": int((~in_view).sum()),
        "support_cell_volume_inside_plot_bounds_m3": float(selected_volumes[in_view].sum()),
    }


def nice_ticks(bounds: list[float], target_count: int = 4) -> np.ndarray:
    lower, upper = bounds
    rough_step = (upper - lower) / target_count
    decade = 10 ** math.floor(math.log10(rough_step))
    step = next(
        multiplier * decade
        for multiplier in (1.0, 2.0, 5.0, 10.0)
        if multiplier * decade >= rough_step
    )
    first = math.ceil(lower / step - 1e-12) * step
    last = math.floor(upper / step + 1e-12) * step
    return np.arange(first, last + step * 0.5, step)


def render(
    projected: list[list[np.ndarray]],
    metrics: dict[str, dict],
    time_s: float,
    image_path: Path,
    plot_bounds_m: dict[str, list[float]] = PLOT_BOUNDS_M,
    bounds_label: str = "shared coarse-view bounds",
    figure_title: str | None = None,
) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(16.0, 4.6), constrained_layout=False)
    fig.subplots_adjust(left=0.065, right=0.99, bottom=0.16, top=0.82, wspace=0.18)

    for axis, threshold, polygons in zip(axes, THRESHOLDS, projected, strict=True):
        key = f"alpha_ge_{threshold:g}"
        collection = PolyCollection(
            polygons,
            facecolors="#1769aa",
            edgecolors="none",
            linewidths=0,
            antialiased=False,
            rasterized=True,
        )
        axis.add_collection(collection)
        metric = metrics[key]
        axis.set_xlim(*plot_bounds_m["x"])
        axis.set_ylim(*plot_bounds_m["y"])
        axis.set_aspect("equal", adjustable="box")
        axis.set_xticks(nice_ticks(plot_bounds_m["x"]))
        axis.set_yticks(nice_ticks(plot_bounds_m["y"]))
        axis.tick_params(labelsize=9, length=3, colors="#4b5563")
        axis.grid(True, color="#aeb7c2", linewidth=0.45, alpha=0.35)
        axis.spines["top"].set_visible(False)
        axis.spines["right"].set_visible(False)
        for spine_name in ("left", "bottom"):
            axis.spines[spine_name].set_visible(True)
            axis.spines[spine_name].set_color("#6b7280")
            axis.spines[spine_name].set_linewidth(0.6)
        axis.scatter(
            [0.0],
            [0.0],
            marker="+",
            color="#111827",
            s=55,
            linewidths=1.35,
            zorder=10,
            clip_on=False,
        )
        axis.annotate(
            "nozzle (0, 0)",
            xy=(0.0, 0.0),
            xytext=(7, 7),
            textcoords="offset points",
            fontsize=8,
            color="#111827",
            ha="left",
            va="bottom",
            bbox={
                "boxstyle": "round,pad=0.2",
                "facecolor": "white",
                "alpha": 0.78,
                "linewidth": 0,
            },
            zorder=11,
        )
        axis.set_title(
            f"alpha.water ≥ {threshold:g}  |  {metric['cell_count']:,} cells\n"
            f"cell support {metric['cell_support_volume_m3']:.4g} m³  |  "
            f"{len(polygons):,} surface polygons",
            fontsize=12,
        )
        axis.set_xlabel("x crossflow (m) →")
        axis.set_ylabel("y upward (m) ↑")

    fig.suptitle(
        figure_title or f"Computed fine-grid water cells at t = {time_s:.4f} s",
        fontsize=14,
        y=0.96,
    )
    fig.text(
        0.5,
        0.015,
        "Opaque exterior surfaces of native cells selected by alpha.water threshold • "
        f"+z orthographic projection; axes clip to {bounds_label} • "
        "threshold surfaces are not a reconstructed continuous interface",
        ha="center",
        fontsize=9,
    )
    image_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(image_path, dpi=180, facecolor="white")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--alpha-npz", type=Path, required=True)
    parser.add_argument("--alpha-receipt", type=Path, required=True)
    parser.add_argument("--geometry-npz", type=Path, required=True)
    parser.add_argument("--geometry-receipt", type=Path, required=True)
    parser.add_argument("--time-s", type=float, required=True)
    parser.add_argument("--ledger-water-volume-m3", type=float)
    parser.add_argument("--metrics-json", type=Path, required=True)
    parser.add_argument("--figure-png", type=Path, required=True)
    parser.add_argument("--zoom-figure-png", type=Path, required=True)
    parser.add_argument("--surface-dir", type=Path, required=True)
    parser.add_argument("--pvsm", type=Path, required=True)
    args = parser.parse_args()

    alpha_npz = args.alpha_npz.expanduser().resolve()
    alpha_receipt_path = args.alpha_receipt.expanduser().resolve()
    geometry_npz = args.geometry_npz.expanduser().resolve()
    geometry_receipt_path = args.geometry_receipt.expanduser().resolve()
    if not all(
        path.is_file()
        for path in (alpha_npz, alpha_receipt_path, geometry_npz, geometry_receipt_path)
    ):
        raise FileNotFoundError("mapped alpha and native geometry inputs must be present")
    alpha_receipt = json.loads(alpha_receipt_path.read_text(encoding="utf-8"))
    geometry_receipt = json.loads(geometry_receipt_path.read_text(encoding="utf-8"))
    if alpha_receipt["time_s"] != args.time_s:
        raise RuntimeError("mapped alpha receipt time differs from requested snapshot time")
    if alpha_receipt["mapping"]["native_cell_count"] != EXPECTED_CELLS:
        raise RuntimeError("mapped alpha receipt has an unexpected native cell count")
    if geometry_receipt["cells"] != EXPECTED_CELLS:
        raise RuntimeError("native geometry receipt has an unexpected cell count")
    with np.load(alpha_npz) as mapped:
        alpha = mapped["alpha_water_global"]
    with np.load(geometry_npz) as geometry:
        centres = geometry["centres_m"].copy()
        volumes = geometry["volumes_m3"].copy()
    if alpha.shape != (EXPECTED_CELLS,):
        raise RuntimeError(f"unexpected mapped alpha shape {alpha.shape}")
    if centres.shape != (EXPECTED_CELLS, 3) or volumes.shape != (EXPECTED_CELLS,):
        raise RuntimeError("native cell geometry arrays do not match alpha cell count")
    if not np.isfinite(alpha).all() or not np.isfinite(centres).all():
        raise RuntimeError("alpha or cell centres contain non-finite values")
    if not np.isfinite(volumes).all() or np.any(volumes <= 0.0):
        raise RuntimeError("native cell volumes contain non-finite or non-positive values")

    domain_volume = float(volumes.sum())
    water_volume = float(np.dot(alpha, volumes))
    water_weights = alpha * volumes
    if not math.isfinite(water_volume) or water_volume <= 0.0:
        raise RuntimeError(f"mapped alpha water volume is invalid: {water_volume}")
    water_centroid = np.einsum("i,ij->j", water_weights, centres) / water_volume
    threshold_results = {
        f"alpha_ge_{threshold:g}": threshold_metrics(alpha, centres, volumes, threshold)
        for threshold in THRESHOLDS
    }
    ledger_check = None
    if args.ledger_water_volume_m3 is not None:
        ledger_check = {
            "solver_ledger_volume_m3": args.ledger_water_volume_m3,
            "field_integral_volume_m3": water_volume,
            "signed_residual_m3": water_volume - args.ledger_water_volume_m3,
            "relative_residual": (water_volume - args.ledger_water_volume_m3)
            / args.ledger_water_volume_m3,
        }

    metrics_path = args.metrics_json.expanduser().resolve()
    figure_path = args.figure_png.expanduser().resolve()
    zoom_figure_path = args.zoom_figure_png.expanduser().resolve()
    surface_dir = args.surface_dir.expanduser().resolve()
    state_path = args.pvsm.expanduser().resolve()
    surface_paths = [
        surface_dir / f"alpha-ge-{threshold:g}-t{args.time_s:.4f}.vtp" for threshold in THRESHOLDS
    ]
    outputs = [metrics_path, figure_path, zoom_figure_path, state_path, *surface_paths]
    if any(path.exists() for path in outputs):
        raise FileExistsError("refusing to overwrite fine water-view results")
    started = time.monotonic()
    reader, grid, cell_order = read_native_grid(centres, volumes)
    alpha_vtk = numpy_to_vtk(np.asarray(alpha, dtype=np.float64), deep=True, array_type=VTK_DOUBLE)
    alpha_vtk.SetName("alpha.water")
    grid.GetCellData().AddArray(alpha_vtk)
    projected = []
    surface_results = []
    for threshold, surface_path in zip(THRESHOLDS, surface_paths, strict=True):
        polydata, surface_receipt = make_threshold_surface(grid, threshold, surface_path)
        projected.append(projected_polygons(polydata))
        surface_results.append(surface_receipt)
        del polydata
        gc.collect()
    render(projected, threshold_results, args.time_s, figure_path)
    render(
        projected,
        threshold_results,
        args.time_s,
        zoom_figure_path,
        ZOOM_BOUNDS_M,
        "plume zoom bounds",
        f"Computed α.water at t = {args.time_s:.4f} s • saved parent checkpoint • "
        f"{EXPECTED_CELLS:,} cells",
    )
    state_camera = save_pv_state(surface_paths, state_path)
    del grid, reader, alpha_vtk
    gc.collect()
    metrics_path.parent.mkdir(parents=True, exist_ok=True)
    receipt = {
        "schema_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "time_s": args.time_s,
        "source_mesh_manifest_sha256": geometry_receipt["source_mesh_manifest_sha256"],
        "mesh_cells": EXPECTED_CELLS,
        "coordinate_frame": {
            "x": "native mesh x; nozzle at 0 m and positive downstream",
            "y": "native mesh y; upward positive and nozzle/wall reference at 0 m",
            "z": "spanwise; plotted from an orthographic +z side view",
        },
        "raw_alpha_extrema": {
            "min": float(alpha.min()),
            "max": float(alpha.max()),
            "values_clipped": False,
        },
        "domain_volume_m3": domain_volume,
        "water_volume_from_global_alpha_integral_m3": water_volume,
        "water_centroid_m": [float(value) for value in water_centroid],
        "solver_ledger_check": ledger_check,
        "threshold_support_by_cell_centres_and_volumes": threshold_results,
        "native_mesh_cell_order_check": cell_order,
        "native_threshold_surfaces": surface_results,
        "processing": {
            "elapsed_s": round(time.monotonic() - started, 2),
            "peak_rss_gib": peak_rss_gib(),
            "mesh_reader": "ParaView OpenFOAMReader; reconstructed case internalMesh",
            "surface_extraction": "VTK cell threshold + exterior geometry filter",
            "rendering": "Matplotlib Agg CPU; no ParaView Render or SaveScreenshot/OpenGL draw call",
        },
        "plot": {
            "path": str(figure_path),
            "sha256": sha256(figure_path),
            "bytes": figure_path.stat().st_size,
            "dpi": 180,
            "projection": "+z orthographic projection of native-cell threshold exterior polygons",
            "plot_bounds_m": PLOT_BOUNDS_M,
            "same_camera_frame_as_coarse_view": True,
            "render_backend": "Matplotlib Agg CPU",
            "continuous_interface_reconstructed": False,
            "axes_clip_to_plot_bounds": True,
            "view_role": "wide bounds retained for qualitative comparison with coarse t=0.3 fields",
        },
        "zoom_plot": {
            "path": str(zoom_figure_path),
            "sha256": sha256(zoom_figure_path),
            "bytes": zoom_figure_path.stat().st_size,
            "dpi": 180,
            "plot_bounds_m": ZOOM_BOUNDS_M,
            "same_nozzle_reference_and_equal_aspect": True,
            "all_selected_cell_centres_inside_bounds": all(
                item["cell_center_extents_m"]["x"][0] >= ZOOM_BOUNDS_M["x"][0]
                and item["cell_center_extents_m"]["x"][1] <= ZOOM_BOUNDS_M["x"][1]
                and item["cell_center_extents_m"]["y"][0] >= ZOOM_BOUNDS_M["y"][0]
                and item["cell_center_extents_m"]["y"][1] <= ZOOM_BOUNDS_M["y"][1]
                for item in threshold_results.values()
            ),
            "render_backend": "Matplotlib Agg CPU",
        },
        "paraview_state": {
            "path": str(state_path),
            "sha256": sha256(state_path),
            "bytes": state_path.stat().st_size,
            "saved_without_render": True,
            "contains_surface_readers": [str(path) for path in surface_paths],
            "default_camera": state_camera,
        },
        "input_receipts": {
            "mapped_alpha_receipt": str(alpha_receipt_path),
            "mapped_alpha_receipt_sha256": sha256(alpha_receipt_path),
            "mapped_alpha_npz": str(alpha_npz),
            "mapped_alpha_npz_sha256": sha256(alpha_npz),
            "native_geometry_receipt": str(geometry_receipt_path),
            "native_geometry_receipt_sha256": sha256(geometry_receipt_path),
            "native_geometry_npz": str(geometry_npz),
            "native_geometry_npz_sha256": sha256(geometry_npz),
        },
        "interpretation": (
            "Exploratory field view and threshold-support diagnostics only; this snapshot "
            "does not validate the discretization or establish a paper comparison."
        ),
    }
    metrics_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
