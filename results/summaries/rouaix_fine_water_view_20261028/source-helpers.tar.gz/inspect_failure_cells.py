#!/usr/bin/env pvpython
"""Map reported rank-local Rouaix hot cells to static native mesh geometry."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[3]
RUN = REPO / "results/runs/rouaix-fine-water-view-20261028"
SUMMARY = REPO / "results/summaries/rouaix_fine_water_view_20261028"
MESH = REPO / "results/runs/rouaix-matched-mesh-mac-20261025/final-cast-only-transfer-core"
CONCAVE_MESH = (
    REPO
    / "results/runs/rouaix-matched-mesh-mac-20261025/final-cast-only/prelayer-immutable/polyMesh"
)
TRANSFER = MESH / "transfer-provenance.json"
FAILURE = (
    REPO
    / "results/summaries/rouaix_pressure_total_restart_20261028/live-14702499/failure-20261028T155146Z/failure-inspection.json"
)
OUTPUT = SUMMARY / "hotspot-cell-geometry.json"
EXPECTED_CELLS = 10_099_265
HOTSPOTS = {
    "max_U": {"processor": 99, "local_cell_id": 84531},
    "p_rgh_extremum_A": {"processor": 97, "local_cell_id": 6006},
    "p_rgh_extremum_B": {"processor": 99, "local_cell_id": 34458},
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load helper module {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def read_cell_set(path: Path, reader_module, expected_cells: int) -> tuple[np.ndarray, str]:
    raw = path.read_bytes()
    header = re.search(rb"(?:^|\n)\s*(\d+)\s*\n\s*\(", raw)
    if header is None:
        raise ValueError(f"cannot find label-list count in {path}")
    count, start = int(header.group(1)), header.end()
    body = raw[start:].lstrip()
    if body[:1] in b"+-0123456789":
        values = np.fromstring(
            reader_module._ascii_list_body(raw, start, path).decode("ascii"),
            sep=" ",
            dtype=np.int64,
        )
        encoding = "ASCII label payload despite FoamFile format binary header"
    else:
        values = np.frombuffer(raw[start : start + count * 4], dtype="<i4").astype(np.int64)
        encoding = "binary 32-bit labels"
    if len(values) != count:
        raise ValueError(f"concaveCells count mismatch: {len(values)} != {count}")
    if values.size and (int(values.min()) < 0 or int(values.max()) >= expected_cells):
        raise ValueError("concaveCells contains IDs outside the native cell range")
    if len(np.unique(values)) != len(values):
        raise ValueError("concaveCells contains repeated IDs")
    return values, encoding


def main() -> None:
    if OUTPUT.exists():
        raise FileExistsError(f"refusing to overwrite {OUTPUT}")
    mapper = load_module("rouaix_fine_field_mapper", RUN / "map_collated_alpha.py")
    mesh_view = load_module("rouaix_fine_mesh_view", RUN / "render_fine_water_view.py")
    geometry_receipt_path = RUN / "staging/native-cell-centres-volumes.json"
    geometry_path = RUN / "staging/native-cell-centres-volumes.npz"
    map_path = RUN / "staging/source-cellProcAddressing"
    concave_path = CONCAVE_MESH / "sets/concaveCells"

    geometry_receipt = json.loads(geometry_receipt_path.read_text(encoding="utf-8"))
    transfer = json.loads(TRANSFER.read_text(encoding="utf-8"))
    failure = json.loads(FAILURE.read_text(encoding="utf-8"))
    reader_module = mapper.native_reader()
    cell_maps, map_receipt = mapper.read_cell_maps(map_path, 120, EXPECTED_CELLS, reader_module)
    concave_ids, concave_encoding = read_cell_set(concave_path, reader_module, EXPECTED_CELLS)
    if len(concave_ids) != 114_008 or len(np.unique(concave_ids)) != len(concave_ids):
        raise RuntimeError("source concaveCells set does not match the recorded 114,008 unique IDs")
    concave_set = set(map(int, concave_ids))

    mesh_hashes = {}
    for name, expected in geometry_receipt["source_mesh_file_hashes"].items():
        source_hash = sha256(CONCAVE_MESH / name)
        active_hash = sha256(MESH / "constant/polyMesh" / name)
        if source_hash != expected or active_hash != expected:
            raise RuntimeError(f"mesh component {name} does not match the fine run mesh")
        mesh_hashes[name] = expected

    with np.load(geometry_path) as geometry:
        centres = geometry["centres_m"]
        volumes = geometry["volumes_m3"]
    reader, grid, cell_order = mesh_view.read_native_grid(centres, volumes)
    result_cells = {}
    for label, address in HOTSPOTS.items():
        processor = address["processor"]
        local_id = address["local_cell_id"]
        if processor not in cell_maps or local_id < 0 or local_id >= len(cell_maps[processor]):
            raise IndexError(f"rank-local address outside processor{processor} cell map")
        global_id = int(cell_maps[processor][local_id])
        vtk_cell = grid.GetCell(global_id)
        if vtk_cell is None or vtk_cell.GetNumberOfPoints() == 0:
            raise RuntimeError(f"native VTK cell {global_id} is empty")
        result_cells[label] = {
            "processor": processor,
            "processor_local_cell_id_zero_based": local_id,
            "native_global_cell_id": global_id,
            "vtk_cell_type_id": int(grid.GetCellType(global_id)),
            "vtk_cell_type": vtk_cell.GetClassName(),
            "native_cell_centre_m": [float(value) for value in centres[global_id]],
            "native_cell_volume_m3": float(volumes[global_id]),
            "native_cell_bounds_m": {
                "x": [float(value) for value in vtk_cell.GetBounds()[0:2]],
                "y": [float(value) for value in vtk_cell.GetBounds()[2:4]],
                "z": [float(value) for value in vtk_cell.GetBounds()[4:6]],
            },
            "face_count": int(vtk_cell.GetNumberOfFaces()),
            "point_count": int(vtk_cell.GetNumberOfPoints()),
            "in_native_concaveCells_set": global_id in concave_set,
        }

    claimed_max_u = failure["failure_evidence"]["completed_time_0_2495"]["extrema"][
        "max_U_location_m"
    ]
    max_u_centre = np.asarray(result_cells["max_U"]["native_cell_centre_m"])
    claimed = np.asarray(claimed_max_u)
    result_cells["max_U"]["claimed_completed_log_location_m"] = claimed_max_u
    result_cells["max_U"]["centre_minus_claimed_location_m"] = [
        float(value) for value in max_u_centre - claimed
    ]
    result_cells["max_U"]["centre_claim_difference_norm_m"] = float(
        np.linalg.norm(max_u_centre - claimed)
    )
    result_cells["p_rgh_extremum_A"]["claimed_log_location_m_available"] = False
    result_cells["p_rgh_extremum_B"]["claimed_log_location_m_available"] = False

    output = {
        "schema_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "static geometry only for three reported processor-local failure hotspot addresses",
        "job_id": failure["parent_job_id"],
        "failed_solver_time_s": failure["failure_evidence"]["actual_end_time_s"],
        "no_failed_time_fields_read": True,
        "hotspot_address_source": (
            "max_U address/location from saved failure-inspection receipt; two p_rgh addresses "
            "from the primary investigation's follow-up instruction"
        ),
        "mesh": {
            "native_cells": EXPECTED_CELLS,
            "source_mesh_case": str(MESH),
            "polyMesh_hashes_match_run_input": True,
            "polyMesh_component_sha256": mesh_hashes,
            "reader_cell_order_check": cell_order,
        },
        "cellProcAddressing": {
            "path": str(map_path),
            "sha256": map_receipt["sha256"],
            "ranks": map_receipt["ranks"],
            "exact_global_cell_cover": map_receipt["global_cell_id_exact_cover"],
        },
        "native_concaveCells_set": {
            "path": str(concave_path),
            "sha256": sha256(concave_path),
            "cell_count": len(concave_ids),
            "payload_encoding": concave_encoding,
            "geometry_identity_check": "five source polyMesh hashes match the active fine mesh",
            "interpretation": transfer["native_source_check"]["mesh_gate"],
            "independent_review": transfer["native_source_check"][
                "independent_signed_plane_review"
            ],
        },
        "hotspots": result_cells,
        "interpretation": (
            "These are mesh identities and static geometric properties only. They do not provide "
            "the failed-time phase, pressure, or velocity fields, and concaveCells membership is "
            "the historical checkMesh flag set rather than proof of genuine cell concavity."
        ),
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2), flush=True)


if __name__ == "__main__":
    main()
