#!/usr/bin/env python3
"""Map a collated alpha.water field to native cell IDs using cellProcAddressing."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np

REPO = Path(__file__).resolve().parents[3]
READER_PATH = REPO / "src/aerial_drop/i4f_native_face_reader.py"
_UNIFORM_SCALAR_RE = re.compile(
    rb"internalField\s+uniform\s+([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)\s*;"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def native_reader():
    spec = importlib.util.spec_from_file_location("i4f_native_face_reader", READER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not import native collated reader {READER_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def read_cell_maps(
    path: Path, nprocs: int, expected_cells: int, reader: Any
) -> tuple[dict[int, np.ndarray], dict[str, Any]]:
    raw = path.read_bytes()
    matches = list(reader._COLLATED_FIELD_RE.finditer(raw))
    rank_ids = [int(match.group(1)) for match in matches]
    if rank_ids != list(range(nprocs)):
        raise ValueError(
            f"expected ordered processor blocks 0..{nprocs - 1} in cellProcAddressing; "
            f"found {rank_ids[:8]}... ({len(rank_ids)} blocks)"
        )

    maps: dict[int, np.ndarray] = {}
    counts = []
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(raw)
        block = raw[match.end() : end]
        count, start = reader._block_list_start(block, path)
        payload = block[start : start + count * 4]
        if len(payload) != count * 4:
            raise ValueError(f"truncated cellProcAddressing block for rank {index}")
        if b"format      ascii" in block[:512]:
            values = np.fromstring(
                reader._ascii_list_body(block, start, path).decode("ascii"),
                sep=" ",
                dtype=np.int32,
            )
        else:
            values = np.frombuffer(payload, dtype="<i4").copy()
        if len(values) != count:
            raise ValueError(
                f"cellProcAddressing block {index} has {len(values)} IDs, expected {count}"
            )
        maps[index] = values
        counts.append(count)

    covered = np.zeros(expected_cells, dtype=bool)
    for rank, labels in maps.items():
        if labels.size and (int(labels.min()) < 0 or int(labels.max()) >= expected_cells):
            raise ValueError(f"rank {rank} has cell IDs outside the native mesh range")
        if covered[labels].any():
            raise ValueError(f"rank {rank} repeats a native cell already assigned elsewhere")
        covered[labels] = True
    missing = int(np.count_nonzero(~covered))
    if missing:
        raise ValueError(f"cellProcAddressing leaves {missing} native cells unmapped")
    return maps, {
        "path": str(path),
        "sha256": sha256(path),
        "bytes": path.stat().st_size,
        "ranks": nprocs,
        "rank_cell_counts": counts,
        "mapped_cells": int(sum(counts)),
        "native_cell_count": expected_cells,
        "global_cell_id_exact_cover": True,
        "global_id_min": int(min(int(labels.min()) for labels in maps.values())),
        "global_id_max": int(max(int(labels.max()) for labels in maps.values())),
    }


def map_collated_alpha(
    alpha_path: Path,
    maps: dict[int, np.ndarray],
    nprocs: int,
    expected_cells: int,
    reader: Any,
) -> tuple[np.ndarray, dict[str, Any]]:
    chunks = reader._field_chunks(alpha_path, nprocs)
    alpha = np.empty(expected_cells, dtype=np.float64)
    seen = np.zeros(expected_cells, dtype=bool)
    rank_receipts = []
    for rank in range(nprocs):
        ids = maps[rank]
        uniform = _UNIFORM_SCALAR_RE.search(chunks[rank])
        if uniform is None:
            values = reader._parse_internal(chunks[rank], "scalar")
            encoding = "nonuniform List<scalar>"
        else:
            scalar = float(uniform.group(1))
            values = np.full(len(ids), scalar, dtype=np.float64)
            encoding = "uniform scalar expanded to mapped rank cells"
        if len(values) != len(ids):
            raise ValueError(
                f"alpha.water rank {rank} count {len(values)} differs from "
                f"cellProcAddressing count {len(ids)}"
            )
        if seen[ids].any():
            raise ValueError(f"alpha.water rank {rank} repeats mapped native cells")
        alpha[ids] = values
        seen[ids] = True
        rank_receipts.append(
            {
                "rank": rank,
                "cells": len(values),
                "internal_field_encoding": encoding,
                "alpha_min_raw": float(values.min()),
                "alpha_max_raw": float(values.max()),
            }
        )
    if not seen.all():
        raise ValueError(f"alpha.water left {int(np.count_nonzero(~seen))} native cells unset")
    if not np.isfinite(alpha).all():
        raise ValueError("mapped alpha.water includes non-finite values")
    return alpha, {
        "path": str(alpha_path),
        "sha256": sha256(alpha_path),
        "bytes": alpha_path.stat().st_size,
        "mapped_cells": len(alpha),
        "uniform_internal_field_ranks": [
            item["rank"]
            for item in rank_receipts
            if item["internal_field_encoding"].startswith("uniform")
        ],
        "alpha_min_raw": float(alpha.min()),
        "alpha_max_raw": float(alpha.max()),
        "rank_fields": rank_receipts,
        "values_clipped": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--alpha", type=Path, required=True)
    parser.add_argument("--cell-proc-addressing", type=Path, required=True)
    parser.add_argument("--nprocs", type=int, required=True)
    parser.add_argument("--expected-cells", type=int, required=True)
    parser.add_argument("--time-s", type=float, required=True)
    parser.add_argument("--output-npz", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    args = parser.parse_args()
    alpha_path = args.alpha.expanduser().resolve()
    map_path = args.cell_proc_addressing.expanduser().resolve()
    if args.nprocs <= 0 or args.expected_cells <= 0:
        raise ValueError("nprocs and expected-cells must be positive")
    if not alpha_path.is_file() or not map_path.is_file():
        raise FileNotFoundError("both collated field and cell map must be closed local files")

    reader = native_reader()
    maps, map_receipt = read_cell_maps(map_path, args.nprocs, args.expected_cells, reader)
    alpha, alpha_receipt = map_collated_alpha(
        alpha_path, maps, args.nprocs, args.expected_cells, reader
    )
    output_npz = args.output_npz.expanduser().resolve()
    output_json = args.output_json.expanduser().resolve()
    output_npz.parent.mkdir(parents=True, exist_ok=True)
    output_json.parent.mkdir(parents=True, exist_ok=True)
    if output_npz.exists() or output_json.exists():
        raise FileExistsError("refusing to overwrite mapped fine-field evidence")
    np.savez_compressed(output_npz, alpha_water_global=alpha)

    receipt = {
        "schema_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "time_s": args.time_s,
        "native_reader_module": {
            "path": str(READER_PATH),
            "sha256": sha256(READER_PATH),
            "routines_reused": [
                "_COLLATED_FIELD_RE",
                "_block_list_start",
                "_ascii_list_body",
                "_field_chunks",
                "_parse_internal",
            ],
        },
        "source_processor_map": map_receipt,
        "source_alpha_field": alpha_receipt,
        "mapped_alpha_npz": {
            "path": str(output_npz),
            "sha256": sha256(output_npz),
            "bytes": output_npz.stat().st_size,
            "values_clipped": False,
        },
        "mapping": {
            "native_cell_count": args.expected_cells,
            "processor_count": args.nprocs,
            "exact_global_cell_cover": True,
            "alpha_values_clipped": False,
        },
    }
    output_json.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
