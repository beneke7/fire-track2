#!/usr/bin/env python3
"""Stage, but do not launch, a source-case water-nozzle sibling."""

from __future__ import annotations

import hashlib
import json
import re
import sys
from datetime import UTC, datetime
from pathlib import Path

RUN = Path(__file__).resolve().parent
SOURCE_ROOT = RUN / "source-code"
sys.path.insert(0, str(SOURCE_ROOT))
from cases.e1_rouaix_fast_diagnostics import build_cases  # noqa: E402

AIR_CASE = RUN / "air-backflow-030"
DESTINATION = RUN / "air-backflow-water-030"
SOURCE_ALPHA = SOURCE_ROOT / "cases/e1_rouaix_case1_static/case/0/alpha.water"
NOZZLE_BLOCK = re.compile(r"(?ms)^    nozzle\s*\{\s*.*?^    \}")


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    air_meta = json.loads((AIR_CASE / "case-inputs.json").read_text(encoding="utf-8"))
    source_text = SOURCE_ALPHA.read_text(encoding="utf-8")
    source_match = NOZZLE_BLOCK.search(source_text)
    if source_match is None or "value           uniform 1;" not in source_match.group():
        raise ValueError("source-case nozzle water patch is not the expected fixed alpha=1")

    metadata = build_cases.write_case(
        DESTINATION,
        "original",
        horizon_s=0.30,
        ranks=8,
        backflow_total_pressure=True,
    )
    build_cases.attach_mesh(DESTINATION, RUN / "native-mesh")
    alpha_path = DESTINATION / "0/alpha.water"
    air_text = alpha_path.read_text(encoding="utf-8")
    air_match = NOZZLE_BLOCK.search(air_text)
    if air_match is None or "value           uniform 0;" not in air_match.group():
        raise ValueError("generated air candidate nozzle patch is not fixed alpha=0")
    alpha_path.write_text(
        air_text[: air_match.start()] + source_match.group() + air_text[air_match.end() :],
        encoding="utf-8",
    )

    metadata_path = DESTINATION / "case-inputs.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    metadata.update(
        {
            "case_id": "ROUAIX-WATER-NOZZLE-ORIGINAL-03000-BACKFLOW-PTOTAL0-08RANK",
            "queue_run_name": DESTINATION.name,
            "source_mode": (
                "air-filled domain alpha.water=0 with the source-case liquid nozzle boundary "
                "fixedValue alpha.water=1"
            ),
            "initial_condition": "air-filled domain; liquid phase supplied through existing source nozzle patch",
            "source_turbulence_boundary_note": (
                "Case 1 nozzle k=0.015 m2/s2 and epsilon=0.0107810420 m2/s3 are retained at the "
                "liquid nozzle patch; gasInlet k=0.735 m2/s2 and epsilon=3.6978974178 m2/s3 are unchanged."
            ),
            "flux_field_note": (
                "phi is mixture-volume flux; alphaPhi_ is water-phase flux. Both are recorded separately."
            ),
            "launch_state": "prepared only; do not release before air branch reaches t>0.20 s healthy or primary approval",
            "source_case_nozzle_alpha_sha256": sha(SOURCE_ALPHA),
            "air_sibling_case_inputs_sha256": sha(AIR_CASE / "case-inputs.json"),
            "water_preparation_script_sha256": sha(Path(__file__)),
        }
    )
    metadata["case_files_sha256"] = build_cases.tree_hashes(
        DESTINATION, exclude=("case-inputs.json",)
    )
    metadata["case_files_total_bytes"] = sum(
        path.stat().st_size
        for path in DESTINATION.rglob("*")
        if path.is_file() and path.name != "case-inputs.json"
    )
    metadata_path.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")

    air_files = {
        path.relative_to(AIR_CASE).as_posix(): path
        for path in AIR_CASE.rglob("*")
        if path.is_file()
    }
    water_files = {
        path.relative_to(DESTINATION).as_posix(): path
        for path in DESTINATION.rglob("*")
        if path.is_file()
    }
    if set(air_files) != set(water_files):
        raise AssertionError("water candidate file set differs from the all-air sibling")
    changed = {
        name
        for name in air_files
        if name not in {"0/alpha.water", "case-inputs.json"}
        and sha(air_files[name]) != sha(water_files[name])
    }
    if changed:
        raise AssertionError(f"unexpected water candidate changes: {sorted(changed)}")
    if metadata["mesh_files_sha256"] != air_meta["mesh_files_sha256"]:
        raise AssertionError("water candidate does not reuse the frozen mesh bytes")
    if "internalField   uniform 0;" not in alpha_path.read_text(encoding="utf-8"):
        raise AssertionError("water candidate bulk initial phase was changed")

    record = {
        "schema_version": 1,
        "prepared_utc": datetime.now(UTC).isoformat(),
        "status": "prepared_only_not_launched",
        "case": DESTINATION.name,
        "air_sibling": AIR_CASE.name,
        "air_sibling_case_inputs_sha256": sha(AIR_CASE / "case-inputs.json"),
        "case_inputs_sha256": sha(metadata_path),
        "source_case_nozzle_alpha_sha256": sha(SOURCE_ALPHA),
        "mesh_file_count": len(metadata["mesh_files_sha256"]),
        "mesh_files_sha256": metadata["mesh_files_sha256"],
        "changed_case_files_from_air_sibling": ["0/alpha.water"],
        "nozzle_alpha_source_value": "fixedValue uniform 1",
        "bulk_alpha_initial_value": "uniform 0",
        "launch_gate": metadata["launch_state"],
        "no_solver_started": True,
    }
    (RUN / "water-candidate-prepared-only.json").write_text(
        json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(record, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
