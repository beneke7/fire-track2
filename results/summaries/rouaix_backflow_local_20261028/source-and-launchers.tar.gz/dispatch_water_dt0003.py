#!/usr/bin/env python3
"""Bounded persistent dispatcher for the fixed-0.0003 s water cost case."""

from __future__ import annotations

import fcntl
import json
import os
import re
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
PYTHON = ROOT / ".venv/bin/python"
RUN_LOCAL = ROOT / "scripts/run_local.py"
RUNNER = RUN / "run_remote.py"
CASE = "air-backflow-water-dt0003-030"
REFERENCE = "air-backflow-water-030"
CASE_DIR = RUN / CASE
REFERENCE_DIR = RUN / REFERENCE
OUTPUT = RUN / "container-runs" / CASE
REFERENCE_OUTPUT = RUN / "container-runs" / REFERENCE
STATE = RUN / "water-dt0003-dispatcher-state.json"
EVENTS = RUN / "water-dt0003-dispatcher-events.jsonl"
LOCK = RUN / "water-dt0003-dispatcher.lock"
LOG = RUN / f"{CASE}.runner.log"
LOCAL_PAUSE = ROOT / "PAUSE"
MAX_WAIT_S = 1800
POLL_S = 10
SSH_CAPACITY = r"""set -euo pipefail
if [[ -e /home/v/proj/bene/fire-track2/PAUSE ]]; then echo PAUSED_GOBLIN; exit 0; fi
read_cpu() { awk '$1=="cpu" { total=0; for(i=2;i<=9;i++) total+=$i; idle=$5+$6; printf "%.0f %.0f\n",total,total-idle }' /proc/stat; }
read -r total0 busy0 < <(read_cpu)
sleep 5
read -r total1 busy1 < <(read_cpu)
cpus=$(nproc); dt=$((total1-total0)); db=$((busy1-busy0))
awk -v dt="$dt" -v db="$db" -v n="$cpus" 'BEGIN { if(dt<=0 || db<0) exit 2; printf "BUSY=%.3f NPROC=%d AVAILABLE=%.3f\n", db/dt*n, n, n-db/dt*n }'
"""


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def sha(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def event(kind: str, **fields: Any) -> None:
    record = {"utc": utc_now(), "event": kind, **fields}
    with EVENTS.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, sort_keys=True) + "\n")
    print(json.dumps(record, sort_keys=True), flush=True)


def state(value: str, **fields: Any) -> None:
    record = {"schema_version": 1, "state": value, "updated_utc": utc_now(), **fields}
    tmp = STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    os.replace(tmp, STATE)


def tree_hashes(root: Path) -> dict[str, str]:
    return {
        path.relative_to(root).as_posix(): sha(path)
        for path in sorted(root.rglob("*"))
        if path.is_file()
    }


def validate_case() -> tuple[bool, dict[str, Any]]:
    checks: dict[str, Any] = {}
    try:
        receipt = json.loads((RUN / "water-dt0003-prepared-only.json").read_text())
        case_meta = json.loads((CASE_DIR / "case-inputs.json").read_text())
        ref_meta = json.loads((REFERENCE_DIR / "case-inputs.json").read_text())
        checks["prepared_case_receipt"] = (
            receipt.get("no_solver_started") is True
            and receipt.get("status") == "prepared_only_not_launched"
            and receipt.get("case_inputs_sha256") == sha(CASE_DIR / "case-inputs.json")
        )
        case_hashes = tree_hashes(CASE_DIR)
        reference_hashes = tree_hashes(REFERENCE_DIR)
        checks["same_file_inventory"] = set(case_hashes) == set(reference_hashes)
        checks["only_dt_dictionary_and_metadata_changed"] = checks["same_file_inventory"] and all(
            case_hashes[name] == reference_hashes[name]
            for name in case_hashes
            if name not in {"system/controlDict", "case-inputs.json"}
        )
        reference_control = (REFERENCE_DIR / "system/controlDict").read_text()
        case_control = (CASE_DIR / "system/controlDict").read_text()
        checks["control_dict_only_changes_delta_t"] = (
            case_control.replace("deltaT 0.0003;", "deltaT 0.0001;") == reference_control
            and case_control.count("deltaT 0.0003;") == 1
        )
        matched_keys = (
            "end_time_s",
            "field_write_times_s",
            "initial_condition",
            "momentum_convection",
            "mpi_ranks",
            "nozzle_velocity_m_s",
            "gas_inlet_velocity_m_s",
            "source_mode",
            "mesh_files_sha256",
        )
        checks["physical_inputs_match_reference"] = all(
            case_meta.get(key) == ref_meta.get(key) for key in matched_keys
        )
        checks["fixed_dt_and_horizon"] = (
            case_meta.get("delta_t_s") == 0.0003
            and case_meta.get("expected_steps") == 1000
            and case_meta.get("end_time_s") == 0.3
            and case_meta.get("runtime_guard", {}).get("max_abs_U_m_s") == 200.0
            and case_meta.get("runtime_guard", {}).get("hard_wall_seconds") == 900
            and case_meta.get("runtime_guard", {}).get("grace_seconds") == 120
        )
        # The reference must be a complete archived water run with a frozen source/input identity.
        ref_result = json.loads((REFERENCE_OUTPUT / "run-result.json").read_text())
        ref_archive = json.loads((REFERENCE_OUTPUT / "archive-verification.json").read_text())
        ref_pre_go_path = REFERENCE_OUTPUT / "pre-go-manifest.json"
        ref_pre_go = json.loads(ref_pre_go_path.read_text())
        ref_snapshot_path = RUN / f"source-snapshot-before-{REFERENCE}" / "manifest.json"
        ref_snapshot = json.loads(ref_snapshot_path.read_text())
        ref_upload_manifest = RUN / "uploads" / REFERENCE / "case-files.sha256"
        ref_go = json.loads((REFERENCE_OUTPUT / "go-released.json").read_text())
        checks["reference_terminal_and_archive"] = (
            ref_result.get("released") is True
            and ref_archive.get("remote_local_sha_match") is True
            and ref_result.get("snapshot_inventory", {}).get("passed") is True
            and ref_result.get("terminal", {}).get("solver_time_s") == "0.300000000000"
            and ref_result.get("terminal", {}).get("guard_reason") == "horizon_end"
        )
        checks["reference_source_and_inputs_frozen"] = (
            ref_pre_go.get("source_snapshot_sha256") == sha(ref_snapshot_path)
            and ref_pre_go.get("source_files_sha256") == ref_snapshot.get("source_files_sha256")
            and ref_pre_go.get("git_revision") == ref_snapshot.get("git_revision")
            and ref_pre_go.get("git_dirty") == ref_snapshot.get("git_dirty")
            and ref_pre_go.get("input_case_sha256") == sha(REFERENCE_DIR / "case-inputs.json")
            and ref_pre_go.get("input_file_manifest_sha256") == sha(ref_upload_manifest)
            and ref_go.get("pre_go_manifest_sha256") == sha(ref_pre_go_path)
        )
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        checks["error"] = f"{type(error).__name__}: {error}"
        return False, checks
    return bool(checks) and all(v is True for k, v in checks.items() if k != "error"), checks


def ssh_capacity() -> tuple[bool, str]:
    result = subprocess.run(
        ["ssh", "-oBatchMode=yes", "-oConnectTimeout=8", "goblin", "bash", "-s"],
        input=SSH_CAPACITY,
        text=True,
        capture_output=True,
        timeout=12,
        check=False,
    )
    output = result.stdout.strip()
    if result.returncode != 0:
        return False, result.stderr.strip() or output
    if output.startswith("PAUSED_GOBLIN"):
        return False, output
    match = re.search(r"AVAILABLE=([0-9.]+)", output)
    return bool(match and float(match.group(1)) >= 8.0), output


def launch() -> int:
    command = [
        str(PYTHON),
        str(RUN_LOCAL),
        "--threads",
        "1",
        "--timeout",
        "2400",
        "--",
        str(PYTHON),
        str(RUNNER),
        "solver",
        "--case",
        CASE,
        "--cpus",
        "8",
    ]
    started = time.monotonic()
    with LOG.open("x", encoding="utf-8") as stream:
        result = subprocess.run(
            command,
            cwd=ROOT,
            stdout=stream,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
            timeout=2400,
        )
    elapsed = time.monotonic() - started
    event("runner_exit", returncode=result.returncode, elapsed_s=elapsed, command=command)
    result_path = OUTPUT / "run-result.json"
    archive_path = OUTPUT / "archive-verification.json"
    if result_path.is_file():
        run_result = json.loads(result_path.read_text())
        archive = json.loads(archive_path.read_text()) if archive_path.is_file() else {}
        terminal = run_result.get("terminal", {})
        passed = (
            result.returncode == 0
            and run_result.get("released") is True
            and archive.get("remote_local_sha_match") is True
            and run_result.get("snapshot_inventory", {}).get("passed") is True
            and terminal.get("end_marker") is True
            and terminal.get("solver_exit_code") == 0
        )
        state(
            "terminal_capture_verified" if passed else "terminal_capture_review_needed",
            run_result=run_result,
            archive_verification=archive,
        )
        return 0 if passed else 1
    state("runner_failed_without_result", returncode=result.returncode, log=str(LOG))
    return result.returncode or 1


def selftest() -> int:
    okay, checks = validate_case()
    if not okay:
        raise AssertionError(json.dumps(checks, sort_keys=True))
    safe = {"delta_t_s": 0.0003, "expected_steps": 1000, "end_time_s": 0.3}
    if abs(safe["end_time_s"] / safe["delta_t_s"] - safe["expected_steps"]) > 1e-12:
        raise AssertionError("fixed-step count self-test failed")
    print("WATER_DT0003_PREFLIGHT_SELFTEST_PASSED")
    return 0


def main() -> int:
    if "--selftest" in sys.argv:
        return selftest()
    LOCK.parent.mkdir(parents=True, exist_ok=True)
    with LOCK.open("a", encoding="utf-8") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("another dt0003 dispatcher already owns the lock", file=sys.stderr)
            return 3
        if STATE.is_file() and json.loads(STATE.read_text()).get("state") in {
            "case_running",
            "terminal_capture_verified",
        }:
            print("refusing duplicate dt0003 launch", file=sys.stderr)
            return 4
        if LOG.exists() or OUTPUT.exists():
            print("dt0003 attempt already has durable outputs; refusing relaunch", file=sys.stderr)
            return 5
        okay, checks = validate_case()
        if not okay:
            event("preflight_failed", checks=checks)
            state("preflight_failed", checks=checks)
            return 6
        event("case_inputs_verified", checks=checks)
        start = time.monotonic()
        while time.monotonic() - start < MAX_WAIT_S:
            if LOCAL_PAUSE.exists():
                reason = f"local PAUSE sentinel {LOCAL_PAUSE}"
                state("paused_waiting_for_clear", reason=reason, checks=checks)
                event("pause_wait", reason=reason)
                time.sleep(POLL_S)
                continue
            enough, sample = ssh_capacity()
            if not enough:
                state("waiting_for_eight_cpu_equivalents", capacity_sample=sample)
                event("capacity_wait", sample=sample)
                time.sleep(POLL_S)
                continue
            if LOCAL_PAUSE.exists():
                continue
            state("case_running", capacity_sample=sample, checks=checks)
            event("case_start", capacity_sample=sample, checks=checks)
            return launch()
        state("bounded_wait_timeout", max_wait_s=MAX_WAIT_S, checks=checks)
        event("bounded_wait_timeout", max_wait_s=MAX_WAIT_S)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
