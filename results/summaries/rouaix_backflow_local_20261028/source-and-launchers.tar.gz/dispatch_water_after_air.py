#!/usr/bin/env python3
"""Bounded conditional Goblin dispatcher for the matched water-nozzle branch."""

from __future__ import annotations

import argparse
import fcntl
import json
import math
import os
import re
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
PYTHON = ROOT / ".venv/bin/python"
RUN_LOCAL = ROOT / "scripts/run_local.py"
RUNNER = RUN / "run_remote.py"
STATE = RUN / "water-dispatcher-state.json"
EVENTS = RUN / "water-dispatcher-events.jsonl"
LOCK = RUN / "water-dispatcher.lock"
LOCAL_PAUSE = ROOT / "PAUSE"
GOBLIN_REPO = "/home/v/proj/bene/fire-track2"
AIR_NAME = "air-backflow-030"
WATER_NAME = "air-backflow-water-030"
CONTAINER = "rouaix-backflow-air-backflow-030-20261028-q20261028"
AIR_OUTPUT = RUN / "container-runs" / AIR_NAME
AIR_CASE = RUN / AIR_NAME
WATER_CASE = RUN / WATER_NAME
BASELINE_CASE = (
    ROOT / "results/runs/rouaix-fast-local-20261027/cases-and-runs/attempt-003/air-original-030"
)
BASELINE_OUTPUT = (
    ROOT
    / "results/runs/rouaix-fast-local-20261027/cases-and-runs/attempt-003/container-runs/air-original-030"
)
MAX_WAIT_S = 2400
POLL_S = 10

SSH_LIVE = r"""set -euo pipefail
name=rouaix-backflow-air-backflow-030-20261028-q20261028
if [[ -e /home/v/proj/bene/fire-track2/PAUSE ]]; then echo PAUSED_GOBLIN; exit 0; fi
if ! docker inspect "$name" >/dev/null 2>&1; then echo CONTAINER_GONE; exit 0; fi
docker exec "$name" cat /workspace/status.json
if docker exec "$name" grep -Eiwq '(nan|inf)' /workspace/logs/interIsoFoam.log; then
  echo NONFINITE_TOKEN_FOUND
else
  echo NO_NONFINITE_TOKENS
fi
"""
SSH_CAPACITY = r"""set -euo pipefail
if [[ -e /home/v/proj/bene/fire-track2/PAUSE ]]; then echo PAUSED_GOBLIN; exit 0; fi
read_cpu() { awk '$1=="cpu" { total=0; for(i=2;i<=9;i++) total+=$i; idle=$5+$6; printf "%.0f %.0f\n",total,total-idle }' /proc/stat; }
read -r total0 busy0 < <(read_cpu)
sleep 5
read -r total1 busy1 < <(read_cpu)
cpus=$(nproc); dt=$((total1-total0)); db=$((busy1-busy0))
awk -v dt="$dt" -v db="$db" -v n="$cpus" 'BEGIN { if(dt<=0 || db<0) exit 2; printf "BUSY=%.3f NPROC=%d AVAILABLE=%.3f\n", db/dt*n, n, n-db/dt*n }'
"""


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def sha(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def event(kind: str, **fields: Any) -> None:
    record = {"utc": utc_now(), "event": kind, **fields}
    with EVENTS.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, sort_keys=True) + "\n")
    print(json.dumps(record, sort_keys=True), flush=True)


def state(status: str, **fields: Any) -> None:
    record = {"schema_version": 1, "state": status, "updated_utc": utc_now(), **fields}
    tmp = STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    os.replace(tmp, STATE)


def ssh_script(script: str, timeout: int = 20) -> tuple[int, str, str]:
    result = subprocess.run(
        ["ssh", "-oBatchMode=yes", "-oConnectTimeout=8", "goblin", "bash", "-s"],
        input=script,
        text=True,
        capture_output=True,
        timeout=timeout,
        check=False,
    )
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def baseline_and_source_checks() -> tuple[bool, dict[str, Any]]:
    baseline_path = BASELINE_OUTPUT / "run-result.json"
    baseline_archive = BASELINE_OUTPUT / "archive-verification.json"
    air_pre_go_path = AIR_OUTPUT / "pre-go-manifest.json"
    source_manifest_path = RUN / f"source-snapshot-before-{AIR_NAME}" / "manifest.json"
    upload_manifest = RUN / "uploads" / AIR_NAME / "case-files.sha256"
    checks: dict[str, Any] = {}
    try:
        baseline = json.loads(baseline_path.read_text())
        archive = json.loads(baseline_archive.read_text())
        terminal = baseline["terminal"]
        checks["baseline_terminal"] = (
            baseline.get("released") is True
            and archive.get("remote_local_sha_match") is True
            and baseline["snapshot_inventory"].get("passed") is True
            and terminal.get("solver_exit_code") == 0
            and terminal.get("end_marker") is True
            and terminal.get("guard_reason") == "max_abs_U_exceeded_1000.0_m_s"
        )
        baseline_files = {
            path.relative_to(BASELINE_CASE).as_posix(): sha(path)
            for path in BASELINE_CASE.rglob("*")
            if path.is_file()
        }
        air_files = {
            path.relative_to(AIR_CASE).as_posix(): sha(path)
            for path in AIR_CASE.rglob("*")
            if path.is_file()
        }
        checks["matched_case_files"] = set(baseline_files) == set(air_files) and all(
            baseline_files[name] == air_files[name]
            for name in baseline_files
            if name not in {"0/p_rgh", "case-inputs.json"}
        )
        baseline_meta = json.loads((BASELINE_CASE / "case-inputs.json").read_text())
        air_meta = json.loads((AIR_CASE / "case-inputs.json").read_text())
        matched_keys = (
            "momentum_convection",
            "expected_steps",
            "mpi_ranks",
            "delta_t_s",
            "nozzle_velocity_m_s",
            "gas_inlet_velocity_m_s",
            "initial_condition",
        )
        checks["matched_physical_metadata"] = all(
            baseline_meta.get(key) == air_meta.get(key) for key in matched_keys
        )
        pre_go = json.loads(air_pre_go_path.read_text())
        source_manifest = json.loads(source_manifest_path.read_text())
        checks["air_source_snapshot"] = (
            pre_go.get("source_snapshot_sha256") == sha(source_manifest_path)
            and pre_go.get("source_files_sha256") == source_manifest.get("source_files_sha256")
            and pre_go.get("git_revision") == source_manifest.get("git_revision")
            and pre_go.get("git_dirty") == source_manifest.get("git_dirty")
        )
        checks["air_frozen_inputs"] = (
            pre_go.get("input_case_sha256") == sha(AIR_CASE / "case-inputs.json")
            and pre_go.get("input_file_manifest_sha256") == sha(upload_manifest)
            and pre_go.get("pre_go_ready_check", {}).get("hashes_verified") is True
        )
        water_record = json.loads((RUN / "water-candidate-prepared-only.json").read_text())
        water_meta = json.loads((WATER_CASE / "case-inputs.json").read_text())
        checks["water_preparation"] = (
            water_record.get("no_solver_started") is True
            and water_meta.get("runtime_guard", {}).get("max_abs_U_m_s") == 200.0
            and water_meta.get("expected_steps") == 3000
            and water_meta.get("mpi_ranks") == 8
        )
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        checks["error"] = f"{type(error).__name__}: {error}"
        return False, checks
    return bool(checks) and all(
        value is True for key, value in checks.items() if key != "error"
    ), checks


def eligible_status(status: dict[str, Any], *, nonfinite: bool) -> bool:
    try:
        time_s = float(status["solver_time_s"])
        speed = float(status["max_U_m_s"])
    except (KeyError, TypeError, ValueError):
        return False
    return (
        not nonfinite
        and math.isfinite(time_s)
        and time_s >= 0.20
        and math.isfinite(speed)
        and speed < 200.0
        and status.get("guard_reason") in {"none", "horizon_end"}
        and status.get("state") in {"running", "terminal"}
    )


def final_air_result_eligible() -> tuple[bool, dict[str, Any]]:
    result_path = AIR_OUTPUT / "run-result.json"
    if not result_path.is_file():
        return False, {"state": "air_run_result_pending"}
    try:
        result = json.loads(result_path.read_text())
        terminal = result["terminal"]
        speed = float(terminal["max_U_m_s"])
        time_s = float(terminal["solver_time_s"])
        log = (AIR_OUTPUT / "evidence/interIsoFoam.log").read_text(errors="replace")
        okay = (
            result.get("released") is True
            and json.loads((AIR_OUTPUT / "archive-verification.json").read_text()).get(
                "remote_local_sha_match"
            )
            is True
            and result.get("snapshot_inventory", {}).get("passed") is True
            and terminal.get("solver_exit_code") == 0
            and terminal.get("end_marker") is True
            and terminal.get("guard_reason") == "horizon_end"
            and math.isfinite(time_s)
            and time_s >= 0.20
            and math.isfinite(speed)
            and speed < 200.0
            and re.search(r"(?<![A-Za-z0-9_])[-+]?(?:nan|inf)(?![A-Za-z0-9_])", log, re.I) is None
        )
        return okay, {
            "state": "air_terminal_checked",
            "solver_time_s": time_s,
            "max_U_m_s": speed,
            "guard_reason": terminal.get("guard_reason"),
            "nonfinite_log_token": re.search(
                r"(?<![A-Za-z0-9_])[-+]?(?:nan|inf)(?![A-Za-z0-9_])", log, re.I
            )
            is not None,
        }
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        return False, {
            "state": "air_terminal_check_failed",
            "error": f"{type(error).__name__}: {error}",
        }


def run_water() -> tuple[int, dict[str, Any] | None]:
    log_path = RUN / f"{WATER_NAME}.runner.log"
    command = [
        str(PYTHON),
        str(RUN_LOCAL),
        "--threads",
        "1",
        "--timeout",
        "2400",
        "--",
        str(PYTHON),
        str(RUNNER),
        "solver",
        "--case",
        WATER_NAME,
        "--cpus",
        "8",
    ]
    event("water_case_start", command=command)
    state("water_case_running", case=WATER_NAME, runner_log=str(log_path))
    with log_path.open("w", encoding="utf-8") as stream:
        process = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    output = RUN / "container-runs" / WATER_NAME
    result_path = output / "run-result.json"
    result = json.loads(result_path.read_text()) if result_path.is_file() else None
    archived = bool(
        result
        and result.get("released") is True
        and (output / "archive-verification.json").is_file()
        and result.get("snapshot_inventory", {}).get("passed") is True
        and result.get("terminal", {}).get("solver_exit_code") == 0
        and result.get("terminal", {}).get("end_marker") is True
    )
    return process.returncode, result if archived else None


def _selftest() -> None:
    running = {
        "state": "running",
        "solver_time_s": "0.2001",
        "max_U_m_s": "79.0",
        "guard_reason": "none",
    }
    assert eligible_status(running, nonfinite=False)
    assert not eligible_status(running, nonfinite=True)
    assert not eligible_status({**running, "max_U_m_s": "200.1"}, nonfinite=False)
    assert not eligible_status({**running, "solver_time_s": "0.1999"}, nonfinite=False)
    print("WATER_RELEASE_GATE_SELFTEST_PASSED", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args()
    if args.selftest:
        _selftest()
        return 0

    with LOCK.open("a+") as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("WATER_DISPATCH_DUPLICATE_REFUSED", flush=True)
            return 73
        lock.seek(0)
        lock.truncate()
        lock.write(f"pid={os.getpid()}\n")
        lock.flush()

        checks_ok, checks = baseline_and_source_checks()
        state("waiting_for_air_crossing", checks=checks)
        event("conditional_wait_started", checks=checks, max_wait_s=MAX_WAIT_S)
        if not checks_ok:
            state("stopped_baseline_or_source_check", checks=checks)
            return 3

        deadline = time.monotonic() + MAX_WAIT_S
        while time.monotonic() < deadline:
            if LOCAL_PAUSE.exists():
                state("paused", reason=f"local pause sentinel {LOCAL_PAUSE}")
                return 2
            if (RUN / "water-dispatcher-stop").exists():
                state("paused", reason="water-dispatcher-stop sentinel")
                return 2

            remote_rc, remote_output, remote_error = ssh_script(SSH_LIVE)
            nonfinite = "NONFINITE_TOKEN_FOUND" in remote_output
            if remote_rc == 0 and "CONTAINER_GONE" not in remote_output:
                lines = remote_output.splitlines()
                status_line = next(
                    (line for line in lines if line.startswith("{") and "solver_time_s" in line),
                    None,
                )
                if status_line is not None:
                    try:
                        live = json.loads(status_line)
                    except json.JSONDecodeError:
                        live = {}
                    if eligible_status(live, nonfinite=nonfinite):
                        state("air_crossed_0p20_healthy", air_status=live, checks=checks)
                        event("air_crossing_observed", air_status=live)
                        break
                    if (
                        live.get("state") == "terminal"
                        and live.get("guard_reason") != "horizon_end"
                    ):
                        state("stopped_air_terminal_before_healthy_crossing", air_status=live)
                        return 4
            elif remote_rc != 0:
                event("air_status_unavailable", stderr=remote_error[-400:])

            final_ok, final_summary = final_air_result_eligible()
            if final_ok:
                state(
                    "air_crossed_0p20_healthy_after_completion",
                    air_status=final_summary,
                    checks=checks,
                )
                event("air_final_eligible", air_status=final_summary)
                break
            if (AIR_OUTPUT / "run-result.json").is_file():
                state("stopped_air_terminal_before_healthy_crossing", air_status=final_summary)
                return 4
            time.sleep(POLL_S)
        else:
            state("bounded_wait_expired", wait_s=MAX_WAIT_S)
            return 5

        if LOCAL_PAUSE.exists() or (RUN / "water-dispatcher-stop").exists():
            state("paused_before_water_go", reason="pause or stop sentinel present")
            return 2
        capacity_rc, capacity_output, capacity_error = ssh_script(SSH_CAPACITY, timeout=15)
        if capacity_rc != 0 or "PAUSED_GOBLIN" in capacity_output:
            state("capacity_or_pause_check_failed", output=capacity_output, error=capacity_error)
            return 6
        available_match = re.search(r"AVAILABLE=([0-9]+(?:\.[0-9]+)?)", capacity_output)
        if not available_match or float(available_match.group(1)) < 8.0:
            state("insufficient_capacity_for_eight_ranks", sample=capacity_output)
            return 7
        event("water_capacity_admitted", sample=capacity_output)

        rc, result = run_water()
        if rc != 0 or result is None:
            state("water_branch_failed_or_incomplete", wrapper_exit_code=rc)
            return 8
        state(
            "complete",
            water_terminal=result.get("terminal"),
            water_guard=result.get("guard"),
            snapshot_inventory=result.get("snapshot_inventory"),
        )
        event("water_branch_complete", terminal=result.get("terminal"))
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
