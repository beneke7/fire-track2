#!/usr/bin/env python3
"""Prepare the fixed-0.0003 s water-nozzle cost/robustness case, no launch."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

RUN = Path(__file__).resolve().parent
REFERENCE = RUN / "air-backflow-water-030"
DESTINATION = RUN / "air-backflow-water-dt0003-030"
DELTA_T_S = 0.0003
HORIZON_S = 0.3
EXPECTED_STEPS = 1000


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def hashes(root: Path, *, exclude: tuple[str, ...] = ()) -> dict[str, str]:
    skipped = set(exclude)
    return {
        path.relative_to(root).as_posix(): sha(path)
        for path in sorted(root.rglob("*"))
        if path.is_file() and path.relative_to(root).as_posix() not in skipped
    }


def main() -> int:
    if DESTINATION.exists():
        raise FileExistsError(f"refusing to overwrite prepared cost case: {DESTINATION}")
    reference_meta = json.loads((REFERENCE / "case-inputs.json").read_text(encoding="utf-8"))
    shutil.copytree(REFERENCE, DESTINATION)

    control_path = DESTINATION / "system/controlDict"
    original_control = control_path.read_text(encoding="utf-8")
    modified_control, count = re.subn(
        r"(?m)^deltaT\s+0\.0001;\s*$", "deltaT 0.0003;", original_control
    )
    if count != 1:
        raise ValueError(f"expected one fixed deltaT=0.0001 entry, found {count}")
    control_path.write_text(modified_control, encoding="utf-8")

    metadata_path = DESTINATION / "case-inputs.json"
    metadata: dict[str, Any] = json.loads(metadata_path.read_text(encoding="utf-8"))
    metadata.update(
        {
            "case_id": "ROUAIX-WATER-NOZZLE-ORIGINAL-01000-BACKFLOW-PTOTAL0-DT0003-08RANK",
            "queue_run_name": DESTINATION.name,
            "delta_t_s": DELTA_T_S,
            "expected_steps": EXPECTED_STEPS,
            "end_time_s": HORIZON_S,
            "runtime_guard": {
                **metadata["runtime_guard"],
                "max_abs_U_m_s": 200.0,
                "hard_wall_seconds": 900,
                "grace_seconds": 120,
            },
            "guard_note": "200 m/s operational cutoff only; fields are not clipped",
            "time_step_diagnostic": (
                "Fixed-deltaT cost and robustness sensitivity against the matched 0.0001 s water-nozzle case; "
                "no adaptive stepping or physics changes."
            ),
            "reference_case": REFERENCE.name,
            "reference_case_inputs_sha256": sha(REFERENCE / "case-inputs.json"),
            "preparation_script_sha256": sha(Path(__file__)),
        }
    )
    if abs(HORIZON_S / DELTA_T_S - EXPECTED_STEPS) > 1e-12:
        raise AssertionError("declared fixed time step does not produce 1,000 steps")
    if (
        metadata["runtime_guard"]["max_abs_U_m_s"]
        != reference_meta["runtime_guard"]["max_abs_U_m_s"]
    ):
        raise AssertionError("operational speed guard differs from the matched reference")
    metadata["case_files_sha256"] = hashes(DESTINATION, exclude=("case-inputs.json",))
    metadata["case_files_total_bytes"] = sum(
        path.stat().st_size
        for path in DESTINATION.rglob("*")
        if path.is_file() and path.name != "case-inputs.json"
    )
    metadata_path.write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    reference_files = hashes(REFERENCE)
    candidate_files = hashes(DESTINATION)
    if set(reference_files) != set(candidate_files):
        raise AssertionError("time-step case file inventory differs from reference")
    changed = {
        name
        for name in reference_files
        if name not in {"system/controlDict", "case-inputs.json"}
        and reference_files[name] != candidate_files[name]
    }
    if changed:
        raise AssertionError(f"unexpected non-time-step input changes: {sorted(changed)}")
    normalized = modified_control.replace("deltaT 0.0003;", "deltaT 0.0001;")
    if normalized != original_control:
        raise AssertionError("controlDict differs by more than its fixed deltaT value")
    if metadata.get("mesh_files_sha256") != reference_meta.get("mesh_files_sha256"):
        raise AssertionError("time-step case mesh hash differs from matched reference")
    for key in (
        "mpi_ranks",
        "momentum_convection",
        "source_mode",
        "initial_condition",
        "field_write_times_s",
        "nozzle_velocity_m_s",
        "gas_inlet_velocity_m_s",
    ):
        if metadata.get(key) != reference_meta.get(key):
            raise AssertionError(f"matched physical metadata changed: {key}")
    if metadata.get("mpi_ranks") != 8 or metadata.get("expected_steps") != 1000:
        raise AssertionError("time-step case rank/step count does not match its declaration")

    receipt = {
        "schema_version": 1,
        "prepared_utc": datetime.now(UTC).isoformat(),
        "status": "prepared_only_not_launched",
        "case": DESTINATION.name,
        "reference_case": REFERENCE.name,
        "case_inputs_sha256": sha(metadata_path),
        "changed_case_files": ["system/controlDict", "case-inputs.json"],
        "control_dictionary_change": {"deltaT_from_s": 0.0001, "deltaT_to_s": DELTA_T_S},
        "horizon_s": HORIZON_S,
        "expected_steps": EXPECTED_STEPS,
        "mpi_ranks": metadata["mpi_ranks"],
        "runtime_guard_m_s": metadata["runtime_guard"]["max_abs_U_m_s"],
        "hard_wall_s": metadata["runtime_guard"]["hard_wall_seconds"],
        "grace_s": metadata["runtime_guard"]["grace_seconds"],
        "mesh_files_sha256": metadata["mesh_files_sha256"],
        "no_solver_started": True,
    }
    (RUN / "water-dt0003-prepared-only.json").write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(receipt, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
