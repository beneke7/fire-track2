#!/usr/bin/env python3
"""Prepare the matched static-pressure water-nozzle control, without launching it."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
SOURCE_ROOT = RUN / "source-code"
sys.path.insert(0, str(SOURCE_ROOT))
from cases.e1_rouaix_fast_diagnostics import build_cases  # noqa: E402

TOTAL_CASE = RUN / "air-backflow-water-030"
DESTINATION = RUN / "air-backflow-water-static-030"
STATIC_REFERENCE = (
    ROOT
    / "results/runs/rouaix-fast-local-20261027/cases-and-runs/attempt-003/air-original-030/0/p_rgh"
)
SOURCE_ALPHA = SOURCE_ROOT / "cases/e1_rouaix_case1_static/case/0/alpha.water"
PATCHES = ("downstreamOutlet", "bottomOutlet", "spanwiseMinus", "spanwisePlus")


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def patch_block(text: str, name: str) -> str:
    match = re.findall(rf"(?ms)^    {re.escape(name)}\s*\{{.*?^    \}}", text)
    if len(match) != 1:
        raise ValueError(f"expected one p_rgh block for {name}, found {len(match)}")
    return match[0]


def replace_patch(text: str, name: str, replacement: str) -> str:
    pattern = re.compile(rf"(?ms)^    {re.escape(name)}\s*\{{.*?^    \}}")
    result, count = pattern.subn(lambda _: replacement, text)
    if count != 1:
        raise ValueError(f"expected one replacement target for {name}, found {count}")
    return result


def main() -> int:
    if DESTINATION.exists():
        raise FileExistsError(f"refusing to overwrite prepared case: {DESTINATION}")
    total_meta = json.loads((TOTAL_CASE / "case-inputs.json").read_text(encoding="utf-8"))
    reference_text = STATIC_REFERENCE.read_text(encoding="utf-8")
    target_p_path = TOTAL_CASE / "0/p_rgh"
    p_text = target_p_path.read_text(encoding="utf-8")
    for patch in PATCHES:
        reference = patch_block(reference_text, patch)
        candidate = patch_block(p_text, patch)
        if "type            prghPressure;" not in reference:
            raise ValueError(f"static reference patch {patch} is not prghPressure")
        if "type            prghTotalPressure;" not in candidate:
            raise ValueError(f"total-pressure case patch {patch} is not prghTotalPressure")

    shutil.copytree(TOTAL_CASE, DESTINATION)
    static_p_path = DESTINATION / "0/p_rgh"
    static_text = p_text
    for patch in PATCHES:
        static_text = replace_patch(static_text, patch, patch_block(reference_text, patch))
    static_p_path.write_text(static_text, encoding="utf-8")

    alpha_text = (DESTINATION / "0/alpha.water").read_text(encoding="utf-8")
    nozzle = re.findall(r"(?ms)^    nozzle\s*\{.*?^    \}", alpha_text)
    if len(nozzle) != 1 or "value           uniform 1;" not in nozzle[0]:
        raise ValueError("static control lost source-case nozzle alpha=1 condition")
    if "internalField   uniform 0;" not in alpha_text:
        raise ValueError("static control must retain bulk-air alpha=0 initial field")

    metadata_path = DESTINATION / "case-inputs.json"
    metadata: dict[str, Any] = json.loads(metadata_path.read_text(encoding="utf-8"))
    metadata.update(
        {
            "case_id": "ROUAIX-WATER-NOZZLE-ORIGINAL-03000-BACKFLOW-STATIC0-08RANK",
            "queue_run_name": DESTINATION.name,
            "pressure_boundary_variant": "matched static prghPressure p=0 control",
            "boundary_diagnostic_note": (
                "Matched fresh water-nozzle control for the total-pressure branch; only the four open "
                "p_rgh patch blocks and case metadata differ. All other case files are byte-identical."
            ),
            "runtime_guard": {
                **metadata["runtime_guard"],
                "max_abs_U_m_s": 200.0,
            },
            "guard_note": "operational max|U| cutoff only; fields are not clipped",
            "matched_total_pressure_case": TOTAL_CASE.name,
            "matched_total_pressure_case_inputs_sha256": sha(TOTAL_CASE / "case-inputs.json"),
            "static_pressure_reference_sha256": sha(STATIC_REFERENCE),
            "static_control_preparation_script_sha256": sha(Path(__file__)),
        }
    )
    metadata["case_files_sha256"] = build_cases.tree_hashes(
        DESTINATION, exclude=("case-inputs.json",)
    )
    metadata["case_files_total_bytes"] = sum(
        path.stat().st_size
        for path in DESTINATION.rglob("*")
        if path.is_file() and path.name != "case-inputs.json"
    )
    metadata_path.write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    total_files = {
        path.relative_to(TOTAL_CASE).as_posix(): path
        for path in TOTAL_CASE.rglob("*")
        if path.is_file()
    }
    static_files = {
        path.relative_to(DESTINATION).as_posix(): path
        for path in DESTINATION.rglob("*")
        if path.is_file()
    }
    if set(total_files) != set(static_files):
        raise AssertionError("static control file inventory differs from total-pressure sibling")
    changed_other = {
        name
        for name in total_files
        if name not in {"0/p_rgh", "case-inputs.json"}
        and sha(total_files[name]) != sha(static_files[name])
    }
    if changed_other:
        raise AssertionError(f"unexpected non-pressure case changes: {sorted(changed_other)}")
    normalized_total = p_text
    normalized_static = static_text
    for patch in PATCHES:
        normalized_total = replace_patch(
            normalized_total, patch, f"    {patch}\n    {{\n        BLOCK\n    }}"
        )
        normalized_static = replace_patch(
            normalized_static, patch, f"    {patch}\n    {{\n        BLOCK\n    }}"
        )
        if patch_block(static_text, patch) != patch_block(reference_text, patch):
            raise AssertionError(f"static p_rgh patch {patch} does not match immutable original")
    if normalized_total != normalized_static:
        raise AssertionError(
            "static and total-pressure p_rgh files differ outside the four patch blocks"
        )

    for key in (
        "delta_t_s",
        "expected_steps",
        "field_write_times_s",
        "initial_condition",
        "momentum_convection",
        "mpi_ranks",
        "nozzle_velocity_m_s",
        "gas_inlet_velocity_m_s",
        "source_mode",
    ):
        if total_meta.get(key) != metadata.get(key):
            raise AssertionError(f"matched physical metadata changed: {key}")
    if metadata.get("expected_steps") != 3000 or metadata.get("mpi_ranks") != 8:
        raise AssertionError("static water control is not the declared 3000-step, 8-rank case")
    if metadata.get("runtime_guard", {}).get("max_abs_U_m_s") != 200.0:
        raise AssertionError("static water control guard differs from the paired run")

    record = {
        "schema_version": 1,
        "prepared_utc": datetime.now(UTC).isoformat(),
        "status": "prepared_only_not_launched",
        "case": DESTINATION.name,
        "matched_total_pressure_case": TOTAL_CASE.name,
        "case_inputs_sha256": sha(metadata_path),
        "changed_case_files_from_total_pressure_sibling": ["0/p_rgh", "case-inputs.json"],
        "changed_pressure_patches": list(PATCHES),
        "static_reference_sha256": sha(STATIC_REFERENCE),
        "mesh_files_sha256": metadata["mesh_files_sha256"],
        "mpi_ranks": metadata["mpi_ranks"],
        "expected_steps": metadata["expected_steps"],
        "delta_t_s": metadata["delta_t_s"],
        "runtime_guard_m_s": metadata["runtime_guard"]["max_abs_U_m_s"],
        "source_nozzle_alpha": "fixedValue uniform 1",
        "bulk_alpha_initial": "uniform 0",
        "no_solver_started": True,
    }
    (RUN / "water-static-control-prepared-only.json").write_text(
        json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(record, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
