#!/usr/bin/env python3
"""Prepare immutable 8-rank all-air backflow smoke and target branches."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
SOURCE_ROOT = RUN / "source-code"

sys.path.insert(0, str(SOURCE_ROOT))
from cases.e1_rouaix_fast_diagnostics import build_cases  # noqa: E402


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def update_metadata(case_dir: Path, *, guard_m_s: float, guard_note: str) -> dict:
    metadata_path = case_dir / "case-inputs.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    metadata["queue_run_name"] = case_dir.name
    metadata["runtime_guard"]["max_abs_U_m_s"] = guard_m_s
    metadata["guard_note"] = guard_note
    metadata["mesh_qa_sha256"] = sha(RUN / "mesh-qa.json")
    metadata["mesh_input_sha256"] = sha(RUN / "mesh-input/mesh-input.json")
    metadata["case_files_sha256"] = build_cases.tree_hashes(case_dir, exclude=("case-inputs.json",))
    metadata["case_files_total_bytes"] = sum(
        path.stat().st_size
        for path in case_dir.rglob("*")
        if path.is_file() and path.name != "case-inputs.json"
    )
    metadata_path.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")
    return metadata


def main() -> int:
    mesh_dir = RUN / "native-mesh"
    mesh_files = build_cases.tree_hashes(mesh_dir)
    if not mesh_files or len(mesh_files) != 8:
        raise ValueError(f"unexpected frozen mesh file inventory: {len(mesh_files)}")
    specs = (
        ("air-backflow-save-smoke", 0.01, 70.0, "checkpoint signal smoke; operational cutoff only"),
        ("air-backflow-030", 0.30, 200.0, "target operational cutoff; does not clip fields"),
    )
    cases = {}
    for name, horizon_s, guard_m_s, guard_note in specs:
        destination = RUN / name
        metadata = build_cases.write_case(
            destination,
            "original",
            horizon_s=horizon_s,
            ranks=8,
            backflow_total_pressure=True,
        )
        build_cases.attach_mesh(destination, mesh_dir)
        metadata = update_metadata(destination, guard_m_s=guard_m_s, guard_note=guard_note)
        if len(metadata["mesh_files_sha256"]) != len(mesh_files):
            raise ValueError(f"mesh inventory changed while preparing {name}")
        if metadata["expected_steps"] != round(horizon_s / metadata["delta_t_s"]):
            raise ValueError(f"step horizon mismatch for {name}")
        cases[name] = {
            "case_id": metadata["case_id"],
            "horizon_s": horizon_s,
            "expected_steps": metadata["expected_steps"],
            "mpi_ranks": metadata["mpi_ranks"],
            "guard_m_s": guard_m_s,
            "guard_note": guard_note,
            "case_inputs_sha256": sha(destination / "case-inputs.json"),
            "case_files_sha256": metadata["case_files_sha256"],
        }

    result = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, capture_output=True, check=True
    )
    status = subprocess.run(
        ["git", "status", "--porcelain"], cwd=ROOT, text=True, capture_output=True, check=True
    )
    manifest = {
        "schema_version": 1,
        "prepared_utc": datetime.now(UTC).isoformat(),
        "git_revision": result.stdout.strip(),
        "git_dirty": bool(status.stdout.strip()),
        "git_status_porcelain": status.stdout.splitlines(),
        "solver": "OpenCFD v2512 interIsoFoam",
        "container_image_digest": build_cases.IMAGE_ID,
        "cpu_only": True,
        "mpi_ranks": 8,
        "openfoam_file_handler": "collated",
        "mesh_qa_sha256": sha(RUN / "mesh-qa.json"),
        "mesh_input_sha256": sha(RUN / "mesh-input/mesh-input.json"),
        "mesh_files_sha256": mesh_files,
        "source_sha256": {
            str(path.relative_to(SOURCE_ROOT)): sha(path)
            for path in sorted(SOURCE_ROOT.rglob("*"))
            if path.is_file() and "__pycache__" not in path.parts
        },
        "preparation_script_sha256": sha(Path(__file__)),
        "cases": cases,
    }
    (RUN / "preparation-manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps({"prepared_utc": manifest["prepared_utc"], "cases": cases}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
