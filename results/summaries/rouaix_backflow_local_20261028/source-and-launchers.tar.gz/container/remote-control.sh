#!/usr/bin/env bash
set -Eeuo pipefail
phase=${1:?phase required}
name=${2:?container name required}
input=${3:?remote input directory required}
work=${4:?remote work directory required}
cpus=${5:-1}
mem=${6:-3g}
stage=${7:-mesh}
image=sha256:f5080db350a74a6130f248e2fd4d4fd1a8bd9309054b49ca160afe45a4d0c45b
remote_root=/home/v/proj/bene/fire-track2/results/runs/rouaix-backflow-local-20261028/remote/q20261028
[[ $name =~ ^rouaix-backflow-[a-z0-9-]+$ ]] || { echo invalid_container_name >&2; exit 2; }
[[ $input == "$remote_root"/staging/rouaix-backflow-* ]] || { echo input_path_outside_owned_durable_area >&2; exit 2; }
[[ $work == "$remote_root"/containers/rouaix-backflow-* ]] || { echo work_path_outside_owned_durable_area >&2; exit 2; }
[[ $cpus =~ ^[1-8]$ ]] || { echo invalid_cpu_limit >&2; exit 2; }
[[ $mem == 3g ]] || { echo invalid_memory_limit >&2; exit 2; }
container_exists() { docker container inspect "$name" >/dev/null 2>&1; }
container_running() { [[ $(docker container inspect --format '{{.State.Running}}' "$name" 2>/dev/null || true) == true ]]; }
report_early_exit() {
  docker logs "$name" >&2 2>&1 || true
  if [[ -d $work/failure ]]; then
    find "$work/failure" -type f -maxdepth 3 -print -exec cat {} \; >&2
  fi
}
case $phase in
  prepare)
    [[ -d $input ]] || { echo missing_input_directory >&2; exit 10; }
    if container_exists; then echo "refusing existing container $name" >&2; exit 11; fi
    mkdir -p "$work"
    chmod 0777 "$work"
    available=$(df --output=avail -B1 /home/v/proj/bene/fire-track2/results | tail -n 1 | tr -d ' ')
    [[ $available =~ ^[0-9]+$ ]] && (( available >= 20 * 1024 * 1024 * 1024 )) || {
      echo durable_output_disk_floor_below_20GiB >&2; exit 16;
    }
    docker create --log-driver=none \
      --name "$name" --network none --cpus="$cpus" \
      --memory="$mem" --memory-swap="$mem" --pids-limit=256 \
      --tmpfs /workspace:rw,nosuid,size=2g,mode=1777 \
      --mount "type=bind,src=$input,dst=/input,readonly" \
      --mount "type=bind,src=$work,dst=/rescue" \
      --env "RUN_STAGE=$stage" --env "SOLVER_RANKS=$cpus" \
      --env FOAM_FILEHANDLER=collated \
      --env OMP_NUM_THREADS=1 --env OMP_THREAD_LIMIT=1 \
      --env OPENBLAS_NUM_THREADS=1 --env MKL_NUM_THREADS=1 --env NUMEXPR_NUM_THREADS=1 \
      --workdir /workspace --cap-drop=ALL --security-opt=no-new-privileges \
      --entrypoint /bin/bash "$image" /input/container-start.sh >/dev/null
    [[ $(docker inspect --format '{{.HostConfig.LogConfig.Type}}' "$name") == none ]] || {
      echo docker_log_driver_not_disabled >&2; exit 17;
    }
    docker start "$name" >/dev/null
    if [[ $stage == mesh ]]; then
      ready=0
      for _ in $(seq 1 2400); do
        if ! container_exists; then echo mesh_container_exited_before_archive >&2; exit 13; fi
        if ! container_running; then report_early_exit; echo mesh_container_exited_before_archive >&2; exit 13; fi
        if docker exec "$name" test -f /workspace/DONE 2>/dev/null; then ready=1; break; fi
        sleep 0.25
      done
      [[ $ready == 1 ]] || { echo mesh_stage_timeout >&2; exit 14; }
      printf 'MESH_DONE\t%s\t%s\n' \
        "$(docker inspect --format '{{.Id}}' "$name")" \
        "$(docker inspect --format '{{.State.StartedAt}}' "$name")"
    else
      ready=0
      for _ in $(seq 1 120); do
        if ! container_exists; then echo container_exited_during_preflight >&2; exit 12; fi
        if ! container_running; then report_early_exit; echo container_exited_during_preflight >&2; exit 12; fi
        if docker exec "$name" test -s /workspace/READY.json 2>/dev/null; then ready=1; break; fi
        sleep 0.25
      done
      [[ $ready == 1 ]] || { echo solver_preflight_timeout >&2; exit 15; }
      printf 'PREPARED\t%s\t%s\n' \
        "$(docker inspect --format '{{.Id}}' "$name")" \
        "$(docker inspect --format '{{.State.StartedAt}}' "$name")"
      docker exec "$name" cat /workspace/READY.json
    fi
    ;;
  go)
    container_exists || { echo container_missing_before_go >&2; exit 20; }
    [[ -s $work/pre-go-manifest.json ]] || { echo pre_go_manifest_missing >&2; exit 21; }
    docker exec -i "$name" /bin/sh -c 'cat > /workspace/pre-go-manifest.json' \
      < "$work/pre-go-manifest.json"
    local_sha=$(sha256sum "$work/pre-go-manifest.json" | awk '{print $1}')
    container_sha=$(docker exec "$name" sha256sum /workspace/pre-go-manifest.json | awk '{print $1}')
    [[ $local_sha == "$container_sha" ]] || { echo pre_go_manifest_hash_mismatch >&2; exit 22; }
    docker exec "$name" touch /workspace/GO
    echo GO_RELEASED
    ;;
  guard-selftest)
    container_running || { echo container_missing_before_guard_selftest >&2; exit 23; }
    threshold=$(docker exec "$name" sed -n -E 's/.*"max_abs_U_m_s": ([0-9]+([.][0-9]+)?).*/\1/p' /workspace/case/case-inputs.json | head -n 1)
    [[ $threshold =~ ^[0-9]+([.][0-9]+)?$ ]] || { echo invalid_U_guard_threshold >&2; exit 24; }
    docker exec -e "GUARD_THRESHOLD_M_S=$threshold" "$name" /bin/bash /input/solver-supervisor.sh --selftest
    ;;
  pause-request)
    container_running || { echo container_not_running_for_pause >&2; exit 41; }
    docker exec "$name" pkill -USR2 -x interIsoFoam >/dev/null 2>&1 || {
      echo write_and_stop_signal_failed >&2; exit 42;
    }
    echo WRITE_STOP_REQUESTED
    ;;
  status)
    if ! container_exists; then echo CONTAINER_GONE; exit 0; fi
    if docker exec "$name" test -f /workspace/DONE 2>/dev/null; then
      printf 'DONE\t'
      docker exec "$name" cat /workspace/status.json
      exit 0
    fi
    if docker exec "$name" test -s /workspace/status.json 2>/dev/null; then
      docker exec "$name" cat /workspace/status.json
    else
      echo '{"state":"starting"}'
    fi
    ;;
  export)
    mkdir -p "$work"
    if container_exists; then
      [[ $(docker inspect --format '{{.HostConfig.LogConfig.Type}}' "$name") == none ]] || {
        echo docker_log_driver_not_disabled_before_export >&2; exit 33;
      }
    fi
    if [[ -s $work/result.tar.gz && -s $work/result.tar.gz.sha256 ]]; then
      : # Completed output is mirrored to the owned rescue bind before DONE is written.
    elif container_running && docker exec "$name" test -s /workspace/result.tar.gz 2>/dev/null; then
      docker exec "$name" test -f /workspace/DONE || { echo result_not_done >&2; exit 31; }
      docker cp "$name:/workspace/result.tar.gz" "$work/result.tar.gz" >/dev/null
      docker cp "$name:/workspace/result.tar.gz.sha256" "$work/result.tar.gz.sha256" >/dev/null
    else
      echo result_missing_before_export >&2; exit 30
    fi
    (cd "$work" && sha256sum -c result.tar.gz.sha256 >/dev/null)
    archive_bytes=$(stat -c %s "$work/result.tar.gz")
    (( archive_bytes <= 1073741824 )) || { echo result_archive_exceeds_1GiB_per_case_cap >&2; exit 32; }
    printf 'ARCHIVE_READY\t%s\t%s\n' \
      "$(sha256sum "$work/result.tar.gz" | awk '{print $1}')" \
      "$archive_bytes"
    ;;
  release)
    if container_running; then
      docker exec "$name" touch /workspace/STREAMED
      for _ in $(seq 1 240); do
        if ! container_running; then break; fi
        sleep 0.25
      done
    fi
    if container_running; then echo container_did_not_exit_after_stream >&2; exit 40; fi
    if container_exists; then docker rm "$name" >/dev/null; fi
    echo CONTAINER_RELEASED
    ;;
  abort)
    if container_exists; then docker rm --force "$name" >/dev/null; fi
    echo CONTAINER_ABORTED
    ;;
  cleanup)
    if container_exists; then docker rm --force "$name" >/dev/null; fi
    rm -rf -- "$input"
    echo CONTAINER_STOPPED_INPUT_REMOVED_WORK_PRESERVED
    ;;
  *) echo "unknown phase $phase" >&2; exit 2 ;;
esac
