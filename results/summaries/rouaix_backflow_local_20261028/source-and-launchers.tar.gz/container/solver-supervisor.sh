#!/usr/bin/env bash
set -Eeuo pipefail
parse_latest_u() {
    grep -E 'max\(mag\(U\)\)[[:space:]]*=' \
        | tail -n 1 \
        | sed -E 's/.*max\(mag\(U\)\)[[:space:]]*=[[:space:]]*([^[:space:]]+).*/\1/' || true
}
classify_u() {
    local value=$1 threshold=$2
    if [[ -z $value ]]; then
        printf 'missing\n'
    elif grep -Eqi 'nan|inf' <<< "$value"; then
        printf 'nonfinite\n'
    elif awk -v u="$value" -v limit="$threshold" 'BEGIN { exit !(u + 0 > limit) }'; then
        printf 'exceeded\n'
    else
        printf 'below\n'
    fi
}
guard_parser_selftest() {
    local safe high nonfinite missing parser_threshold=1000
    safe=$(printf 'max(mag(U)) = 100\n' | parse_latest_u)
    high=$(printf 'max(mag(U)) = 1.2e3\n' | parse_latest_u)
    nonfinite=$(printf 'max(mag(U)) = -inf\n' | parse_latest_u)
    missing=$(printf 'Time = 0.001\n' | parse_latest_u)
    [[ $safe == 100 && $(classify_u "$safe" "$parser_threshold") == below ]]
    [[ $high == 1.2e3 && $(classify_u "$high" "$parser_threshold") == exceeded ]]
    [[ $nonfinite == -inf && $(classify_u "$nonfinite" "$parser_threshold") == nonfinite ]]
    [[ -z $missing && $(classify_u "$missing" "$parser_threshold") == missing ]]
    printf 'GUARD_PARSER_SELFTEST_PASSED parser_threshold_m_s=%s runtime_guard_m_s=%s\n' \
        "$parser_threshold" "$GUARD_THRESHOLD_M_S"
}
if [[ ${1:-} == --selftest ]]; then
    guard_parser_selftest
    exit 0
fi
case_dir=$1
log=$2
guard_json=$3
status_json=$4
container_start_epoch=$5
guard_threshold=${6:?guard threshold required}
hard_wall_seconds=${7:?hard wall limit required}
grace_seconds=${8:?stop grace required}
[[ $guard_threshold =~ ^[0-9]+([.][0-9]+)?$ ]]
[[ $hard_wall_seconds =~ ^[0-9]+$ && $grace_seconds =~ ^[0-9]+$ ]]
export GUARD_THRESHOLD_M_S=$guard_threshold
solver_ranks=${SOLVER_RANKS:-4}
[[ $solver_ranks =~ ^[1-8]$ ]]
cd "$case_dir"
export OMP_NUM_THREADS=1 OMP_THREAD_LIMIT=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export OMPI_ALLOW_RUN_AS_ROOT=1 OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
mpirun --bind-to none -np "$solver_ranks" interIsoFoam -parallel > "$log" 2>&1 &
solver_pid=$!
trigger_reason=
trigger_value=
trigger_time=
trigger_epoch=
last_status_epoch=0
signal_solver_group() {
    pkill -USR2 -x interIsoFoam >/dev/null 2>&1 || true
}
latest_u() {
    tail -n 400 "$log" 2>/dev/null | parse_latest_u
}
latest_time() {
    tail -n 200 "$log" 2>/dev/null | sed -n -E 's/^Time = ([^[:space:]]+).*/\1/p' | tail -n 1
}
status_write() {
    local now=$1 reached=$2 max_u=$3 reason=$4
    printf '{"state":"running","elapsed_s":%s,"solver_time_s":"%s","max_U_m_s":"%s","guard_reason":"%s"}\n' \
        "$now" "$reached" "$max_u" "$reason" > "$status_json"
}
while kill -0 "$solver_pid" 2>/dev/null; do
    now_epoch=$(date +%s)
    elapsed=$((now_epoch - container_start_epoch))
    current_time=$(latest_time || true)
    current_u=$(latest_u || true)
    if [[ -z $trigger_reason && -n $current_u ]]; then
        u_class=$(classify_u "$current_u" "$guard_threshold")
        if [[ $u_class == nonfinite ]]; then
            trigger_reason=nonfinite_U_guard
            trigger_value=$current_u
            trigger_time=${current_time:-unknown}
            trigger_epoch=$now_epoch
        elif [[ $u_class == exceeded ]]; then
            trigger_reason="max_abs_U_exceeded_${guard_threshold}_m_s"
            trigger_value=$current_u
            trigger_time=${current_time:-unknown}
            trigger_epoch=$now_epoch
        fi
        if [[ -n $trigger_reason ]]; then
            signal_solver_group
        fi
    fi
    if [[ -z $trigger_reason && $elapsed -ge $hard_wall_seconds ]]; then
        trigger_reason=hard_30_minute_wall_deadline
        trigger_value=${current_u:-unknown}
        trigger_time=${current_time:-unknown}
        trigger_epoch=$now_epoch
        signal_solver_group
    fi
    if [[ -n $trigger_reason && $((now_epoch - trigger_epoch)) -ge $grace_seconds ]]; then
        pkill -TERM -x interIsoFoam >/dev/null 2>&1 || true
        kill -TERM "$solver_pid" >/dev/null 2>&1 || true
        sleep 10
        pkill -KILL -x interIsoFoam >/dev/null 2>&1 || true
        kill -KILL "$solver_pid" >/dev/null 2>&1 || true
        break
    fi
    if [[ $((now_epoch - last_status_epoch)) -ge 10 ]]; then
        status_write "$elapsed" "${current_time:-unknown}" "${current_u:-unknown}" "${trigger_reason:-none}"
        last_status_epoch=$now_epoch
    fi
    sleep 0.5
done
set +e
wait "$solver_pid"
solver_exit=$?
set -e
last_time=$(latest_time || true)
last_u=$(latest_u || true)
end_marker=false
grep -q '^End$' "$log" && end_marker=true || true
if [[ -z $trigger_reason ]]; then
    if [[ $end_marker == true ]]; then
        trigger_reason=horizon_end
    else
        trigger_reason=solver_exited_without_end
    fi
fi
printf '{"reason":"%s","trigger_time_s":"%s","trigger_max_U_m_s":"%s","latest_solver_time_s":"%s","latest_max_U_m_s":"%s","threshold_m_s":%s,"hard_deadline_elapsed_s":%s,"write_and_stop_signal":12,"end_marker":%s,"solver_exit_code":%s,"log":"%s"}\n' \
    "$trigger_reason" "${trigger_time:-unknown}" "${trigger_value:-unknown}" \
    "${last_time:-unknown}" "${last_u:-unknown}" "$guard_threshold" \
    "$(( $(date +%s) - container_start_epoch ))" "$end_marker" "$solver_exit" "$(basename "$log")" > "$guard_json"
printf '{"state":"terminal","solver_exit_code":%s,"end_marker":%s,"solver_time_s":"%s","max_U_m_s":"%s","guard_reason":"%s"}\n' \
    "$solver_exit" "$end_marker" "${last_time:-unknown}" "${last_u:-unknown}" "$trigger_reason" > "$status_json"
exit 0
