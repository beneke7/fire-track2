#!/usr/bin/env python3
"""Durably run the save smoke, then the fresh 0.30 s backflow branch."""

from __future__ import annotations

import argparse
import fcntl
import json
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
PYTHON = ROOT / ".venv/bin/python"
RUN_LOCAL = ROOT / "scripts/run_local.py"
RUNNER = RUN / "run_remote.py"
STATE = RUN / "dispatcher-state.json"
EVENTS = RUN / "dispatcher-events.jsonl"
LOCK = RUN / "dispatcher.lock"
LOCAL_PAUSE = ROOT / "PAUSE"
CASES = ("air-backflow-save-smoke", "air-backflow-030")


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def event(kind: str, **fields: Any) -> None:
    record = {"utc": utc_now(), "event": kind, **fields}
    with EVENTS.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, sort_keys=True) + "\n")
    print(json.dumps(record, sort_keys=True), flush=True)


def state(status: str, **fields: Any) -> None:
    record = {"schema_version": 1, "state": status, "updated_utc": utc_now(), **fields}
    temporary = STATE.with_suffix(".tmp")
    temporary.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, STATE)


def run_case(case: str) -> tuple[int, dict[str, Any] | None]:
    log = RUN / f"{case}.runner.log"
    command = [
        str(PYTHON),
        str(RUN_LOCAL),
        "--threads",
        "1",
        "--timeout",
        "2400",
        "--",
        str(PYTHON),
        str(RUNNER),
        "solver",
        "--case",
        case,
        "--cpus",
        "8",
    ]
    event("case_start", case=case, command=command)
    state("case_running", case=case, runner_log=str(log))
    with log.open("w", encoding="utf-8") as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    result_path = RUN / "container-runs" / case / "run-result.json"
    run_result = json.loads(result_path.read_text()) if result_path.is_file() else None
    archive_ok = bool(
        run_result
        and run_result.get("released") is True
        and (RUN / "container-runs" / case / "archive-verification.json").is_file()
    )
    event(
        "case_terminal",
        case=case,
        wrapper_exit_code=result.returncode,
        archive_verified=archive_ok,
        terminal=run_result.get("terminal") if run_result else None,
    )
    return result.returncode, run_result if archive_ok else None


def output_valid(result: dict[str, Any]) -> bool:
    terminal = result.get("terminal") or {}
    inventory = result.get("snapshot_inventory") or {}
    try:
        reached = float(terminal["solver_time_s"])
    except (KeyError, TypeError, ValueError):
        return False
    times = inventory.get("times") or {}
    return (
        not result.get("pause_observed")
        and not result.get("pause_stop_requested")
        and terminal.get("solver_exit_code") == 0
        and terminal.get("end_marker") is True
        and reached > 0
        and inventory.get("passed") is True
        and bool(times)
        and all(
            times.get(time, {}).get(field, {}).get("present")
            for time in times
            for field in ("U", "alpha.water", "p_rgh")
        )
    )


def target_terminal_valid(result: dict[str, Any]) -> bool:
    terminal = result.get("terminal") or {}
    if not output_valid(result):
        return False
    reason = terminal.get("guard_reason")
    if reason == "horizon_end":
        try:
            return abs(float(terminal["solver_time_s"]) - 0.3) <= 1e-10
        except (KeyError, TypeError, ValueError):
            return False
    guard = result.get("guard") or {}
    try:
        return (
            reason == "max_abs_U_exceeded_200.0_m_s"
            and guard.get("reason") == reason
            and guard.get("end_marker") is True
            and guard.get("solver_exit_code") == 0
            and float(guard.get("threshold_m_s")) == 200.0
            and float(guard.get("trigger_max_U_m_s")) > 200.0
            and float(terminal["solver_time_s"]) <= 0.3 + 1e-10
        )
    except (KeyError, TypeError, ValueError):
        return False


def _selftest() -> None:
    fields = {name: {"present": True} for name in ("U", "alpha.water", "p_rgh")}
    result = {
        "terminal": {
            "solver_exit_code": 0,
            "end_marker": True,
            "solver_time_s": "0.200000000000",
            "guard_reason": "max_abs_U_exceeded_200.0_m_s",
        },
        "guard": {
            "reason": "max_abs_U_exceeded_200.0_m_s",
            "threshold_m_s": 200.0,
            "trigger_max_U_m_s": "205.0",
            "end_marker": True,
            "solver_exit_code": 0,
        },
        "snapshot_inventory": {"passed": True, "times": {"0": fields, "0.2": fields}},
    }
    assert output_valid(result)
    assert target_terminal_valid(result)
    result["snapshot_inventory"]["times"] = {}
    assert not output_valid(result)
    print("BACKFLOW_DISPATCH_SELFTEST_PASSED", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args()
    if args.selftest:
        _selftest()
        return 0
    RUN.mkdir(parents=True, exist_ok=True)
    with LOCK.open("a+") as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("QUEUE_DUPLICATE_REFUSED", flush=True)
            return 73
        lock.seek(0)
        lock.truncate()
        lock.write(f"pid={os.getpid()}\n")
        lock.flush()

        if LOCAL_PAUSE.exists():
            state("paused", reason=f"local pause sentinel {LOCAL_PAUSE}")
            return 2
        event("queue_started", cases=list(CASES), started_utc=utc_now())
        for index, case in enumerate(CASES):
            if LOCAL_PAUSE.exists():
                state("paused", stage=case, reason=f"local pause sentinel {LOCAL_PAUSE}")
                return 2
            rc, result = run_case(case)
            if rc != 0 or result is None or not output_valid(result):
                state("stopped_invalid_or_incomplete", stage=case, wrapper_exit_code=rc)
                return 3
            if index == 0:
                guard = result.get("guard") or {}
                save_test = (
                    guard.get("reason") == "max_abs_U_exceeded_70.0_m_s"
                    and guard.get("end_marker") is True
                    and guard.get("solver_exit_code") == 0
                    and float(guard.get("threshold_m_s", -1)) == 70.0
                )
                state(
                    "pilot_complete_starting_target",
                    stage=case,
                    checkpoint_signal_exercised=save_test,
                    terminal=result.get("terminal"),
                    snapshot_inventory=result.get("snapshot_inventory"),
                )
                event("pilot_complete", checkpoint_signal_exercised=save_test)
                continue
            if not target_terminal_valid(result):
                state(
                    "target_terminal_requires_review",
                    stage=case,
                    terminal=result.get("terminal"),
                    guard=result.get("guard"),
                    snapshot_inventory=result.get("snapshot_inventory"),
                )
                return 4
            state(
                "complete",
                stage=case,
                terminal=result.get("terminal"),
                guard=result.get("guard"),
                snapshot_inventory=result.get("snapshot_inventory"),
            )
        event("queue_complete")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
