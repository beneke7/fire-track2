# Rouaix local backflow pressure sensitivity — 28 October 2026

Predeclared exploratory CPU diagnostic. This is not an E1 gate, a paper
boundary-condition correction, or a validation result.

## Question and evidence

Test whether the four open-boundary pressure patches contribute to the
coarse all-air corner-speed blow-up. The prior 299,520-cell all-air runs using
`prghPressure` stopped at the downstream/top/positive-span corner at 0.1752 s
(original momentum scheme) and 0.1960 s (upwind). Upwind alone did not remove
the failure. The source review in
`results/summaries/rouaix_restart_controls_20261027/outlet-control-review.md`
recommends this pressure-energy sensitivity.

The fresh candidate starts from the same all-air `t=0` inputs and mesh. Change
only `p_rgh` on downstreamOutlet, bottomOutlet, spanwiseMinus, and spanwisePlus
from `prghPressure` (`p uniform 0`) to gravity-aware `prghTotalPressure` with
`p0 uniform 0`, `rho rho`, `U U`, `phi phi`, `value uniform 0`. Keep all four
`pressureInletOutletVelocity` entries and their tangential velocity unchanged.
This preserves zero outflow gauge and subtracts reverse-flow dynamic head; at
air density 1.18 kg/m³ and speed 70 m/s the term is 2.891 kPa. It is a
deliberate backflow-energy sensitivity, not an ambient-total-pressure match.

## Matched inputs and observable

- Solver: OpenCFD v2512 `interIsoFoam`, image
  `sha256:f5080db350a74a6130f248e2fd4d4fd1a8bd9309054b49ca160afe45a4d0c45b`.
- Mesh: previously native-QA'd coarse full-domain mesh, 299,520 cells; copied
  from the immutable `rouaix-fast-local-20261027/cases-and-runs/attempt-003`
  preparation. No remeshing or field interpolation.
- Fresh initial state: `alpha.water=0` in the domain and nozzle, retained
  source-case velocity and realizable k-epsilon fields. This is an all-air
  negative control, not a water discharge case.
- Original momentum convection `limitedLinearV 1`; all other schemes,
  material inputs, geometry, time step and boundaries match the prior
  `air-original-030` case. Fixed `deltaT=0.0001 s`, 8 MPI ranks, collated I/O.
- Target horizon: 0.3000 s (3,000 steps), subject to a 1,680 s solver wall
  bound plus 120 s graceful-signal window. The target's operational U guard is
  200 m/s. It requests OpenFOAM's configured write-and-stop signal; it does not
  clip or alter fields. The historical static-pressure baseline used a
  1,000 m/s guard, so compare raw traces only at shared times and report the
  differing operational stop thresholds.
- Before the target, run a separately labelled fresh `t=0` checkpoint smoke
  using the same backflow BCs, 8 ranks and mesh, 0.01 s declared horizon, but
  a 70 m/s operational guard. Require OpenFOAM `End`, exit 0, and captured
  `U`, `alpha.water`, and `p_rgh` at `t=0` and the guard-stop time. This tests
  the signal-save path without changing the target branch's 200 m/s guard.
- Record every-step speed/pressure/turbulence extrema with locations, water
  volume, seven signed patch fluxes, two probes, solver iterations and wall
  timing. Retain only initial, endpoint or guard-stop fields; no dense 3D
  history.

## Compute, stop and interpretation

Use Goblin CPU only, up to 8 ranks and 3 GiB container memory, with OMP/BLAS
threads fixed at one. No GPU, HPC queue, or I4F container. Admit only with the
project's 20 GiB floor plus the runner's 1 GiB archive cap and staging space;
current inspection found 96 GiB free, 119 GiB available RAM and 20 effective
CPUs, with no active solver. Profile the target's first 100 steps from its
live log but do not delay launch for another forecast. Stop on nonfinite
diagnostics, an operational U guard, a 600 s no-progress interval, PAUSE, or
the declared wall/disk limit; preserve raw fields and logs for any stop.

Primary comparison: maximum speed and location, pressure and flux traces, and
whether the fresh candidate reaches the same time as the prior original-scheme
baseline. A lower peak alone is not evidence of greater physical accuracy.
Keep the run exploratory; no fitted inputs or acceptance tolerance are used.
