#!/usr/bin/env python3
"""Bounded Goblin Docker runner for the owned Rouaix fast diagnostics."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import shutil
import subprocess
import sys
import tarfile
import time
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
SOURCE_ROOT = RUN / "source-code" if (RUN / "source-code").is_dir() else ROOT
sys.path.insert(0, str(SOURCE_ROOT))
from cases.e1_rouaix_fast_diagnostics import build_cases  # noqa: E402
from cases.e1_rouaix_matched_mesh import mesh_audit  # noqa: E402

CONTAINER_DIR = RUN / "container"
REMOTE_CONTROL = CONTAINER_DIR / "remote-control.sh"
IMAGE_ID = build_cases.IMAGE_ID
SSH = [
    "ssh",
    "-oBatchMode=yes",
    "-oConnectTimeout=10",
    "-oServerAliveInterval=5",
    "-oServerAliveCountMax=1",
    "goblin",
]
RSYNC_SSH = (
    "ssh -oBatchMode=yes -oConnectTimeout=10 -oServerAliveInterval=5 -oServerAliveCountMax=1"
)
REMOTE_BASE = (
    "/home/v/proj/bene/fire-track2/results/runs/rouaix-backflow-local-20261028/remote/q20261028"
)
QUEUE_ID = "q20261028"
GOBLIN_REPO = "/home/v/proj/bene/fire-track2"
PROJECT_PAUSE = ROOT / "PAUSE"
MAX_REMOTE_ARCHIVE_BYTES = 1_073_741_824
MIN_FREE_DISK_BYTES = 20 * 1024**3
CONTAINER_RUNS = RUN / "container-runs"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def run_command(
    command: list[str], *, timeout: float = 120, input_bytes: bytes | None = None
) -> str:
    result = subprocess.run(
        command,
        input=input_bytes,
        capture_output=True,
        timeout=timeout,
        check=False,
    )
    stdout = result.stdout.decode("utf-8", errors="replace")
    stderr = result.stderr.decode("utf-8", errors="replace")
    if result.returncode != 0:
        raise RuntimeError(
            f"command failed ({result.returncode}): {command!r}\nstdout:\n{stdout[-4000:]}\nstderr:\n{stderr[-4000:]}"
        )
    return stdout


def remote(phase: str, name: str, input_dir: str, work_dir: str, cpus: int, stage: str) -> str:
    script = REMOTE_CONTROL.read_bytes()
    return run_command(
        SSH
        + [
            "bash",
            "-s",
            "--",
            phase,
            name,
            input_dir,
            work_dir,
            str(cpus),
            "3g",
            stage,
        ],
        timeout=1200 if phase == "prepare" else 180,
        input_bytes=script,
    )


def active_pause_state() -> tuple[str, str]:
    if PROJECT_PAUSE.exists():
        return "paused", f"local sentinel {PROJECT_PAUSE}"
    checks = (
        (
            SSH,
            f"if [[ -e {GOBLIN_REPO}/PAUSE ]]; then echo PAUSED_GOBLIN; else echo CLEAR_GOBLIN; fi\n",
        ),
    )
    for command, script in checks:
        try:
            output = run_command(
                command + ["bash", "-s"], timeout=15, input_bytes=script.encode()
            ).strip()
        except Exception as error:
            return "unknown", f"active PAUSE check failed: {type(error).__name__}: {error}"
        if output.startswith("PAUSED_"):
            return "paused", output
        if output != "CLEAR_GOBLIN":
            return "unknown", f"malformed active PAUSE check: {output[-300:]}"
    return "clear", "local and Goblin PAUSE checks clear"


def upload(directory: Path, remote_input: str) -> None:
    parent = remote_input.rsplit("/", 1)[0]
    run_command(SSH + ["mkdir", "-p", parent])
    command = [
        "rsync",
        "-avP",
        "-e",
        RSYNC_SSH,
        str(directory) + "/",
        f"goblin:{remote_input}/",
    ]
    result = subprocess.run(command, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        raise RuntimeError(f"rsync input failed: {result.stderr[-4000:]}\n{result.stdout[-1000:]}")
    print(result.stdout, flush=True)


def fetch(remote_path: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise FileExistsError(destination)
    command = ["rsync", "-avP", "-e", RSYNC_SSH, f"goblin:{remote_path}", str(destination)]
    result = subprocess.run(command, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        raise RuntimeError(f"rsync output failed: {result.stderr[-4000:]}\n{result.stdout[-1000:]}")
    print(result.stdout, flush=True)


def fetch_tree(remote_dir: str, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        ["rsync", "-avP", "-e", RSYNC_SSH, f"goblin:{remote_dir}/", str(destination) + "/"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"rsync recovery evidence failed: {result.stderr[-4000:]}\n{result.stdout[-1000:]}"
        )
    print(result.stdout, flush=True)


def prepare_upload(stage: str, case_name: str | None, cpus: int) -> tuple[Path, str, str, str, int]:
    uploads = RUN / "uploads"
    uploads.mkdir(exist_ok=True)
    if stage == "mesh":
        local = uploads / "mesh"
        name = f"rouaix-fast-mesh-20261027-{QUEUE_ID}"
        cpus = 1
        if local.exists():
            raise FileExistsError(local)
        local.mkdir()
        shutil.copytree(RUN / "mesh-input", local / "mesh-input")
    else:
        if case_name is None:
            raise ValueError("solver stage requires --case")
        if not re.fullmatch(r"air-backflow-save-smoke|air-backflow-030", case_name):
            raise ValueError(f"invalid case name {case_name!r}")
        local = uploads / case_name
        name = f"rouaix-backflow-{case_name}-20261028-{QUEUE_ID}"
        if local.exists():
            raise FileExistsError(local)
        local.mkdir()
        shutil.copytree(RUN / case_name, local / "case")
        entries = build_cases.tree_hashes(local / "case")
        (local / "case-files.sha256").write_text(
            "".join(f"{digest}  {path}\n" for path, digest in entries.items()), encoding="utf-8"
        )
    shutil.copy2(CONTAINER_DIR / "container-start.sh", local / "container-start.sh")
    if stage == "solver":
        shutil.copy2(CONTAINER_DIR / "solver-supervisor.sh", local / "solver-supervisor.sh")
    remote_input = f"{REMOTE_BASE}/staging/{name}"
    remote_work = f"{REMOTE_BASE}/containers/{name}"
    return local, name, remote_input, remote_work, cpus


def _safe_extract(archive: Path, destination: Path) -> list[str]:
    destination.mkdir(parents=True, exist_ok=False)
    names = []
    with tarfile.open(archive, "r:gz") as stream:
        members = stream.getmembers()
        for member in members:
            path = PurePosixPath(member.name)
            if path.is_absolute() or ".." in path.parts or not (member.isfile() or member.isdir()):
                raise ValueError(f"unsafe or unsupported archive member: {member.name}")
            names.append(member.name)
        stream.extractall(destination, members=members)
    return names


def _snapshot_inventory(output_dir: Path, case_name: str) -> dict[str, Any]:
    evidence = output_dir / "evidence/case/times"
    metadata = json.loads((RUN / case_name / "case-inputs.json").read_text(encoding="utf-8"))
    declared = {f"{float(value):.12g}" for value in metadata["field_write_times_s"]}
    terminal_path = output_dir / "terminal-status.json"
    terminal_time = None
    if terminal_path.is_file():
        terminal_time = json.loads(terminal_path.read_text(encoding="utf-8")).get("solver_time_s")
        if terminal_time and terminal_time != "unknown":
            terminal_time = f"{float(terminal_time):.12g}"
        else:
            terminal_time = None
    reached_declared = {
        time_value
        for time_value in declared
        if terminal_time is not None and float(time_value) <= float(terminal_time) + 1e-10
    }
    unreached_declared = declared - reached_declared
    expected = set(reached_declared)
    if terminal_time is not None:
        expected.add(terminal_time)
    checks: dict[str, Any] = {}
    for time_value in sorted(expected, key=float):
        checks[time_value] = {}
        for field in ("U", "alpha.water", "p_rgh"):
            matches = (
                [
                    path
                    for path in evidence.rglob(field)
                    if path.is_file()
                    and re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", path.parent.name)
                    and math.isclose(
                        float(path.parent.name), float(time_value), rel_tol=0.0, abs_tol=1e-10
                    )
                ]
                if evidence.is_dir()
                else []
            )
            checks[time_value][field] = {
                "present": bool(matches),
                "paths": [str(path.relative_to(output_dir / "evidence")) for path in matches],
                "bytes": sum(path.stat().st_size for path in matches),
            }
    result = {
        "schema_version": 1,
        "field_handler": "collated",
        "required_fields": ["U", "alpha.water", "p_rgh"],
        "declared_times_s": sorted(declared, key=float),
        "reached_declared_times_s": sorted(reached_declared, key=float),
        "unreached_declared_times_s": sorted(unreached_declared, key=float),
        "terminal_time_s": terminal_time,
        "expected_captured_times_s": sorted(expected, key=float),
        "times": checks,
        "passed": terminal_time is not None
        and bool(checks)
        and all(item["present"] for per_time in checks.values() for item in per_time.values()),
    }
    (output_dir / "snapshot-inventory.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return result


def _resource_sample(name: str) -> dict[str, Any] | None:
    try:
        raw = run_command(
            SSH
            + [
                "docker",
                "stats",
                "--no-stream",
                "--format",
                "{{.CPUPerc}} {{.MemUsage}}",
                name,
            ],
            timeout=20,
        ).strip()
    except Exception:
        return None
    return {"utc": utc_now(), "sample": raw}


def _stage_hashes(directory: Path) -> dict[str, str]:
    return build_cases.tree_hashes(directory)


def _capture_source_snapshot(case_name: str) -> dict[str, Any]:
    destination = RUN / f"source-snapshot-before-{case_name}"
    destination.mkdir(parents=True, exist_ok=False)
    sources = {
        "build_cases.py": SOURCE_ROOT / "cases/e1_rouaix_fast_diagnostics/build_cases.py",
        "mesh_audit.py": SOURCE_ROOT / "cases/e1_rouaix_matched_mesh/mesh_audit.py",
        "rouaix_mesh_helper.py": SOURCE_ROOT / "scripts/run_rouaix_case4_pilot.py",
        "experiment.md": SOURCE_ROOT / "experiments/E1_ROUAIX_BACKFLOW_LOCAL_20261028.md",
        "test_rouaix_fast_diagnostics.py": SOURCE_ROOT / "tests/test_rouaix_fast_diagnostics.py",
        "run_remote.py": Path(__file__).resolve(),
        "container/container-start.sh": CONTAINER_DIR / "container-start.sh",
        "container/remote-control.sh": REMOTE_CONTROL,
        "container/solver-supervisor.sh": CONTAINER_DIR / "solver-supervisor.sh",
        "templates/hpc-fvSchemes": SOURCE_ROOT / "cases/e1_rouaix_hpc/template/system/fvSchemes",
        "templates/hpc-fvSolution": SOURCE_ROOT / "cases/e1_rouaix_hpc/template/system/fvSolution",
        "templates/mesh-controlDict": SOURCE_ROOT
        / "cases/e1_rouaix_matched_mesh/case/system/controlDict",
        "templates/source-topoSetDict": SOURCE_ROOT
        / "cases/e1_rouaix_case1_static/case/system/topoSetDict",
        "templates/source-createPatchDict": SOURCE_ROOT
        / "cases/e1_rouaix_case1_static/case/system/createPatchDict",
    }
    file_hashes = {}
    for relative, source in sources.items():
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        file_hashes[relative] = sha256(target)
    revision = run_command(["git", "rev-parse", "HEAD"]).strip()
    status = run_command(["git", "status", "--porcelain"])
    (destination / "git-revision.txt").write_text(revision + "\n", encoding="utf-8")
    (destination / "git-status-porcelain.txt").write_text(status, encoding="utf-8")
    snapshot = {
        "schema_version": 1,
        "captured_utc": utc_now(),
        "git_revision": revision,
        "git_dirty": bool(status.strip()),
        "source_files_sha256": file_hashes,
        "active_case_input_tree_sha256": build_cases.tree_hashes(RUN / case_name),
        "mesh_input_sha256": sha256(RUN / "mesh-input/mesh-input.json")
        if (RUN / "mesh-input/mesh-input.json").is_file()
        else None,
        "mesh_qa_sha256": sha256(RUN / "mesh-qa.json")
        if (RUN / "mesh-qa.json").is_file()
        else None,
    }
    (destination / "manifest.json").write_text(
        json.dumps(snapshot, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    snapshot["manifest_sha256"] = sha256(destination / "manifest.json")
    return snapshot


def _refresh_case_provenance(case_name: str) -> None:
    case_dir = RUN / case_name
    metadata_path = case_dir / "case-inputs.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    metadata["source_sha256"]["case_generator"] = sha256(
        SOURCE_ROOT / "cases/e1_rouaix_fast_diagnostics/build_cases.py"
    )
    metadata["mesh_input_sha256"] = sha256(RUN / "mesh-input/mesh-input.json")
    metadata["mesh_qa_sha256"] = sha256(RUN / "mesh-qa.json")
    metadata["case_files_sha256"] = build_cases.tree_hashes(case_dir, exclude=("case-inputs.json",))
    metadata["case_files_total_bytes"] = sum(
        path.stat().st_size
        for path in case_dir.rglob("*")
        if path.is_file() and path.name != "case-inputs.json"
    )
    metadata_path.write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


def run_stage(stage: str, case_name: str | None = None, *, cpus: int = 4) -> dict[str, Any]:
    if stage == "solver":
        if case_name is None:
            raise ValueError("solver stage requires a case name")
        _refresh_case_provenance(case_name)
        source_snapshot = _capture_source_snapshot(case_name)
    else:
        source_snapshot = None
    local_upload, name, remote_input, remote_work, cpus = prepare_upload(stage, case_name, cpus)
    output_dir = CONTAINER_RUNS / (case_name or "mesh")
    output_dir.mkdir(parents=True, exist_ok=False)
    local_control_log = output_dir / "remote-control.log"
    released = False
    resource_samples: list[dict[str, Any]] = []
    try:
        free_output = int(
            run_command(
                SSH
                + [
                    "df",
                    "--output=avail",
                    "-B1",
                    "/home/v/proj/bene/fire-track2/results",
                ]
            )
            .splitlines()[-1]
            .strip()
        )
        if free_output < MIN_FREE_DISK_BYTES:
            raise RuntimeError(
                f"Goblin durable output filesystem has {free_output} bytes free; "
                f"required floor is {MIN_FREE_DISK_BYTES}"
            )
        upload(local_upload, remote_input)
        context = {
            "created_utc": utc_now(),
            "git_revision": source_snapshot["git_revision"]
            if source_snapshot
            else json.loads((RUN / "preparation-manifest.json").read_text())["git_revision"],
            "git_dirty": source_snapshot["git_dirty"]
            if source_snapshot
            else json.loads((RUN / "preparation-manifest.json").read_text())["git_dirty"],
            "image_digest": IMAGE_ID,
            "stage": stage,
            "case_name": case_name,
            "resource_cap": {
                "cpus": cpus,
                "memory_gib": 3,
                "workspace_tmpfs_gib": 2,
                "network": "none",
                "gpu": False,
                "field_handler": "collated",
                "durable_output_free_bytes_before_upload": free_output,
            },
            "input_files_sha256": _stage_hashes(local_upload),
        }
        (output_dir / "input-context.json").write_text(
            json.dumps(context, indent=2, sort_keys=True) + "\n"
        )
        if stage == "mesh":
            # Include the host-side context in the input before this no-solver container starts.
            shutil.copy2(output_dir / "input-context.json", local_upload / "input-context.json")
            upload(local_upload, remote_input)
        result = remote("prepare", name, remote_input, remote_work, cpus, stage)
        local_control_log.write_text(result, encoding="utf-8")
        lines = [line for line in result.splitlines() if line.strip()]
        if stage == "mesh":
            first = lines[0].split("\t")
            if len(first) != 3 or first[0] != "MESH_DONE":
                raise RuntimeError(f"unexpected mesh prepare output: {result[-2000:]}")
            container_id, started_at = first[1], first[2]
            ready_record: dict[str, Any] = {"native_mesh_stage": "completed-before-solver-creation"}
        else:
            first = lines[0].split("\t")
            if len(first) != 3 or first[0] != "PREPARED":
                raise RuntimeError(f"unexpected solver prepare output: {result[-2000:]}")
            container_id, started_at = first[1], first[2]
            ready_line = next((line for line in lines[1:] if line.startswith("{")), None)
            if ready_line is None:
                raise RuntimeError("solver container did not provide READY.json")
            ready_record = json.loads(ready_line)
            if (
                ready_record.get("ready") is not True
                or ready_record.get("hashes_verified") is not True
            ):
                raise RuntimeError(f"solver guard/input preflight failed: {ready_record}")
            guard_selftest = remote("guard-selftest", name, remote_input, remote_work, cpus, stage)
            if "GUARD_PARSER_SELFTEST_PASSED" not in guard_selftest:
                raise RuntimeError(f"solver guard parser self-test failed: {guard_selftest}")
            (output_dir / "guard-parser-selftest.txt").write_text(guard_selftest, encoding="utf-8")
            case_metadata = json.loads((RUN / case_name / "case-inputs.json").read_text())
            manifest = {
                "schema_version": 1,
                "case_id": case_metadata["case_id"],
                "run_id": case_name,
                "container_id": container_id,
                "container_name": name,
                "container_started_at": started_at,
                "image_digest": IMAGE_ID,
                "host": "Goblin / greengoblin",
                "resource_cap": context["resource_cap"],
                "field_handler": "collated",
                "input_case_sha256": sha256(RUN / case_name / "case-inputs.json"),
                "input_file_manifest_sha256": sha256(local_upload / "case-files.sha256"),
                "container_start_script_sha256": sha256(CONTAINER_DIR / "container-start.sh"),
                "solver_supervisor_sha256": sha256(CONTAINER_DIR / "solver-supervisor.sh"),
                "remote_control_script_sha256": sha256(REMOTE_CONTROL),
                "source_snapshot_sha256": source_snapshot["manifest_sha256"],
                "source_files_sha256": source_snapshot["source_files_sha256"],
                "git_revision": context["git_revision"],
                "git_dirty": context["git_dirty"],
                "pre_go_ready_check": ready_record,
                "launch_command": (
                    f"decomposePar -force; mpirun --bind-to none -np {cpus} interIsoFoam -parallel"
                ),
                "guard": {
                    "max_abs_U_m_s": case_metadata["runtime_guard"]["max_abs_U_m_s"],
                    "write_and_stop_signal": 12,
                    "hard_deadline_s": case_metadata["runtime_guard"]["hard_wall_seconds"],
                    "grace_s": case_metadata["runtime_guard"]["grace_seconds"],
                },
                "guard_parser_selftest": guard_selftest.strip(),
                "recorded_utc": utc_now(),
            }
            pre_go = output_dir / "pre-go-manifest.json"
            pre_go.write_text(
                json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
            )
            run_command(SSH + ["mkdir", "-p", remote_work])
            copy = subprocess.run(
                [
                    "rsync",
                    "-avP",
                    "-e",
                    RSYNC_SSH,
                    str(pre_go),
                    f"goblin:{remote_work}/pre-go-manifest.json",
                ],
                capture_output=True,
                text=True,
                check=False,
            )
            if copy.returncode != 0:
                raise RuntimeError(f"pre-GO manifest rsync failed: {copy.stderr}")
            pause_state, pause_detail = active_pause_state()
            (output_dir / "pre-go-pause-check.json").write_text(
                json.dumps(
                    {"state": pause_state, "detail": pause_detail, "utc": utc_now()}, indent=2
                )
                + "\n",
                encoding="utf-8",
            )
            if pause_state != "clear":
                raise RuntimeError(f"PAUSE gate before GO was {pause_state}: {pause_detail}")
            go_out = remote("go", name, remote_input, remote_work, cpus, stage)
            if "GO_RELEASED" not in go_out:
                raise RuntimeError(f"container did not acknowledge GO: {go_out}")
            (output_dir / "go-released.json").write_text(
                json.dumps(
                    {"go_released_utc": utc_now(), "pre_go_manifest_sha256": sha256(pre_go)},
                    indent=2,
                )
                + "\n"
            )

            started = time.monotonic()
            last_sample = started
            last_pause_check = started - 30
            pause_stop_requested = False
            pause_observed = False
            pause_stop_detail = None
            while True:
                if time.monotonic() - last_pause_check >= 30:
                    pause_state, pause_detail = active_pause_state()
                    pause_record = {
                        "utc": utc_now(),
                        "state": pause_state,
                        "detail": pause_detail,
                    }
                    with (output_dir / "pause-monitor.jsonl").open("a", encoding="utf-8") as stream:
                        stream.write(json.dumps(pause_record, sort_keys=True) + "\n")
                    if pause_state != "clear" and not pause_stop_requested:
                        pause_observed = True
                        try:
                            stop_reply = remote(
                                "pause-request", name, remote_input, remote_work, cpus, stage
                            )
                            if "WRITE_STOP_REQUESTED" in stop_reply:
                                pause_stop_requested = True
                                pause_stop_detail = pause_detail
                            else:
                                pause_stop_detail = (
                                    f"pause stop was not acknowledged: {stop_reply[-300:]}"
                                )
                        except Exception as error:
                            pause_stop_detail = (
                                f"pause stop request failed: {type(error).__name__}: {error}"
                            )
                        (output_dir / "pause-stop-request.json").write_text(
                            json.dumps(
                                {
                                    "utc": utc_now(),
                                    "requested": pause_stop_requested,
                                    "pause_state": pause_state,
                                    "detail": pause_stop_detail,
                                },
                                indent=2,
                            )
                            + "\n",
                            encoding="utf-8",
                        )
                    last_pause_check = time.monotonic()
                state = remote("status", name, remote_input, remote_work, cpus, stage).strip()
                if state.startswith("CONTAINER_GONE"):
                    raise RuntimeError(
                        "container disappeared before the output archive was streamed"
                    )
                if state.startswith("DONE\t"):
                    terminal_line = state.split("\t", 1)[1]
                    terminal = json.loads(terminal_line)
                    (output_dir / "terminal-status.json").write_text(
                        json.dumps(terminal, indent=2) + "\n"
                    )
                    print(f"TERMINAL case={case_name} status={terminal}", flush=True)
                    break
                if time.monotonic() - last_sample >= 30:
                    sample = _resource_sample(name)
                    if sample:
                        resource_samples.append(sample)
                        with (output_dir / "resource-samples.jsonl").open(
                            "a", encoding="utf-8"
                        ) as stream:
                            stream.write(json.dumps(sample, sort_keys=True) + "\n")
                    print(f"LIVE case={case_name} status={state}", flush=True)
                    last_sample = time.monotonic()
                time.sleep(10)

        export_result = remote("export", name, remote_input, remote_work, cpus, stage)
        local_control_log.write_text(
            local_control_log.read_text(encoding="utf-8") + "\n" + export_result, encoding="utf-8"
        )
        export_line = next(
            (line for line in export_result.splitlines() if line.startswith("ARCHIVE_READY\t")),
            None,
        )
        if export_line is None:
            raise RuntimeError(f"no remote archive readiness record: {export_result}")
        _, remote_sha, remote_bytes = export_line.split("\t")
        if int(remote_bytes) > MAX_REMOTE_ARCHIVE_BYTES:
            raise RuntimeError(
                f"remote archive is {remote_bytes} bytes; per-case cap is "
                f"{MAX_REMOTE_ARCHIVE_BYTES}"
            )
        archive = output_dir / "result.tar.gz"
        sidecar = output_dir / "result.tar.gz.sha256"
        fetch(f"{remote_work}/result.tar.gz", archive)
        fetch(f"{remote_work}/result.tar.gz.sha256", sidecar)
        local_sha = sha256(archive)
        sidecar_sha = sidecar.read_text(encoding="utf-8").split()[0]
        if (
            local_sha != remote_sha
            or local_sha != sidecar_sha
            or archive.stat().st_size != int(remote_bytes)
        ):
            raise RuntimeError("local result archive failed remote SHA/size verification")
        member_names = _safe_extract(archive, output_dir / "evidence")
        snapshot_inventory = (
            _snapshot_inventory(output_dir, case_name) if stage == "solver" else None
        )
        (output_dir / "archive-verification.json").write_text(
            json.dumps(
                {
                    "sha256": local_sha,
                    "bytes": archive.stat().st_size,
                    "regular_members": len(member_names),
                    "members": member_names,
                    "remote_local_sha_match": True,
                },
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        release_output = remote("release", name, remote_input, remote_work, cpus, stage)
        if "CONTAINER_RELEASED" not in release_output:
            raise RuntimeError(f"container did not confirm streamed cleanup: {release_output}")
        released = True
        try:
            run_command(SSH + ["rm", "-rf", "--", remote_input, remote_work], timeout=60)
        except Exception as error:
            (output_dir / "remote-cleanup-warning.txt").write_text(
                f"verified archive retained locally; remote owned paths remain: {type(error).__name__}: {error}\n",
                encoding="utf-8",
            )
        result = {
            "run_id": case_name or "mesh",
            "stage": stage,
            "container_name": name,
            "container_id": container_id,
            "container_started_at": started_at,
            "archive_sha256": local_sha,
            "archive_bytes": archive.stat().st_size,
            "archive_members": len(member_names),
            "resource_samples": resource_samples,
            "field_handler": "collated",
            "snapshot_inventory": snapshot_inventory,
            "pause_stop_requested": pause_stop_requested if stage == "solver" else False,
            "pause_observed": pause_observed if stage == "solver" else False,
            "pause_stop_detail": pause_stop_detail if stage == "solver" else None,
            "guard": json.loads((output_dir / "evidence/guard.json").read_text())
            if stage == "solver" and (output_dir / "evidence/guard.json").is_file()
            else None,
            "terminal": json.loads((output_dir / "terminal-status.json").read_text())
            if stage == "solver"
            else json.loads((output_dir / "evidence/mesh-qa.json").read_text()),
            "released": released,
            "completed_utc": utc_now(),
        }
        (output_dir / "run-result.json").write_text(
            json.dumps(result, indent=2, sort_keys=True) + "\n"
        )
        return result
    except Exception as error:
        (output_dir / "runner-error.txt").write_text(
            f"{type(error).__name__}: {error}\n", encoding="utf-8"
        )
        raise
    finally:
        if not released:
            try:
                remote("abort", name, remote_input, remote_work, cpus, stage)
            except Exception as error:
                (output_dir / "cleanup-error.txt").write_text(str(error) + "\n", encoding="utf-8")
            try:
                fetch_tree(remote_work, output_dir / "remote-recovery")
            except Exception as error:
                (output_dir / "recovery-error.txt").write_text(str(error) + "\n", encoding="utf-8")
        try:
            remote("cleanup", name, remote_input, remote_work, cpus, stage)
        except Exception:
            try:
                run_command(SSH + ["rm", "-rf", "--", remote_input], timeout=60)
            except Exception:
                pass


def _write_mesh_qa() -> dict[str, Any]:
    mesh_dir = CONTAINER_RUNS / "mesh" / "evidence/polyMesh"
    evidence = CONTAINER_RUNS / "mesh" / "evidence"
    check_log = (evidence / "logs/checkMesh.log").read_text(encoding="utf-8", errors="replace")
    summary = mesh_audit.check_mesh_summary(check_log)
    patch_ranges = mesh_audit.boundary_ranges(mesh_dir / "boundary")
    expected = set(build_cases.PATCHES)
    patch_names_ok = set(patch_ranges) == expected
    nozzle = mesh_audit.binary_patch_area_normal(mesh_dir, "nozzle")
    area_target = 3.141592653589793 * 0.2**2
    relative_error = nozzle["area_m2"] / area_target - 1.0
    snappy_log = (evidence / "logs/snappyHexMesh.log").read_text(encoding="utf-8", errors="replace")
    refinement = mesh_audit.refinement_counts(snappy_log)
    passed = (
        summary["mesh_ok_banner"]
        and summary["failed_checkmesh_categories"] in (None, 0)
        and summary["low_quality_tet_faces"] == 0
        and summary["cells"] is not None
        and summary["cells"] <= build_cases.MAX_CELLS
        and patch_names_ok
        and abs(relative_error) <= 0.02
        and abs(nozzle["normal"][1] - 1.0) <= 1e-8
        and abs(nozzle["normal"][0]) <= 1e-8
        and abs(nozzle["normal"][2]) <= 1e-8
    )
    qa = {
        "schema_version": 1,
        "status": "passed" if passed else "failed",
        "native_checkMesh": summary,
        "patch_inventory": {
            "expected": sorted(expected),
            "actual": sorted(patch_ranges),
            "passed": patch_names_ok,
        },
        "nozzle": {
            "analytic_area_m2": area_target,
            "relative_area_error": relative_error,
            **nozzle,
        },
        "nozzle_owner_spacing": {
            "status": "not-computed",
            "reason": "native mesh was written in binary format; nozzle area/normal are the predeclared QA metrics",
        },
        "snappy_refinement_counts": refinement,
        "area_tolerance_fraction": 0.02,
        "interpretation": "coarse exploratory mesh only; native QA is a run prerequisite, not E1 grid qualification",
        "mesh_archive_sha256": sha256(CONTAINER_RUNS / "mesh/result.tar.gz"),
    }
    (RUN / "mesh-qa.json").write_text(
        json.dumps(qa, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    if not passed:
        raise RuntimeError(f"native/coarse mesh QA failed; see {RUN / 'mesh-qa.json'}")
    return qa


def _attach_mesh(qa: dict[str, Any]) -> None:
    source_mesh = CONTAINER_RUNS / "mesh/evidence/polyMesh"
    qa_sha = sha256(RUN / "mesh-qa.json")
    for case_name in ("air-a-pilot", "air-original", "air-upwind"):
        case_dir = RUN / case_name
        build_cases.attach_mesh(case_dir, source_mesh)
        metadata_path = case_dir / "case-inputs.json"
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        metadata["mesh_qa_sha256"] = qa_sha
        metadata["case_files_sha256"] = build_cases.tree_hashes(
            case_dir, exclude=("case-inputs.json",)
        )
        metadata["case_files_total_bytes"] = sum(
            p.stat().st_size
            for p in case_dir.rglob("*")
            if p.is_file() and p.name != "case-inputs.json"
        )
        metadata_path.write_text(
            json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("mesh", "solver"))
    parser.add_argument("--case")
    parser.add_argument("--cpus", type=int, choices=(4, 8), default=4)
    args = parser.parse_args()
    if args.stage == "mesh":
        result = run_stage("mesh")
        qa = _write_mesh_qa()
        _attach_mesh(qa)
        print(json.dumps({"mesh_result": result, "mesh_qa": qa}, indent=2), flush=True)
        return 0
    if args.case is None:
        parser.error("--case is required for solver stage")
    result = run_stage("solver", args.case, cpus=args.cpus)
    print(json.dumps(result, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
