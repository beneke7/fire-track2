#!/usr/bin/env python3
"""Bounded persistent launch for the matched static-pressure water control."""

from __future__ import annotations

import fcntl
import json
import math
import os
import re
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
PYTHON = ROOT / ".venv/bin/python"
RUN_LOCAL = ROOT / "scripts/run_local.py"
RUNNER = RUN / "run_remote.py"
STATE = RUN / "water-static-control-dispatcher-state.json"
EVENTS = RUN / "water-static-control-dispatcher-events.jsonl"
LOCK = RUN / "water-static-control-dispatcher.lock"
LOG = RUN / "air-backflow-water-static-030.runner.log"
LOCAL_PAUSE = ROOT / "PAUSE"
TOTAL_NAME = "air-backflow-water-030"
STATIC_NAME = "air-backflow-water-static-030"
TOTAL_OUTPUT = RUN / "container-runs" / TOTAL_NAME
STATIC_OUTPUT = RUN / "container-runs" / STATIC_NAME
TOTAL_CASE = RUN / TOTAL_NAME
STATIC_CASE = RUN / STATIC_NAME
MAX_WAIT_S = 1800
POLL_S = 10
PATCHES = ("downstreamOutlet", "bottomOutlet", "spanwiseMinus", "spanwisePlus")

SSH_LIVE = r"""set -euo pipefail
name=rouaix-backflow-air-backflow-water-030-20261028-q20261028
if [[ -e /home/v/proj/bene/fire-track2/PAUSE ]]; then echo PAUSED_GOBLIN; exit 0; fi
if ! docker inspect "$name" >/dev/null 2>&1; then echo CONTAINER_GONE; exit 0; fi
docker exec "$name" cat /workspace/status.json
"""
SSH_CAPACITY = r"""set -euo pipefail
if [[ -e /home/v/proj/bene/fire-track2/PAUSE ]]; then echo PAUSED_GOBLIN; exit 0; fi
read_cpu() { awk '$1=="cpu" { total=0; for(i=2;i<=9;i++) total+=$i; idle=$5+$6; printf "%.0f %.0f\n",total,total-idle }' /proc/stat; }
read -r total0 busy0 < <(read_cpu)
sleep 5
read -r total1 busy1 < <(read_cpu)
cpus=$(nproc); dt=$((total1-total0)); db=$((busy1-busy0))
awk -v dt="$dt" -v db="$db" -v n="$cpus" 'BEGIN { if(dt<=0 || db<0) exit 2; printf "BUSY=%.3f NPROC=%d AVAILABLE=%.3f\n", db/dt*n, n, n-db/dt*n }'
"""


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def sha(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def event(kind: str, **fields: Any) -> None:
    record = {"utc": utc_now(), "event": kind, **fields}
    with EVENTS.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, sort_keys=True) + "\n")
    print(json.dumps(record, sort_keys=True), flush=True)


def state(value: str, **fields: Any) -> None:
    record = {"schema_version": 1, "state": value, "updated_utc": utc_now(), **fields}
    tmp = STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    os.replace(tmp, STATE)


def ssh_script(script: str, timeout: int = 25) -> tuple[int, str, str]:
    result = subprocess.run(
        ["ssh", "-oBatchMode=yes", "-oConnectTimeout=8", "goblin", "bash", "-s"],
        input=script,
        text=True,
        capture_output=True,
        timeout=timeout,
        check=False,
    )
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def extract_block(text: str, patch: str) -> str:
    blocks = re.findall(rf"(?ms)^    {re.escape(patch)}\s*\{{.*?^    \}}", text)
    if len(blocks) != 1:
        raise ValueError(f"expected one p_rgh block for {patch}, found {len(blocks)}")
    return blocks[0]


def replace_block(text: str, patch: str, replacement: str) -> str:
    pattern = re.compile(rf"(?ms)^    {re.escape(patch)}\s*\{{.*?^    \}}")
    result, count = pattern.subn(lambda _: replacement, text)
    if count != 1:
        raise ValueError(f"expected one p_rgh replacement for {patch}, found {count}")
    return result


def validate_prepared_pair() -> tuple[bool, dict[str, Any]]:
    checks: dict[str, Any] = {}
    try:
        receipt = json.loads((RUN / "water-static-control-prepared-only.json").read_text())
        static_meta = json.loads((STATIC_CASE / "case-inputs.json").read_text())
        total_meta = json.loads((TOTAL_CASE / "case-inputs.json").read_text())
        checks["static_preparation_receipt"] = (
            receipt.get("status") == "prepared_only_not_launched"
            and receipt.get("no_solver_started") is True
            and receipt.get("case_inputs_sha256") == sha(STATIC_CASE / "case-inputs.json")
        )
        static_files = {
            p.relative_to(STATIC_CASE).as_posix(): sha(p)
            for p in STATIC_CASE.rglob("*")
            if p.is_file()
        }
        total_files = {
            p.relative_to(TOTAL_CASE).as_posix(): sha(p)
            for p in TOTAL_CASE.rglob("*")
            if p.is_file()
        }
        checks["case_file_set"] = set(static_files) == set(total_files)
        checks["only_pressure_and_metadata_changed"] = checks["case_file_set"] and all(
            static_files[name] == total_files[name]
            for name in static_files
            if name not in {"0/p_rgh", "case-inputs.json"}
        )
        static_text = (STATIC_CASE / "0/p_rgh").read_text(encoding="utf-8")
        total_text = (TOTAL_CASE / "0/p_rgh").read_text(encoding="utf-8")
        normalized_static = static_text
        normalized_total = total_text
        for patch in PATCHES:
            static_block = extract_block(static_text, patch)
            total_block = extract_block(total_text, patch)
            checks[f"{patch}_static_type"] = "type            prghPressure;" in static_block
            checks[f"{patch}_total_type"] = "type            prghTotalPressure;" in total_block
            normalized = f"    {patch}\n    {{\n        BLOCK\n    }}"
            normalized_static = replace_block(normalized_static, patch, normalized)
            normalized_total = replace_block(normalized_total, patch, normalized)
        checks["pressure_file_other_content_identical"] = normalized_static == normalized_total
        physical_keys = (
            "delta_t_s",
            "expected_steps",
            "field_write_times_s",
            "initial_condition",
            "momentum_convection",
            "mpi_ranks",
            "nozzle_velocity_m_s",
            "gas_inlet_velocity_m_s",
            "source_mode",
        )
        checks["matched_physical_metadata"] = all(
            static_meta.get(key) == total_meta.get(key) for key in physical_keys
        )
        checks["same_stop_and_horizon"] = (
            static_meta.get("expected_steps") == total_meta.get("expected_steps") == 3000
            and static_meta.get("delta_t_s") == total_meta.get("delta_t_s") == 0.0001
            and static_meta.get("mpi_ranks") == total_meta.get("mpi_ranks") == 8
            and static_meta.get("runtime_guard", {}).get("max_abs_U_m_s") == 200.0
            and total_meta.get("runtime_guard", {}).get("max_abs_U_m_s") == 200.0
        )
        checks["same_frozen_mesh"] = static_meta.get("mesh_files_sha256") == total_meta.get(
            "mesh_files_sha256"
        )
        source_manifest_path = RUN / f"source-snapshot-before-{TOTAL_NAME}" / "manifest.json"
        pre_go_path = TOTAL_OUTPUT / "pre-go-manifest.json"
        upload_manifest = RUN / "uploads" / TOTAL_NAME / "case-files.sha256"
        pre_go = json.loads(pre_go_path.read_text())
        source = json.loads(source_manifest_path.read_text())
        go = json.loads((TOTAL_OUTPUT / "go-released.json").read_text())
        checks["total_pressure_source_snapshot"] = (
            pre_go.get("source_snapshot_sha256") == sha(source_manifest_path)
            and pre_go.get("source_files_sha256") == source.get("source_files_sha256")
            and pre_go.get("git_revision") == source.get("git_revision")
            and pre_go.get("git_dirty") == source.get("git_dirty")
        )
        checks["total_pressure_frozen_inputs"] = (
            pre_go.get("input_case_sha256") == sha(TOTAL_CASE / "case-inputs.json")
            and pre_go.get("input_file_manifest_sha256") == sha(upload_manifest)
            and pre_go.get("pre_go_ready_check", {}).get("hashes_verified") is True
            and go.get("pre_go_manifest_sha256") == sha(pre_go_path)
        )
        air_result = json.loads(
            (RUN / "container-runs/air-backflow-030/run-result.json").read_text()
        )
        air_archive = json.loads(
            (RUN / "container-runs/air-backflow-030/archive-verification.json").read_text()
        )
        checks["all_air_control_terminal"] = (
            air_result.get("released") is True
            and air_archive.get("remote_local_sha_match") is True
            and air_result.get("terminal", {}).get("end_marker") is True
            and air_result.get("terminal", {}).get("solver_exit_code") == 0
            and air_result.get("terminal", {}).get("guard_reason") == "horizon_end"
        )
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        checks["error"] = f"{type(error).__name__}: {error}"
        return False, checks
    return bool(checks) and all(v is True for k, v in checks.items() if k != "error"), checks


def total_water_status() -> tuple[bool, dict[str, Any]]:
    code, output, error = ssh_script(SSH_LIVE)
    if code != 0:
        return False, {"error": error or output, "ssh_exit_code": code}
    if output.startswith("PAUSED_GOBLIN"):
        return False, {"state": "paused", "detail": output}
    if output.startswith("CONTAINER_GONE"):
        result_path = TOTAL_OUTPUT / "run-result.json"
        if not result_path.is_file():
            return False, {"state": "total_pressure_container_gone_without_result"}
        result = json.loads(result_path.read_text())
        terminal = result.get("terminal", {})
        archive_path = TOTAL_OUTPUT / "archive-verification.json"
        archive = json.loads(archive_path.read_text()) if archive_path.is_file() else {}
        okay = (
            result.get("released") is True
            and archive.get("remote_local_sha_match") is True
            and result.get("snapshot_inventory", {}).get("passed") is True
            and terminal.get("end_marker") is True
            and terminal.get("solver_exit_code") == 0
        )
        return okay, {"state": "total_pressure_terminal", "terminal": terminal, "archive": archive}
    try:
        status = json.loads(output)
        t = float(status["solver_time_s"])
        speed = float(status["max_U_m_s"])
        okay = (
            status.get("state") in {"running", "terminal"}
            and math.isfinite(t)
            and math.isfinite(speed)
        )
        return okay, status
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        return False, {"error": f"{type(error).__name__}: {error}", "raw": output[:500]}


def capacity() -> tuple[bool, str]:
    code, output, error = ssh_script(SSH_CAPACITY, timeout=12)
    if code != 0:
        return False, error or output
    if output.startswith("PAUSED_GOBLIN"):
        return False, output
    match = re.search(r"AVAILABLE=([0-9.]+)", output)
    return bool(match and float(match.group(1)) >= 8.0), output


def launch() -> int:
    command = [
        str(PYTHON),
        str(RUN_LOCAL),
        "--threads",
        "1",
        "--timeout",
        "2400",
        "--",
        str(PYTHON),
        str(RUNNER),
        "solver",
        "--case",
        STATIC_NAME,
        "--cpus",
        "8",
    ]
    started = time.monotonic()
    with LOG.open("x", encoding="utf-8") as stream:
        result = subprocess.run(
            command,
            cwd=ROOT,
            stdout=stream,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
            timeout=2400,
        )
    elapsed = time.monotonic() - started
    event("runner_exit", returncode=result.returncode, elapsed_s=elapsed, command=command)
    result_path = STATIC_OUTPUT / "run-result.json"
    archive_path = STATIC_OUTPUT / "archive-verification.json"
    if result_path.is_file():
        run_result = json.loads(result_path.read_text())
        archive = json.loads(archive_path.read_text()) if archive_path.is_file() else {}
        terminal = run_result.get("terminal", {})
        passed = (
            result.returncode == 0
            and run_result.get("released") is True
            and archive.get("remote_local_sha_match") is True
            and run_result.get("snapshot_inventory", {}).get("passed") is True
            and terminal.get("end_marker") is True
            and terminal.get("solver_exit_code") == 0
        )
        state(
            "terminal_capture_verified" if passed else "terminal_capture_review_needed",
            run_result=run_result,
            archive_verification=archive,
        )
        return 0 if passed else 1
    state("runner_failed_without_result", returncode=result.returncode, log=str(LOG))
    return result.returncode or 1


def healthy_status(status: dict[str, Any]) -> bool:
    try:
        return (
            status.get("state") in {"running", "terminal"}
            and math.isfinite(float(status["solver_time_s"]))
            and math.isfinite(float(status["max_U_m_s"]))
        )
    except (KeyError, TypeError, ValueError):
        return False


def selftest() -> int:
    safe = {"state": "running", "solver_time_s": "0.1", "max_U_m_s": "100.0"}
    bad = {"state": "running", "solver_time_s": "nan", "max_U_m_s": "100.0"}
    terminal = {"state": "terminal", "solver_time_s": "0.3", "max_U_m_s": "199.0"}
    if not healthy_status(safe) or healthy_status(bad) or not healthy_status(terminal):
        raise AssertionError("static-control live-status classification self-test failed")
    print("WATER_STATIC_CONTROL_DISPATCH_SELFTEST_PASSED")
    return 0


def main() -> int:
    if "--selftest" in sys.argv:
        return selftest()
    LOCK.parent.mkdir(parents=True, exist_ok=True)
    with LOCK.open("a", encoding="utf-8") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("another static-control dispatcher already owns the lock", file=sys.stderr)
            return 3
        if STATE.is_file() and json.loads(STATE.read_text()).get("state") in {
            "case_running",
            "terminal_capture_verified",
        }:
            print("refusing duplicate static-control launch", file=sys.stderr)
            return 4
        if LOG.exists() or STATIC_OUTPUT.exists():
            print(
                "static-control attempt already has durable outputs; refusing relaunch",
                file=sys.stderr,
            )
            return 5
        okay, checks = validate_prepared_pair()
        if not okay:
            event("preflight_failed", checks=checks)
            state("preflight_failed", checks=checks)
            return 6
        event("matched_pair_verified", checks=checks)
        start = time.monotonic()
        while time.monotonic() - start < MAX_WAIT_S:
            if LOCAL_PAUSE.exists():
                reason = f"local PAUSE sentinel {LOCAL_PAUSE}"
                state("paused_waiting_for_clear", reason=reason, checks=checks)
                event("pause_wait", reason=reason)
                time.sleep(POLL_S)
                continue
            water_ready, water_status = total_water_status()
            if not water_ready:
                state("waiting_for_total_pressure_water_status", total_status=water_status)
                event("total_pressure_water_status_wait", total_status=water_status)
                time.sleep(POLL_S)
                continue
            enough, sample = capacity()
            if not enough:
                state(
                    "waiting_for_eight_cpu_equivalents",
                    total_pressure_status=water_status,
                    capacity_sample=sample,
                )
                event("capacity_wait", total_pressure_status=water_status, sample=sample)
                time.sleep(POLL_S)
                continue
            if LOCAL_PAUSE.exists():
                continue
            state("case_running", total_pressure_status=water_status, capacity_sample=sample)
            event(
                "static_control_start", total_pressure_status=water_status, capacity_sample=sample
            )
            return launch()
        state("bounded_wait_timeout", checks=checks, max_wait_s=MAX_WAIT_S)
        event("bounded_wait_timeout", max_wait_s=MAX_WAIT_S)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
