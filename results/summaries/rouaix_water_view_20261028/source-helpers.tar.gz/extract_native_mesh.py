#!/usr/bin/env python3
"""Extract ordered native-cell centres and volumes with ParaView's reader."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from paraview import servermanager
from paraview.simple import CellCenters, CellSize, OpenFOAMReader
from vtk.util.numpy_support import vtk_to_numpy

REPO = Path(__file__).resolve().parents[3]
CASE = REPO / "results/runs/rouaix-backflow-local-20261028/air-backflow-water-030"
OUT = Path(__file__).resolve().parent / "staging"


def blocks(data):
    if data.IsA("vtkCompositeDataSet"):
        iterator = data.NewIterator()
        iterator.SkipEmptyNodesOn()
        iterator.InitTraversal()
        while not iterator.IsDoneWithTraversal():
            item = iterator.GetCurrentDataObject()
            if item is not None:
                yield from blocks(item)
            iterator.GoToNextItem()
    else:
        yield data


def main() -> None:
    reader = OpenFOAMReader(
        registrationName="Rouaix coarse native mesh", FileName=str(CASE / "case.foam")
    )
    reader.CaseType = "Reconstructed Case"
    reader.SkipZeroTime = 0
    reader.MeshRegions = ["internalMesh"]
    reader.CellArrays = ["alpha.water"]
    reader.UpdatePipeline(time=0.0)

    centers_filter = CellCenters(registrationName="Native cell centers", Input=reader)
    centers_filter.VertexCells = 0
    centers_filter.UpdatePipeline(time=0.0)
    centers_data = servermanager.Fetch(centers_filter)
    center_parts = [
        vtk_to_numpy(part.GetPoints().GetData())
        for part in blocks(centers_data)
        if part.GetNumberOfPoints()
    ]
    centers = np.concatenate(center_parts, axis=0)

    size_filter = CellSize(registrationName="Native cell volumes", Input=reader)
    size_filter.ComputeArea = 0
    size_filter.ComputeLength = 0
    size_filter.ComputeVertexCount = 0
    size_filter.ComputeVolume = 1
    size_filter.UpdatePipeline(time=0.0)
    volume_data = servermanager.Fetch(size_filter)
    volume_parts = [
        vtk_to_numpy(part.GetCellData().GetArray("Volume"))
        for part in blocks(volume_data)
        if part.GetNumberOfCells()
    ]
    volumes = np.concatenate(volume_parts, axis=0)

    if centers.shape != (299520, 3) or volumes.shape != (299520,):
        raise RuntimeError(
            f"expected 299520 native cells, got centres={centers.shape}, volumes={volumes.shape}"
        )
    if not np.all(np.isfinite(centers)) or not np.all(np.isfinite(volumes)):
        raise RuntimeError("native mesh contains nonfinite centre or volume values")
    if np.any(volumes <= 0.0):
        raise RuntimeError(f"native mesh has nonpositive cell volumes: {volumes.min()}")

    OUT.mkdir(parents=True, exist_ok=True)
    archive = OUT / "native-cell-centres-volumes.npz"
    if archive.exists():
        with np.load(archive) as existing:
            if not np.array_equal(existing["centers_m"], centers) or not np.array_equal(
                existing["volumes_m3"], volumes
            ):
                raise RuntimeError("existing extracted mesh arrays differ from the reader output")
    else:
        np.savez_compressed(archive, centers_m=centers, volumes_m3=volumes)
    info = reader.GetDataInformation()
    result = {
        "case": str(CASE),
        "case_type": "Reconstructed Case",
        "time_s": 0.0,
        "cells": len(volumes),
        "bounds_m": list(info.GetBounds()),
        "cell_volume_sum_m3": float(volumes.sum()),
        "cell_volume_min_m3": float(volumes.min()),
        "cell_volume_max_m3": float(volumes.max()),
        "centre_order": "native reconstructed OpenFOAM internalMesh cell order",
        "npz": archive.name,
        "npz_bytes": archive.stat().st_size,
    }
    (OUT / "native-mesh-readback.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
