#!/usr/bin/env pvpython
"""Build opaque CPU-only alpha.water>=0.01 surfaces and a ParaView state."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.collections import PolyCollection
from paraview import servermanager
from paraview.simple import SaveState, Threshold, XMLUnstructuredGridReader
from vtk import (
    VTK_DOUBLE,
    vtkAppendFilter,
    vtkCellCenters,
    vtkCellSizeFilter,
    vtkDataObject,
    vtkGeometryFilter,
    vtkPolyData,
    vtkThreshold,
    vtkUnstructuredGrid,
    vtkXMLPolyDataWriter,
    vtkXMLUnstructuredGridWriter,
)
from vtk.util.numpy_support import numpy_to_vtk, vtk_to_numpy

REPO = Path(__file__).resolve().parents[3]
RUN = Path(__file__).resolve().parent
STAGING = RUN / "staging"
SUMMARY = REPO / "results/summaries/rouaix_water_view_20261028"
SOURCE_CASE = REPO / "results/runs/rouaix-backflow-local-20261028/air-backflow-water-030"
PV_VERSION = "ParaView 6.1.1; VTK 9.6.2; CPU only; Matplotlib Agg"
EYE_VECTOR = np.array([0.0, 0.0, 1.0], dtype=np.float64)
PLOT_BOUNDS = ((-0.5, 15.5), (-6.2, 0.65))


def blocks(data):
    if data.IsA("vtkCompositeDataSet"):
        iterator = data.NewIterator()
        iterator.SkipEmptyNodesOn()
        iterator.InitTraversal()
        while not iterator.IsDoneWithTraversal():
            item = iterator.GetCurrentDataObject()
            if item is not None:
                yield from blocks(item)
            iterator.GoToNextItem()
    else:
        yield data


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def as_unstructured_grid(data) -> vtkUnstructuredGrid:
    data_parts = [part for part in blocks(data) if part.GetNumberOfCells()]
    if len(data_parts) == 1 and data_parts[0].IsA("vtkUnstructuredGrid"):
        return vtkUnstructuredGrid.SafeDownCast(data_parts[0])
    append = vtkAppendFilter()
    append.MergePointsOff()
    for part in data_parts:
        append.AddInputData(part)
    append.Update()
    return append.GetOutput()


def verify_native_cell_order(grid, expected_centers, expected_volumes) -> dict:
    centers_filter = vtkCellCenters()
    centers_filter.SetInputData(grid)
    centers_filter.Update()
    centers = vtk_to_numpy(centers_filter.GetOutput().GetPoints().GetData())

    size_filter = vtkCellSizeFilter()
    size_filter.SetInputData(grid)
    size_filter.ComputeVertexCountOff()
    size_filter.ComputeLengthOff()
    size_filter.ComputeAreaOff()
    size_filter.ComputeVolumeOn()
    size_filter.Update()
    volumes = vtk_to_numpy(size_filter.GetOutput().GetCellData().GetArray("Volume"))
    if centers.shape != expected_centers.shape or volumes.shape != expected_volumes.shape:
        raise RuntimeError("flattened native grid changed the cell inventory")
    center_error = float(np.max(np.abs(centers - expected_centers)))
    volume_error = float(np.max(np.abs(volumes - expected_volumes)))
    if center_error > 1e-10 or volume_error > 1e-10:
        raise RuntimeError(
            "ParaView unstructured-grid order does not match the validated native arrays "
            f"(center error {center_error}, volume error {volume_error})"
        )
    return {
        "cells": len(volumes),
        "max_abs_center_difference_m": center_error,
        "max_abs_volume_difference_m3": volume_error,
        "volume_sum_m3": float(volumes.sum()),
    }


def make_threshold_surface(grid, field_name: str, destination: Path) -> tuple[vtkPolyData, dict]:
    threshold = vtkThreshold()
    threshold.SetInputData(grid)
    threshold.SetInputArrayToProcess(
        0,
        0,
        0,
        vtkDataObject.FIELD_ASSOCIATION_CELLS,
        field_name,
    )
    threshold.SetLowerThreshold(0.01)
    threshold.SetUpperThreshold(1.0)
    threshold.SetThresholdFunction(vtkThreshold.THRESHOLD_BETWEEN)
    threshold.Update()

    geometry = vtkGeometryFilter()
    geometry.SetInputConnection(threshold.GetOutputPort())
    geometry.Update()
    polydata = vtkPolyData.SafeDownCast(geometry.GetOutput())
    if polydata is None or polydata.GetNumberOfPolys() == 0:
        raise RuntimeError(f"threshold alpha surface is empty for {field_name}")

    writer = vtkXMLPolyDataWriter()
    writer.SetFileName(str(destination))
    writer.SetInputData(polydata)
    writer.SetDataModeToBinary()
    writer.SetCompressorTypeToZLib()
    if writer.Write() != 1:
        raise RuntimeError(f"could not write {destination}")
    return polydata, {
        "field": field_name,
        "threshold": 0.01,
        "cells_ge_threshold": int(threshold.GetOutput().GetNumberOfCells()),
        "surface_points": int(polydata.GetNumberOfPoints()),
        "surface_polygons": int(polydata.GetNumberOfPolys()),
        "surface_vtp": str(destination),
        "surface_vtp_sha256": sha256(destination),
        "surface_vtp_bytes": destination.stat().st_size,
    }


def projected_polygons(polydata, focal, right, up, toward_camera):
    points = vtk_to_numpy(polydata.GetPoints().GetData())
    polys = polydata.GetPolys()
    offsets = vtk_to_numpy(polys.GetOffsetsArray())
    connectivity = vtk_to_numpy(polys.GetConnectivityArray())
    polygons = []
    depths = []
    for index in range(len(offsets) - 1):
        ids = connectivity[offsets[index] : offsets[index + 1]]
        if len(ids) < 3:
            continue
        relative = points[ids] - focal
        # Shift the projection back to absolute world coordinates so the axes
        # display the actual nozzle-relative x/y values in metres.
        polygons.append(
            np.column_stack((relative @ right + focal @ right, relative @ up + focal @ up))
        )
        depths.append(float(np.mean(relative @ toward_camera)))
    order = np.argsort(depths, kind="stable")
    return [polygons[index] for index in order]


def render_projection(surfaces: list[vtkPolyData], metrics: dict) -> Path:
    # Camera looks from the positive spanwise side, angled slightly downstream.
    focal = np.array([7.25, -3.0, 0.0], dtype=np.float64)
    toward_camera = EYE_VECTOR / np.linalg.norm(EYE_VECTOR)
    camera_forward = -toward_camera
    world_up = np.array([0.0, 1.0, 0.0])
    right = np.cross(camera_forward, world_up)
    right /= np.linalg.norm(right)
    up = np.cross(right, camera_forward)
    up /= np.linalg.norm(up)

    palette = "#1769aa"
    labels = (
        ("Δt = 0.0001 s", "air-backflow-water-030"),
        ("Δt = 0.0003 s", "air-backflow-water-dt0003-030"),
    )
    projected = [
        projected_polygons(surface, focal, right, up, toward_camera) for surface in surfaces
    ]
    # Shared physical bounds keep the pair directly comparable and include the
    # nozzle origin even though the selected cells begin slightly below it.
    fig, axes = plt.subplots(1, 2, figsize=(16.0, 4.6), constrained_layout=False)
    fig.subplots_adjust(left=0.055, right=0.99, bottom=0.18, top=0.83, wspace=0.06)
    for index, axis in enumerate(axes):
        collection = PolyCollection(
            projected[index],
            facecolors=palette,
            edgecolors="none",
            linewidths=0,
            antialiased=False,
        )
        axis.add_collection(collection)
        axis.set_xlim(*PLOT_BOUNDS[0])
        axis.set_ylim(*PLOT_BOUNDS[1])
        axis.set_aspect("equal", adjustable="box")
        axis.set_title(
            f"{labels[index][0]}  |  8 ranks\n"
            f"{labels[index][1]}  |  {metrics['mesh']['cells']:,} cells",
            fontsize=12,
        )
        axis.set_xlabel("x crossflow (m) →")
        axis.set_ylabel("y upward (m) ↑")
        axis.set_xticks(np.arange(0.0, 16.0, 5.0))
        axis.set_yticks(np.arange(-6.0, 1.0, 2.0))
        axis.tick_params(labelsize=9, length=3, colors="#4b5563")
        axis.grid(True, color="#aeb7c2", linewidth=0.45, alpha=0.35)
        axis.spines["top"].set_visible(False)
        axis.spines["right"].set_visible(False)
        for spine_name in ("left", "bottom"):
            axis.spines[spine_name].set_visible(True)
            axis.spines[spine_name].set_color("#6b7280")
            axis.spines[spine_name].set_linewidth(0.6)
        axis.scatter(
            [0.0],
            [0.0],
            marker="+",
            color="#111827",
            s=55,
            linewidths=1.35,
            zorder=10,
            clip_on=False,
        )
        axis.annotate(
            "nozzle (0, 0)",
            xy=(0.0, 0.0),
            xytext=(7, 7),
            textcoords="offset points",
            fontsize=8,
            color="#111827",
            ha="left",
            va="bottom",
            bbox={"boxstyle": "round,pad=0.2", "facecolor": "white", "alpha": 0.78, "linewidth": 0},
            zorder=11,
        )

    fig.suptitle(
        "Computed water cells: α.water ≥ 0.01 at t = 0.3000 s",
        fontsize=15,
        y=0.985,
    )
    fig.text(
        0.5,
        0.015,
        "Thresholded finite-volume cells (not a continuous interface) • same x/y bounds and "
        "orthographic +z view • coarse exploratory fields, not a validated discharge prediction",
        ha="center",
        fontsize=10,
    )
    path = SUMMARY / "water-alpha-001-matched-fields-030.png"
    fig.savefig(path, dpi=180, facecolor="white")
    plt.close(fig)
    return path


def save_pv_state(vtu_path: Path) -> Path:
    reader = XMLUnstructuredGridReader(
        registrationName="Matched t=0.3 s alpha.water fields",
        FileName=[str(vtu_path)],
    )
    reader.UpdatePipeline()
    state = SUMMARY / "water-alpha-threshold-comparison.pvsm"
    for label in ("dt0001", "dt0003"):
        threshold = Threshold(registrationName=f"alpha.water >= 0.01 {label}", Input=reader)
        threshold.Scalars = ["CELLS", f"alpha_{label}"]
        threshold.LowerThreshold = 0.01
        threshold.UpperThreshold = 1.0
        threshold.ThresholdMethod = "Between"
        threshold.UpdatePipeline()
    SaveState(str(state))
    return state


def main() -> None:
    SUMMARY.mkdir(parents=True, exist_ok=True)
    global_fields_path = STAGING / "global-alpha-fields-t030.npz"
    with np.load(global_fields_path) as fields:
        centers = fields["centers_m"]
        volumes = fields["volumes_m3"]
        alpha_dt0001 = fields["alpha_dt0001"]
        alpha_dt0003 = fields["alpha_dt0003"]
        alpha_delta = fields["alpha_difference_dt0003_minus_dt0001"]
    if centers.shape != (299520, 3) or alpha_dt0001.shape != (299520,):
        raise RuntimeError("field comparison arrays have unexpected shape")

    reader = __import__("paraview.simple", fromlist=["OpenFOAMReader"]).OpenFOAMReader(
        registrationName="Native coarse Rouaix mesh",
        FileName=str(SOURCE_CASE / "case.foam"),
    )
    reader.CaseType = "Reconstructed Case"
    reader.SkipZeroTime = 0
    reader.MeshRegions = ["internalMesh"]
    reader.CellArrays = ["alpha.water"]
    reader.UpdatePipeline(time=0.0)
    raw_grid = servermanager.Fetch(reader)
    grid = as_unstructured_grid(raw_grid)
    if grid.GetNumberOfCells() != 299520:
        raise RuntimeError(f"native mesh reader returned {grid.GetNumberOfCells()} cells")
    mesh_order = verify_native_cell_order(grid, centers, volumes)

    arrays = {
        "alpha_dt0001": alpha_dt0001,
        "alpha_dt0003": alpha_dt0003,
        "alpha_difference_dt0003_minus_dt0001": alpha_delta,
    }
    for name, values in arrays.items():
        vtk_array = numpy_to_vtk(
            np.asarray(values, dtype=np.float64), deep=True, array_type=VTK_DOUBLE
        )
        vtk_array.SetName(name)
        grid.GetCellData().AddArray(vtk_array)

    field_vtu = RUN / "staging" / "native-mesh-alpha-fields-t030.vtu"
    vtu_writer = vtkXMLUnstructuredGridWriter()
    vtu_writer.SetFileName(str(field_vtu))
    vtu_writer.SetInputData(grid)
    vtu_writer.SetDataModeToBinary()
    vtu_writer.SetCompressorTypeToZLib()
    if vtu_writer.Write() != 1:
        raise RuntimeError(f"could not write {field_vtu}")

    surfaces = []
    surface_receipts = []
    surface_dir = RUN / "surfaces"
    surface_dir.mkdir(exist_ok=True)
    for label, array_name in (("dt0001", "alpha_dt0001"), ("dt0003", "alpha_dt0003")):
        surface_path = surface_dir / f"alpha-ge-001-{label}.vtp"
        polydata, receipt = make_threshold_surface(grid, array_name, surface_path)
        surfaces.append(polydata)
        surface_receipts.append(receipt)

    comparison = json.loads((SUMMARY / "field-comparison.json").read_text(encoding="utf-8"))
    image = render_projection(surfaces, comparison)
    state = save_pv_state(field_vtu)
    result = {
        "schema_version": 1,
        "software": PV_VERSION,
        "render_backend": "Matplotlib Agg CPU; no ParaView Render/SaveScreenshot/OpenGL call",
        "threshold_definition": "cell alpha.water >= 0.01; opaque exterior surface of selected cells",
        "camera": {
            "projection": "orthographic, fixed projection axes",
            "focal_point_m": [7.25, -3.0, 0.0],
            "view_direction_from_focal_to_camera": [
                float(value) for value in EYE_VECTOR / np.linalg.norm(EYE_VECTOR)
            ],
            "camera_up_world": [0.0, 1.0, 0.0],
            "screen_axes": {
                "horizontal": "absolute x crossflow (m)",
                "vertical": "absolute y upward (m)",
            },
            "shared_bounds_m": {"x": list(PLOT_BOUNDS[0]), "y": list(PLOT_BOUNDS[1])},
            "nozzle_reference_m": [0.0, 0.0],
            "same_in_both_panels": True,
        },
        "native_mesh_cell_order_check": mesh_order,
        "field_vtu": {
            "path": str(field_vtu),
            "sha256": sha256(field_vtu),
            "bytes": field_vtu.stat().st_size,
        },
        "threshold_surfaces": surface_receipts,
        "png": {
            "path": str(image),
            "sha256": sha256(image),
            "bytes": image.stat().st_size,
            "dpi": 180,
        },
        "pvsm": {
            "path": str(state),
            "sha256": sha256(state),
            "bytes": state.stat().st_size,
            "saved_without_render": True,
        },
        "provenance": {
            "global_alpha_fields_sha256": sha256(global_fields_path),
            "native_mesh_case": str(SOURCE_CASE),
            "field_comparison_json": str(SUMMARY / "field-comparison.json"),
            "field_comparison_sha256": sha256(SUMMARY / "field-comparison.json"),
        },
        "alpha_threshold_support_metrics": {
            label: comparison["cases"][label]["metrics"]["alpha_threshold_cell_support"]
            for label in ("dt0001", "dt0003")
        },
    }
    output = SUMMARY / "visualization-receipt.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
