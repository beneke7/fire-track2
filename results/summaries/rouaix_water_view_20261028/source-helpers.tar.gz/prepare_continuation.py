#!/usr/bin/env python3
"""Prepare (but never launch) the coarse water continuation from t=0.3 s."""

from __future__ import annotations

import hashlib
import json
import math
import re
import shutil
import tarfile
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[3]
RUNS = REPO / "results/runs/rouaix-water-view-20261028"
PARENT_RUNS = REPO / "results/runs/rouaix-backflow-local-20261028"
SOURCE_ID = "air-backflow-water-dt0003-030"
RUN_ID = "air-backflow-water-continue-030-to-09999-dt0003"
SOURCE_CASE = PARENT_RUNS / SOURCE_ID
SOURCE_RESULT = PARENT_RUNS / "container-runs" / SOURCE_ID
DESTINATION = RUNS / "continuation-to-09999"
CASE = DESTINATION / "case"
FIELD_COMPARISON_PATH = REPO / "results/summaries/rouaix_water_view_20261028/field-comparison.json"
RESTART_PATH = "processors8/0.300000000000"
ARCHIVE_TIME_PATH = "./case/times/processors8/0.300000000000/"
RESTART_FIELDS = (
    "U",
    "alpha.water",
    "epsilon",
    "k",
    "nut",
    "p",
    "p_rgh",
    "phi",
    "uniform/cumulativeContErr",
    "uniform/functionObjects/functionObjectProperties",
    "uniform/time",
)
DT = 0.0003
START_TIME = 0.3
END_TIME = 0.9999
EXPECTED_STEPS = 2333
WATER_RHO = 997.6


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def tree_hashes(root: Path) -> dict[str, str]:
    return {
        path.relative_to(root).as_posix(): sha256(path)
        for path in sorted(root.rglob("*"))
        if path.is_file()
    }


def replace_once(text: str, pattern: str, replacement: str, key: str) -> str:
    updated, count = re.subn(pattern, replacement, text, flags=re.MULTILINE)
    if count != 1:
        raise RuntimeError(f"expected one {key} dictionary entry, found {count}")
    return updated


def prepare_control_dict() -> dict[str, str]:
    path = CASE / "system/controlDict"
    original = path.read_text(encoding="utf-8")
    updated = original
    changes = {
        "startFrom": (r"^startFrom\s+[^;]+;", "startFrom latestTime;"),
        "startTime": (
            r"^startTime\s+[^;]+;",
            f"startTime {START_TIME:.12f};",
        ),
        "endTime": (r"^endTime\s+[^;]+;", f"endTime {END_TIME:.12f};"),
        "maxDeltaT": (r"^maxDeltaT\s+[^;]+;", f"maxDeltaT {DT:.12g};"),
        "writeInterval": (r"^writeInterval\s+[^;]+;", "writeInterval 0.2;"),
    }
    for key, (pattern, replacement) in changes.items():
        updated = replace_once(updated, pattern, replacement, key)
    delta_match = re.search(r"^deltaT\s+([^;]+);", updated, flags=re.MULTILINE)
    if delta_match is None or float(delta_match.group(1)) != DT:
        raise RuntimeError("fixed deltaT changed unexpectedly in the continuation")
    if not re.search(r"^adjustTimeStep\s+no;", updated, flags=re.MULTILINE):
        raise RuntimeError("continuation must keep adaptive time stepping disabled")
    if not re.search(r"^writeControl\s+runTime;", updated, flags=re.MULTILINE):
        raise RuntimeError("expected runTime write control for sparse continuation snapshots")
    path.write_text(updated, encoding="utf-8")
    return {key: replacement for key, (_pattern, replacement) in changes.items()}


def extract_restart(archive_path: Path, archive_sha256: str) -> dict[str, Any]:
    case_path = CASE / RESTART_PATH
    case_path.mkdir(parents=True, exist_ok=False)
    extracted: dict[str, str] = {}
    expected_names = {ARCHIVE_TIME_PATH + name for name in RESTART_FIELDS}
    with tarfile.open(archive_path, mode="r:gz") as archive:
        members = {member.name: member for member in archive.getmembers()}
        missing = expected_names - members.keys()
        if missing:
            raise RuntimeError(f"archive is missing restart files: {sorted(missing)}")
        for archive_name in sorted(expected_names):
            member = members[archive_name]
            if not member.isfile():
                raise RuntimeError(f"restart item is not a regular file: {archive_name}")
            relpath = archive_name.removeprefix(ARCHIVE_TIME_PATH)
            destination = case_path / relpath
            destination.parent.mkdir(parents=True, exist_ok=True)
            source = archive.extractfile(member)
            if source is None:
                raise RuntimeError(f"cannot read archived restart file {archive_name}")
            with source, destination.open("xb") as output:
                shutil.copyfileobj(source, output)
            extracted[relpath] = sha256(destination)
    return {
        "source_archive": str(archive_path),
        "source_archive_sha256": archive_sha256,
        "source_archive_time_path": ARCHIVE_TIME_PATH,
        "restart_directory": RESTART_PATH,
        "field_handler": "collated",
        "restart_files_sha256": extracted,
    }


def main() -> None:
    if DESTINATION.exists():
        raise FileExistsError(f"refusing to overwrite continuation preparation {DESTINATION}")
    source_input = json.loads((SOURCE_CASE / "case-inputs.json").read_text(encoding="utf-8"))
    source_result = json.loads((SOURCE_RESULT / "run-result.json").read_text(encoding="utf-8"))
    source_archive = SOURCE_RESULT / "result.tar.gz"
    archive_hash = sha256(source_archive)
    if archive_hash != source_result["archive_sha256"]:
        raise RuntimeError("terminal archive SHA-256 differs from its result receipt")
    if source_result["terminal"]["solver_time_s"] != "0.300000000000":
        raise RuntimeError("source water run did not complete at the declared restart time")
    if (
        not source_result["terminal"]["end_marker"]
        or source_result["terminal"]["solver_exit_code"] != 0
    ):
        raise RuntimeError("source water run did not end cleanly")
    if not source_result["snapshot_inventory"]["passed"]:
        raise RuntimeError("source terminal field inventory did not pass")
    archive_verification = json.loads(
        (SOURCE_RESULT / "archive-verification.json").read_text(encoding="utf-8")
    )
    if not archive_verification["remote_local_sha_match"]:
        raise RuntimeError("source archive remote/local SHA verification failed")
    field_comparison = json.loads(FIELD_COMPARISON_PATH.read_text(encoding="utf-8"))
    field_integral_checks = field_comparison["field_integral_map_checks"]
    if not all(row["passes_mapping_gate"] for row in field_integral_checks.values()):
        raise RuntimeError("matched terminal fields do not close against both solver ledgers")
    field_difference = field_comparison["field_difference_dt0003_minus_dt0001"]
    field_comparison_evidence = {
        "path": str(FIELD_COMPARISON_PATH),
        "sha256": sha256(FIELD_COMPARISON_PATH),
        "map_and_ledger_checks_passed": True,
        "volume_weighted_absolute_alpha_difference_m3": field_difference[
            "volume_weighted_absolute_alpha_difference_m3"
        ],
        "half_l1_minimum_redistributed_volume_m3": field_difference[
            "half_difference_as_minimum_redistributed_volume_m3"
        ],
        "l1_relative_to_dt0001_water_volume": field_difference[
            "absolute_difference_relative_to_dt0001_water_volume"
        ],
        "centroid_shift_magnitude_m": field_difference["centroid_shift_magnitude_m"],
        "centroid_shift_dt0003_minus_dt0001_m": field_difference[
            "centroid_shift_dt0003_minus_dt0001_m"
        ],
        "interpretation": (
            "The .0003 s endpoint is materially different in spatial alpha distribution "
            "from the matched .0001 s field at almost equal total water volume. The "
            "continuation remains a temporal-sensitivity follow-up, not an accuracy arm."
        ),
    }

    DESTINATION.mkdir(parents=True)
    shutil.copytree(SOURCE_CASE, CASE)
    restart = extract_restart(source_archive, archive_hash)
    control_changes = prepare_control_dict()

    case_input = dict(source_input)
    case_input.update(
        {
            "case_id": "ROUAIX-WATER-NOZZLE-ORIGINAL-CONTINUE-DT0003-08RANK",
            "queue_run_name": RUN_ID,
            "scope": (
                "Exploratory temporal-sensitivity continuation from the verified t=0.3000 s "
                "total-pressure water snapshot; this is not an accuracy baseline or E1 result."
            ),
            "start_from": "latestTime",
            "start_time_s": START_TIME,
            "end_time_s": END_TIME,
            "delta_t_s": DT,
            "expected_steps": EXPECTED_STEPS,
            "expected_steps_from_restart": EXPECTED_STEPS,
            "field_write_times_s": [0.3, 0.5001, 0.7002, 0.9003, 0.9999],
            "write_interval_s": 0.2,
            "initial_condition": (
                "restart from the t=0.3000 s checkpoint of the total-pressure "
                "water-nozzle case; not a fresh t=0 startup"
            ),
            "time_step_diagnostic": (
                "Fixed-deltaT continuation for temporal sensitivity only; not an "
                "accuracy reference or E1 result."
            ),
            "runtime_guard": {
                "max_abs_U_m_s": 200.0,
                "hard_wall_seconds": 900,
                "grace_seconds": 120,
                "write_and_stop_signal": 12,
            },
            "launch_state": (
                "prepared only; the matched field comparison shows material timestep sensitivity. "
                "Do not launch unless the primary explicitly selects this temporal-sensitivity "
                "follow-up and suitable CPU capacity is available."
            ),
            "restart_checkpoint": restart,
            "preparation_note": (
                "0.3000 + 2333*0.0003 = 0.9999 s. The fixed timestep is retained; "
                "no shortened final step or adaptive stepping is used."
            ),
        }
    )
    nested_diagnostics = dict(source_input["diagnostics"])
    nested_diagnostics["field_write_times_s"] = case_input["field_write_times_s"]
    case_input["diagnostics"] = nested_diagnostics
    case_input["case_files_sha256"] = {
        key: value for key, value in tree_hashes(CASE).items() if key != "case-inputs.json"
    }
    case_input["case_files_total_bytes"] = sum(
        path.stat().st_size
        for path in CASE.rglob("*")
        if path.is_file() and path.name != "case-inputs.json"
    )
    (CASE / "case-inputs.json").write_text(json.dumps(case_input, indent=2) + "\n")

    prepared_files = tree_hashes(CASE)
    restart_checks = {name: (CASE / RESTART_PATH / name).is_file() for name in RESTART_FIELDS}
    if not all(restart_checks.values()):
        raise RuntimeError("one or more required restart files were not staged")
    if len(restart["restart_files_sha256"]) != len(RESTART_FIELDS):
        raise RuntimeError("restart payload file inventory does not match declaration")
    if not math.isclose(EXPECTED_STEPS * DT + START_TIME, END_TIME, rel_tol=0.0, abs_tol=1e-12):
        raise RuntimeError("fixed-step endpoint arithmetic is inconsistent")
    receipt = {
        "schema_version": 1,
        "preparation_state": "prepared_hold_no_solver_launched",
        "run_id": RUN_ID,
        "source_case": SOURCE_ID,
        "source_case_inputs_sha256": sha256(SOURCE_CASE / "case-inputs.json"),
        "source_terminal_archive_sha256": archive_hash,
        "source_container_id": source_result["container_id"],
        "source_terminal_time_s": source_result["terminal"]["solver_time_s"],
        "source_terminal_end_and_exit_ok": True,
        "source_snapshot_inventory_passed": source_result["snapshot_inventory"]["passed"],
        "field_comparison": field_comparison_evidence,
        "launch_state": "held_temporal_sensitivity_no_solver_launched",
        "continuation": {
            "start_time_s": START_TIME,
            "end_time_s": END_TIME,
            "delta_t_s": DT,
            "steps": EXPECTED_STEPS,
            "fixed_dt_endpoint_note": "Nearest fixed-dt endpoint at/below requested 1.0 s is 0.9999 s.",
            "field_write_times_s": case_input["field_write_times_s"],
            "guard_speed_m_s": 200.0,
            "hard_wall_s": 900,
            "grace_s": 120,
            "cpu_ranks": 8,
            "memory_gib": 3,
            "gpu": False,
            "projected_clock_time_s": round(EXPECTED_STEPS * 274.0 / 1000.0, 1),
        },
        "control_dict_changes": control_changes,
        "restart_files_present": restart_checks,
        "restart_files_sha256": restart["restart_files_sha256"],
        "prepared_case_files_sha256": prepared_files,
        "release_gate": [
            "Use the exact 8-rank cellProcAddressing map from the identical 299520-cell mesh.",
            "Both t=0.3000 s alpha.water fields must map to the native mesh and volume integrals must agree with their solver-ledger volumes within 1e-6 relative.",
            "Review the volume-weighted alpha difference, centroids, and alpha>=0.01 extents before any launch.",
            "Keep the continuation held: the dt=0.0003 field is a temporal sensitivity, not the reference accuracy arm.",
            "Only the primary may opt into this follow-up after current compute pressure clears.",
        ],
        "source_context": {
            "solver": source_input["solver"],
            "mesh_cells": 299520,
            "mesh_hashes": source_input["mesh_files_sha256"],
            "mpi_ranks": 8,
            "pressure_boundary": source_input["open_pressure_boundary"],
            "momentum_convection": source_input["momentum_convection"],
            "turbulence": source_input["turbulence"],
        },
    }
    (DESTINATION / "prepared-case.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(
        json.dumps(
            {
                "preparation_state": receipt["preparation_state"],
                "case": str(CASE),
                "source_checkpoint_sha256": archive_hash,
                "restart_files": len(restart_checks),
                "case_file_count": len(prepared_files),
                "end_time_s": END_TIME,
                "steps": EXPECTED_STEPS,
                "solver_launched": False,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
