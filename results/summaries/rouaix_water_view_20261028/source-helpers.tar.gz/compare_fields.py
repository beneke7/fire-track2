#!/usr/bin/env python3
"""Compare terminal alpha.water on the exact native 8-rank cell map."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import re
import tempfile
from pathlib import Path
from typing import Any

import numpy as np

REPO = Path(__file__).resolve().parents[3]
RUN = Path(__file__).resolve().parent
STAGING = RUN / "staging"
SOURCE_RUNS = REPO / "results/runs/rouaix-backflow-local-20261028"
SUMMARY_ROOT = REPO / "results/summaries/rouaix_backflow_local_20261028"
OUTPUT_SUMMARY = REPO / "results/summaries/rouaix_water_view_20261028"
NATIVE_MESH = SOURCE_RUNS / "native-mesh"
MAP_ROOT = REPO / "results/runs/rouaix-pressure-total-restart-20261028/native-utility/map8"
MAP_FILE = MAP_ROOT / "processor-mesh/processors8/constant/polyMesh/cellProcAddressing"
ARCHIVE_NAME = "./case/times/processors8/0.300000000000/alpha.water"
CASE_LABELS = ("dt0001", "dt0003")
WATER_DENSITY_KG_M3 = 997.6
VOLUME_GATE_RELATIVE = 1e-6


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def load_scalar_field(path: Path) -> np.ndarray:
    raw = path.read_bytes()
    match = re.search(rb"internalField\s+nonuniform\s+List<scalar>\s+(\d+)\s*\(\s*", raw)
    if match is None:
        raise RuntimeError(f"cannot locate binary internalField in {path}")
    count = int(match.group(1))
    start = match.end()
    end = start + count * 8
    if end > len(raw):
        raise RuntimeError(f"truncated scalar list in {path}")
    values = np.frombuffer(raw, dtype="<f8", count=count, offset=start).copy()
    if not np.all(np.isfinite(values)):
        raise RuntimeError(f"nonfinite scalar values in {path}")
    return values


def load_label_field(path: Path) -> np.ndarray:
    raw = path.read_bytes()
    match = re.search(rb"\n(\d+)\n\(\s*", raw)
    if match is None:
        raise RuntimeError(f"cannot locate binary label list in {path}")
    count = int(match.group(1))
    start = match.end()
    end = start + count * 4
    if end > len(raw):
        raise RuntimeError(f"truncated label list in {path}")
    return np.frombuffer(raw, dtype="<i4", count=count, offset=start).astype(np.int64, copy=True)


def demux_helper():
    source = (
        REPO
        / "results/runs/rouaix-one-node-paraview-20261026/unpacked-display-case/demux_collated_blocks.py"
    )
    spec = importlib.util.spec_from_file_location("demux_collated_blocks", source)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load the existing byte-preserving demux helper")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_addressing() -> tuple[dict[int, np.ndarray], dict[str, Any]]:
    receipt = load(MAP_ROOT / "map8-receipt.json")
    archive = MAP_ROOT / "map8-processor-mesh.tar.gz"
    archive_sha = sha256(archive)
    if archive_sha != receipt["processor_mesh_archive_sha256"]:
        raise RuntimeError("8-rank map archive differs from its receipt")
    if sha256(MAP_FILE) != receipt["cellProcAddressing_sha256"]:
        raise RuntimeError("collated cellProcAddressing differs from its receipt")
    for filename, digest in receipt["source_mesh_hashes"].items():
        if sha256(NATIVE_MESH / filename) != digest:
            raise RuntimeError(f"native mesh {filename} does not match the address-map source")

    demux = demux_helper()
    maps: dict[int, np.ndarray] = {}
    with tempfile.TemporaryDirectory(prefix="rouaix-map8-") as temp_name:
        temp = Path(temp_name)
        demux.demux_file(MAP_FILE, temp, "constant/polyMesh/cellProcAddressing", 8, 8)
        for rank in range(8):
            maps[rank] = load_label_field(
                temp / f"processor{rank}/constant/polyMesh/cellProcAddressing"
            )

    counts = [len(maps[rank]) for rank in range(8)]
    all_global_ids = np.concatenate([maps[rank] for rank in range(8)])
    map_cover_ok = (
        counts == [37440] * 8
        and len(all_global_ids) == 299520
        and int(all_global_ids.min()) == 0
        and int(all_global_ids.max()) == 299519
        and np.unique(all_global_ids).size == 299520
    )
    if not map_cover_ok or receipt["global_cell_ids"]["exact_cover"] != "0..299519":
        raise RuntimeError("eight processor maps do not exactly cover the native cells")
    return maps, {
        "path": str(MAP_FILE),
        "map_archive": str(archive),
        "map_archive_sha256": archive_sha,
        "cellProcAddressing_sha256": receipt["cellProcAddressing_sha256"],
        "receipt_created_utc": receipt["created_utc"],
        "method": receipt["partition"]["method"],
        "coeffs": receipt["partition"]["coeffs"],
        "ranks": receipt["partition"]["ranks"],
        "cell_counts": counts,
        "global_cell_id_exact_cover": map_cover_ok,
        "native_mesh_source_hashes_match": True,
    }


def load_global_alpha(label: str, maps: dict[int, np.ndarray]) -> tuple[np.ndarray, dict[str, Any]]:
    alpha = np.empty(299520, dtype=np.float64)
    seen = np.zeros(299520, dtype=bool)
    rank_receipts = []
    for rank in range(8):
        path = STAGING / f"demux-{label}" / f"processor{rank}" / "0.300000000000/alpha.water"
        local = load_scalar_field(path)
        address = maps[rank]
        if len(local) != len(address):
            raise RuntimeError(
                f"{label} processor{rank} field/address count differs: "
                f"{len(local)} vs {len(address)}"
            )
        if np.any(seen[address]):
            raise RuntimeError(f"duplicate global-cell mapping in processor{rank}")
        alpha[address] = local
        seen[address] = True
        rank_receipts.append(
            {
                "rank": rank,
                "cells": len(local),
                "alpha_min": float(local.min()),
                "alpha_max": float(local.max()),
                "alpha_field_sha256": sha256(path),
            }
        )
    if not np.all(seen):
        raise RuntimeError("field mapping left native cells uncovered")
    if alpha.min() < -1e-12 or alpha.max() > 1.0 + 1e-12:
        raise RuntimeError(f"alpha.water outside [0,1]: [{alpha.min()}, {alpha.max()}]")
    return alpha, {
        "mapped_cells": len(alpha),
        "alpha_min": float(alpha.min()),
        "alpha_max": float(alpha.max()),
        "rank_fields": rank_receipts,
    }


def volume_weighted_metrics(
    alpha: np.ndarray, centers: np.ndarray, volumes: np.ndarray
) -> dict[str, Any]:
    water_volume = float(np.dot(alpha, volumes))
    water_mass = water_volume * WATER_DENSITY_KG_M3
    weights = alpha * volumes
    centroid = np.einsum("i,ij->j", weights, centers) / water_volume
    active = alpha >= 0.01
    extents = {
        axis: [float(centers[active, i].min()), float(centers[active, i].max())]
        for i, axis in enumerate(("x", "y", "z"))
    }
    threshold_summaries = {}
    for threshold in (0.01, 0.1, 0.9):
        selected = alpha >= threshold
        selected_centers = centers[selected]
        downstream = selected & (centers[:, 0] >= 10.0)
        threshold_summaries[f"alpha_ge_{threshold:g}"] = {
            "cell_count": int(selected.sum()),
            "cell_support_volume_m3": float(volumes[selected].sum()),
            "cell_center_extents_m": {
                axis: [
                    float(selected_centers[:, i].min()),
                    float(selected_centers[:, i].max()),
                ]
                for i, axis in enumerate(("x", "y", "z"))
            },
            "cells_with_x_ge_10_m": int(downstream.sum()),
            "cell_support_volume_with_x_ge_10_m_m3": float(volumes[downstream].sum()),
        }
    return {
        "water_volume_m3": water_volume,
        "water_mass_kg_at_997_6_kg_m3": water_mass,
        "mass_centroid_m": [float(value) for value in centroid],
        "alpha_ge_0_01_cell_count": int(active.sum()),
        "alpha_ge_0_01_cell_volume_m3": float(volumes[active].sum()),
        "alpha_ge_0_01_cell_center_extents_m": extents,
        "alpha_ge_0_01_min_center_y_m": float(centers[active, 1].min()),
        "alpha_ge_0_01_max_center_x_m": float(centers[active, 0].max()),
        "alpha_ge_0_01_max_abs_z_m": float(np.max(np.abs(centers[active, 2]))),
        "alpha_threshold_cell_support": threshold_summaries,
    }


def main() -> None:
    mesh = np.load(STAGING / "native-cell-centres-volumes.npz")
    centers = mesh["centers_m"]
    volumes = mesh["volumes_m3"]
    if centers.shape != (299520, 3) or volumes.shape != (299520,):
        raise RuntimeError("native mesh arrays have unexpected shape")

    receipts = load(STAGING / "input-manifest.json")
    map_arrays, map_receipt = load_addressing()
    source_json = {
        "dt0001": load(SUMMARY_ROOT / "water-total-pressure-diagnostics.json"),
        "dt0003": load(SUMMARY_ROOT / "water-dt0003-diagnostics.json"),
    }
    ledger_volumes = {
        label: source_json[label]["water_volume_m3"]["terminal"]
        if label == "dt0001"
        else source_json[label]["water_volume_m3"]["terminal"]
        for label in CASE_LABELS
    }

    fields: dict[str, np.ndarray] = {}
    field_receipts: dict[str, Any] = {}
    for label in CASE_LABELS:
        fields[label], field_receipts[label] = load_global_alpha(label, map_arrays)

    centers_volumes = {
        label: volume_weighted_metrics(fields[label], centers, volumes) for label in CASE_LABELS
    }
    closure = {
        label: {
            "field_volume_m3": centers_volumes[label]["water_volume_m3"],
            "solver_ledger_volume_m3": ledger_volumes[label],
            "signed_residual_m3": centers_volumes[label]["water_volume_m3"] - ledger_volumes[label],
            "relative_residual": (centers_volumes[label]["water_volume_m3"] - ledger_volumes[label])
            / ledger_volumes[label],
            "passes_mapping_gate": abs(
                centers_volumes[label]["water_volume_m3"] - ledger_volumes[label]
            )
            / ledger_volumes[label]
            <= VOLUME_GATE_RELATIVE,
        }
        for label in CASE_LABELS
    }
    baseline = fields["dt0001"]
    candidate = fields["dt0003"]
    alpha_delta = candidate - baseline
    abs_delta = np.abs(alpha_delta)
    absolute_volume_difference = float(np.dot(abs_delta, volumes))
    domain_volume = float(volumes.sum())
    threshold_001 = abs_delta >= 0.01
    threshold_005 = abs_delta >= 0.05
    centroid_001 = np.asarray(centers_volumes["dt0001"]["mass_centroid_m"])
    centroid_003 = np.asarray(centers_volumes["dt0003"]["mass_centroid_m"])

    output_fields = STAGING / "global-alpha-fields-t030.npz"
    np.savez_compressed(
        output_fields,
        centers_m=centers,
        volumes_m3=volumes,
        alpha_dt0001=baseline,
        alpha_dt0003=candidate,
        alpha_difference_dt0003_minus_dt0001=alpha_delta,
    )
    result = {
        "schema_version": 1,
        "time_s": 0.3,
        "purpose": "Matched-cell field comparison of the two fresh total-pressure water-nozzle cases.",
        "interpretation": (
            "The fixed 0.0003 s case reached the same coarse 0.3000 s horizon. "
            "This exploratory same-grid comparison is not a timestep-convergence "
            "or E1 validation decision."
        ),
        "mesh": {
            "cells": 299520,
            "domain_volume_m3": domain_volume,
            "native_mesh_center_volume_npz": str(STAGING / "native-cell-centres-volumes.npz"),
            "native_mesh_source": str(NATIVE_MESH),
            "coordinate_frame": {"x": "crossflow +", "y": "upward +", "z": "spanwise +"},
            "centre_volume_order_validated_by_solver_ledger": True,
        },
        "processor_cell_addressing": map_receipt,
        "case_sources": {
            "dt0001": {
                "run_id": "air-backflow-water-030",
                "archive_sha256": receipts[0]["archive_sha256"],
                "archive_path": str(
                    SOURCE_RUNS / "container-runs/air-backflow-water-030/result.tar.gz"
                ),
                "archive_terminal_volume_ledger_m3": ledger_volumes["dt0001"],
                "solver_clock_s": source_json["dt0001"]["solver"]["final_execution_clock_line"],
            },
            "dt0003": {
                "run_id": "air-backflow-water-dt0003-030",
                "archive_sha256": receipts[1]["archive_sha256"],
                "archive_path": str(
                    SOURCE_RUNS / "container-runs/air-backflow-water-dt0003-030/result.tar.gz"
                ),
                "archive_terminal_volume_ledger_m3": ledger_volumes["dt0003"],
                "solver_clock_s": source_json["dt0003"]["solver"]["final_execution_clock_line"],
            },
        },
        "field_integral_map_checks": closure,
        "cases": {
            "dt0001": {
                "delta_t_s": 0.0001,
                "mpi_ranks": 8,
                "metrics": centers_volumes["dt0001"],
                "field_extraction": field_receipts["dt0001"],
            },
            "dt0003": {
                "delta_t_s": 0.0003,
                "mpi_ranks": 8,
                "metrics": centers_volumes["dt0003"],
                "field_extraction": field_receipts["dt0003"],
            },
        },
        "field_difference_dt0003_minus_dt0001": {
            "volume_weighted_absolute_alpha_difference_m3": absolute_volume_difference,
            "half_difference_as_minimum_redistributed_volume_m3": absolute_volume_difference / 2.0,
            "absolute_difference_relative_to_dt0001_water_volume": (
                absolute_volume_difference / centers_volumes["dt0001"]["water_volume_m3"]
            ),
            "domain_volume_weighted_mean_absolute_alpha_difference": (
                absolute_volume_difference / domain_volume
            ),
            "rms_volume_weighted_alpha_difference": float(
                np.sqrt(np.dot(alpha_delta * alpha_delta, volumes) / domain_volume)
            ),
            "max_abs_alpha_difference": float(abs_delta.max()),
            "cells_abs_delta_ge_0_01": int(threshold_001.sum()),
            "volume_abs_delta_ge_0_01_m3": float(volumes[threshold_001].sum()),
            "cells_abs_delta_ge_0_05": int(threshold_005.sum()),
            "volume_abs_delta_ge_0_05_m3": float(volumes[threshold_005].sum()),
            "centroid_shift_dt0003_minus_dt0001_m": [
                float(value) for value in (centroid_003 - centroid_001)
            ],
            "centroid_shift_magnitude_m": float(np.linalg.norm(centroid_003 - centroid_001)),
            "volume_difference_m3": (
                centers_volumes["dt0003"]["water_volume_m3"]
                - centers_volumes["dt0001"]["water_volume_m3"]
            ),
            "note": (
                "Weights use native cell volumes in global OpenFOAM cell order. The "
                "address maps came from serial v2512 decomposePar using the source "
                "case's unchanged 8-rank 2x2x2 hierarchical decomposition."
            ),
        },
        "prepared_figure_arrays": {
            "path": str(output_fields),
            "sha256": sha256(output_fields),
            "bytes": output_fields.stat().st_size,
        },
        "release_gate": {
            "volume_relative_tolerance": VOLUME_GATE_RELATIVE,
            "all_cases_match_solver_ledger": all(
                row["passes_mapping_gate"] for row in closure.values()
            ),
            "ready_for_primary_review": all(row["passes_mapping_gate"] for row in closure.values()),
            "does_not_approve_continuation_launch": True,
        },
    }
    OUTPUT_SUMMARY.mkdir(parents=True, exist_ok=True)
    destination = OUTPUT_SUMMARY / "field-comparison.json"
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(
        json.dumps(
            {
                "map_cover_ok": map_receipt["global_cell_id_exact_cover"],
                "volume_closures": closure,
                "weighted_L1_m3": absolute_volume_difference,
                "centroid_shift_m": result["field_difference_dt0003_minus_dt0001"][
                    "centroid_shift_magnitude_m"
                ],
                "output": str(destination),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
