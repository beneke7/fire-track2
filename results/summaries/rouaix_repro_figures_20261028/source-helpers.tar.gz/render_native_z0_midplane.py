#!/usr/bin/env pvpython
"""Render Figure 03 from exact native z=0 faces and +z-side checkpoint values."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import mmap
import re
import resource
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
RUN = ROOT / "results/runs/rouaix-repro-figures-20261028"
SUMMARY = ROOT / "results/summaries/rouaix_repro_figures_20261028"
MESH = ROOT / "results/runs/rouaix-matched-mesh-mac-20261025/final-cast-only-transfer-core/constant/polyMesh"
ALPHA_NPZ = RUN / "staging/global-alpha-t0215.npz"
ALPHA_RECEIPT = RUN / "staging/global-alpha-t0215.json"
GEOMETRY_NPZ = ROOT / "results/runs/rouaix-fine-water-view-20261028/staging/native-cell-centres-volumes.npz"
OUTPUT = RUN / "staging/figure03-native-z0-face-candidate.png"
RECEIPT = RUN / "staging/figure03-native-z0-face-candidate.json"
EXPECTED_CELLS = 10_099_265
THRESHOLD = 0.01
TIME_S = 0.215
EXPECTED_MESH_SHA256 = {
    "boundary": "574392c950271c8c4c1d389bd4ca0e1424bb54a309030f57743405766d32e779",
    "faces": "189d7c0e976e7d59d00b1397209d79feec3499098b304c9c5d9c327f3462d160",
    "neighbour": "4ed021ba510f6800b7c90e90e80783cccbb1e1e5b5c9ec2a565e9e4031d661fc",
    "owner": "05a61c7b0780d1aee5d8258612b69b10263097d2f60a7dbaeb3b1ae8135d47bb",
    "points": "60fe45a13019eb5904ac21ca5ddd6c97ac581025a6d62dee91b5e8c01155298d",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def binary_list_header(path: Path) -> tuple[int, int]:
    with path.open("rb") as stream:
        header = stream.read(8192)
    header_end = header.find(b"\n}\n")
    if header_end < 0:
        raise ValueError(f"OpenFOAM header not found: {path}")
    match = re.search(rb"(?m)^(\d+)\n\(", header[header_end + 3 :])
    if match is None:
        raise ValueError(f"binary list header not found: {path}")
    return int(match.group(1)), header_end + 3 + match.end()


def figure_renderer():
    path = RUN / "render_repro_figures.py"
    spec = importlib.util.spec_from_file_location("rouaix_repro_figure_renderer", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not import figure renderer {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def extract_native_face_section(alpha: np.ndarray, centres: np.ndarray) -> tuple[list[np.ndarray], np.ndarray, dict[str, Any]]:
    points_path, faces_path = MESH / "points", MESH / "faces"
    owner_path, neighbour_path = MESH / "owner", MESH / "neighbour"
    n_points, points_start = binary_list_header(points_path)
    n_offsets, offsets_start = binary_list_header(faces_path)
    n_owner, owner_start = binary_list_header(owner_path)
    n_internal, neighbour_start = binary_list_header(neighbour_path)
    if n_owner != n_offsets - 1 or n_internal >= n_owner:
        raise ValueError("native face, owner and neighbour counts disagree")
    if alpha.shape != (EXPECTED_CELLS,) or centres.shape != (EXPECTED_CELLS, 3):
        raise ValueError("mapped alpha and native cell centres do not match mesh cell count")

    with points_path.open("rb") as point_stream, faces_path.open("rb") as face_stream, owner_path.open("rb") as owner_stream, neighbour_path.open("rb") as neighbour_stream:
        point_map = mmap.mmap(point_stream.fileno(), 0, access=mmap.ACCESS_READ)
        face_map = mmap.mmap(face_stream.fileno(), 0, access=mmap.ACCESS_READ)
        owner_map = mmap.mmap(owner_stream.fileno(), 0, access=mmap.ACCESS_READ)
        neighbour_map = mmap.mmap(neighbour_stream.fileno(), 0, access=mmap.ACCESS_READ)
        try:
            points = np.ndarray((n_points, 3), dtype="<f8", buffer=point_map, offset=points_start)
            offsets = np.ndarray((n_offsets,), dtype="<i4", buffer=face_map, offset=offsets_start)
            after_offsets = offsets_start + n_offsets * 4
            if face_map[after_offsets : after_offsets + 2] != b")\n":
                raise ValueError("native face-offset list has an unexpected terminator")
            labels_header = re.match(rb"(\d+)\n\(", face_map[after_offsets + 2 : after_offsets + 64])
            if labels_header is None:
                raise ValueError("native face-connectivity header is missing")
            n_labels = int(labels_header.group(1))
            labels_start = after_offsets + 2 + labels_header.end()
            labels = np.ndarray((n_labels,), dtype="<i4", buffer=face_map, offset=labels_start)
            owner = np.ndarray((n_owner,), dtype="<i4", buffer=owner_map, offset=owner_start)
            neighbour = np.ndarray((n_internal,), dtype="<i4", buffer=neighbour_map, offset=neighbour_start)
            if int(offsets[-1]) != n_labels:
                raise ValueError("native face offsets/connectivity disagree")

            on_z0 = np.abs(points[:, 2]) <= 1e-12
            coplanar_face = np.logical_and.reduceat(on_z0[labels], offsets[:-1])
            face_ids = np.flatnonzero(coplanar_face[:n_internal]).astype(np.int64)
            if not len(face_ids):
                raise RuntimeError("no exact native internal faces lie at z=0")

            polygons: list[np.ndarray] = []
            field_values: list[float] = []
            selected_cells: list[int] = []
            face_keys: set[tuple[int, ...]] = set()
            section_area = 0.0
            selected_area = 0.0
            alpha_by_side = {"owner": 0, "neighbour": 0}
            alpha_values: list[float] = []
            selected_alpha: list[float] = []
            side_min_abs_dz = float("inf")
            side_ties = 0
            for face_id in face_ids:
                point_ids = labels[int(offsets[face_id]) : int(offsets[face_id + 1])].astype(np.int64, copy=False)
                key = tuple(sorted(int(value) for value in point_ids))
                if key in face_keys:
                    raise RuntimeError("duplicate native face connectivity on z=0 plane")
                face_keys.add(key)
                xyz = points[point_ids]
                xy = xyz[:, :2].copy()
                signed_area = 0.5 * float(
                    np.dot(xy[:, 0], np.roll(xy[:, 1], -1))
                    - np.dot(xy[:, 1], np.roll(xy[:, 0], -1))
                )
                area = abs(signed_area)
                section_area += area

                owner_id = int(owner[face_id])
                neighbour_id = int(neighbour[face_id])
                owner_z = float(centres[owner_id, 2])
                neighbour_z = float(centres[neighbour_id, 2])
                dz = owner_z - neighbour_z
                side_min_abs_dz = min(side_min_abs_dz, abs(dz))
                if abs(dz) <= 1e-12:
                    side_ties += 1
                if dz >= 0.0:
                    plus_cell = owner_id
                    alpha_by_side["owner"] += 1
                else:
                    plus_cell = neighbour_id
                    alpha_by_side["neighbour"] += 1
                value = float(alpha[plus_cell])
                alpha_values.append(value)
                if value >= THRESHOLD:
                    polygons.append(xy)
                    field_values.append(value)
                    selected_cells.append(plus_cell)
                    selected_area += area
                    selected_alpha.append(value)
            if not polygons:
                raise RuntimeError("no +z-side native cells meet the alpha threshold")
            if len(face_keys) != len(face_ids):
                raise RuntimeError("native exact-plane face identifiers are not unique")
            if abs(section_area - 200.0) > 2e-8:
                raise RuntimeError(f"native z=0 section area {section_area} does not cover the 200 m² section")

            receipt = {
                "plane_origin_m": [0.0, 0.0, 0.0],
                "plane_normal": [0.0, 0.0, 1.0],
                "geometry_method": "raw binary native internal faces whose every vertex has abs(z)<=1e-12 m; no cutter/intersection reconstruction",
                "native_internal_faces_on_plane": int(len(face_ids)),
                "native_face_vertex_label_keys_unique": len(face_keys) == len(face_ids),
                "all_face_projected_area_sum_m2": float(section_area),
                "expected_complete_section_area_m2": 200.0,
                "section_area_relative_residual": float((section_area - 200.0) / 200.0),
                "adjacent_cell_selection": "for each exact z=0 internal face, choose owner or neighbour with the greater cached native-cell-centre z coordinate; alpha is taken directly from that cell's mapped global value",
                "selected_side_by_face_count": alpha_by_side,
                "smallest_abs_owner_neighbour_centre_dz_m": float(side_min_abs_dz),
                "centre_side_ties_within_1e_12m": int(side_ties),
                "threshold_alpha_water": THRESHOLD,
                "threshold_semantics": "+z-adjacent native cell has alpha.water >= 0.01",
                "selected_native_face_count": int(len(polygons)),
                "selected_distinct_adjacent_native_cell_count": int(len(set(selected_cells))),
                "selected_face_area_sum_m2": float(selected_area),
                "alpha_min_all_plus_z_cells": float(min(alpha_values)),
                "alpha_max_all_plus_z_cells": float(max(alpha_values)),
                "alpha_min_selected": float(min(selected_alpha)),
                "alpha_max_selected": float(max(selected_alpha)),
                "coordinate_frame": {"x": "crossflow", "y": "upward", "z": "lateral"},
                "cell_value_to_face_value": "piecewise constant from the +z-adjacent cell; no interpolation",
            }
            return polygons, np.asarray(field_values, dtype=np.float64), receipt
        finally:
            del labels, offsets, points, owner, neighbour
            neighbour_map.close()
            owner_map.close()
            face_map.close()
            point_map.close()


def main() -> None:
    started = time.monotonic()
    if OUTPUT.exists() or RECEIPT.exists():
        raise FileExistsError("refusing to overwrite candidate native z=0 face figure")
    source_hashes = {name: sha256(MESH / name) for name in EXPECTED_MESH_SHA256}
    if source_hashes != EXPECTED_MESH_SHA256:
        raise RuntimeError("local native mesh does not match the qualified mesh receipt")
    alpha_receipt = json.loads(ALPHA_RECEIPT.read_text(encoding="utf-8"))
    if alpha_receipt["time_s"] != TIME_S or not alpha_receipt["mapping"]["exact_global_cell_cover"]:
        raise RuntimeError("mapped alpha source time or global cell cover is not qualified")
    if alpha_receipt["mapping"]["alpha_values_clipped"]:
        raise RuntimeError("mapped alpha contains a clipping operation")
    with np.load(ALPHA_NPZ) as mapped:
        alpha = mapped["alpha_water_global"].astype(np.float64, copy=True)
    with np.load(GEOMETRY_NPZ) as geometry:
        centres = geometry["centres_m"].astype(np.float64, copy=True)
    polygons, alpha_face, section = extract_native_face_section(alpha, centres)

    renderer = figure_renderer()
    section["panel_title"] = "Central z=0 m section • native faces colored by +z-side cell α.water"
    section["crop_note"] = (
        "x=[−0.45, 12.8] m, y=[−3.0, 0.28] m • filled polygons are existing internal faces; "
        "+z-adjacent cell α.water ≥ 0.01 (piecewise constant)."
    )
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    figure_receipt = renderer.render_slice(polygons, alpha_face, OUTPUT, section)
    receipt = {
        "schema_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "replace the former exact-plane vtkCutter panel with source-native z=0 internal faces",
        "source_checkpoint": {
            "time_s": TIME_S,
            "mapped_alpha_npz": str(ALPHA_NPZ),
            "mapped_alpha_npz_sha256": sha256(ALPHA_NPZ),
            "mapping_receipt": str(ALPHA_RECEIPT),
            "mapping_receipt_sha256": sha256(ALPHA_RECEIPT),
            "alpha_raw_min": float(alpha.min()),
            "alpha_raw_max": float(alpha.max()),
            "alpha_values_clipped": False,
        },
        "native_mesh": {
            "path": str(MESH),
            "hashes": source_hashes,
            "cell_geometry_cache": str(GEOMETRY_NPZ),
            "cell_geometry_cache_sha256": sha256(GEOMETRY_NPZ),
            "cell_count": EXPECTED_CELLS,
        },
        "cross_section": section,
        "candidate_figure": figure_receipt,
        "rendering": {
            "matplotlib_backend": "Agg",
            "paraview_render_called": False,
            "opengl_or_gpu_used": False,
            "peak_rss_gib": float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (1024**3)),
            "elapsed_s": round(time.monotonic() - started, 2),
        },
    }
    RECEIPT.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == "__main__":
    main()
