#!/usr/bin/env pvpython
"""Render polished CPU figures from the closed Rouaix t=0.215 VOF checkpoint."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import resource
import sys
from datetime import datetime, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.cm import ScalarMappable
from matplotlib.collections import PolyCollection
from matplotlib.colors import LinearSegmentedColormap, LogNorm
from vtk import (
    vtkCellDataToPointData,
    vtkContourFilter,
    vtkCutter,
    vtkDataObject,
    vtkPlane,
    vtkPolyData,
    vtkPolyDataNormals,
    vtkThreshold,
    vtkUnstructuredGrid,
    vtkXMLPolyDataWriter,
)
from vtk.util.numpy_support import numpy_to_vtk, vtk_to_numpy

REPO = Path(__file__).resolve().parents[3]
RUN = REPO / "results/runs/rouaix-repro-figures-20261028"
SUMMARY = REPO / "results/summaries/rouaix_repro_figures_20261028"
FINE_RUN = REPO / "results/runs/rouaix-fine-water-view-20261028"
FINE_SUMMARY = REPO / "results/summaries/rouaix_fine_water_view_20261028"
SOURCE_ALPHA = RUN / "staging/pcg-alpha.water-t0215"
MAP_NPZ = RUN / "staging/global-alpha-t0215.npz"
MAP_JSON = RUN / "staging/global-alpha-t0215.json"
GEOMETRY_NPZ = FINE_RUN / "staging/native-cell-centres-volumes.npz"
GEOMETRY_JSON = FINE_RUN / "staging/native-cell-centres-volumes.json"
MESH_CASE = REPO / "results/runs/rouaix-matched-mesh-mac-20261025/final-cast-only-transfer-core"
EXPECTED_CELLS = 10_099_265
TIME_S = 0.215
THRESHOLD = 0.01
CELL_MAP_HASH = "8859c12cc8f538850a5d32f6bb350c29ed6c8bbfa70639736677a649865507a6"
REMOTE_FIELD_SHA = "687a5e7f395825c85ffdc6fc6a919fbd99c0b7b8f7fee7ec526e70dc9f53c56a"
REMOTE_LOG_VOLUME_M3 = 0.269713860359
FIGURE_TITLE = "COMPUTED WATER FIELD  |  SAVED CHECKPOINT t = 0.2150 s"
FIGURE_SUBTITLE = (
    "PCG-DIC continuation job 14705632  •  10,099,265 native cells  •  "
    "world frame x crossflow / y upward / z lateral  •  exploratory"
)
FIGURE_FOOTER = (
    "Saved intermediate checkpoint, not a terminal or validated result. Native-cell views preserve grid facets; "
    "the labeled contour uses cell-to-point interpolation only for visualization."
)
CMAP = LinearSegmentedColormap.from_list(
    "rouaix_night_cyan",
    ["#16446b", "#087c9c", "#18b7c2", "#62e2dc", "#edffff"],
    N=256,
)
NORM = LogNorm(vmin=THRESHOLD, vmax=1.0)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_helper():
    path = FINE_RUN / "render_fine_water_view.py"
    spec = importlib.util.spec_from_file_location("rouaix_fine_water_view_helper", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load existing fine-view helper: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def unit(vector: np.ndarray) -> np.ndarray:
    magnitude = float(np.linalg.norm(vector))
    if magnitude <= 0:
        raise ValueError("camera basis vector has zero length")
    return vector / magnitude


def header(fig, panel_title: str, crop_note: str) -> None:
    fig.text(0.055, 0.965, FIGURE_TITLE, color="#f4fbff", fontsize=19, weight="bold")
    fig.text(0.055, 0.930, FIGURE_SUBTITLE, color="#9cc8d3", fontsize=10.5)
    fig.text(
        0.055,
        0.885,
        panel_title,
        color="#63e6e4",
        fontsize=13,
        weight="bold",
    )
    fig.text(0.055, 0.855, crop_note, color="#b5d2d8", fontsize=9.5)
    fig.text(0.055, 0.025, FIGURE_FOOTER, color="#8daeb8", fontsize=8.5)


def vtp_polygons(
    polydata, *, prefer_point_alpha: bool = False
) -> tuple[list[np.ndarray], np.ndarray, np.ndarray, np.ndarray]:
    points = vtk_to_numpy(polydata.GetPoints().GetData()).astype(np.float64, copy=False)
    polygons = polydata.GetPolys()
    offsets = vtk_to_numpy(polygons.GetOffsetsArray())
    connectivity = vtk_to_numpy(polygons.GetConnectivityArray())
    alpha_array = polydata.GetCellData().GetArray("alpha.water")
    point_alpha_array = polydata.GetPointData().GetArray("alpha.water")
    if alpha_array is None and point_alpha_array is None:
        raise RuntimeError("threshold surface lacks its native alpha.water cell values")
    cell_alpha = (
        vtk_to_numpy(alpha_array).astype(np.float64, copy=False)
        if alpha_array is not None
        else None
    )
    point_alpha = (
        vtk_to_numpy(point_alpha_array).astype(np.float64, copy=False)
        if point_alpha_array is not None
        else None
    )
    if cell_alpha is not None and len(cell_alpha) != len(offsets) - 1:
        raise RuntimeError("surface polygon and alpha.water counts differ")
    use_point_alpha = point_alpha is not None and (prefer_point_alpha or cell_alpha is None)
    if not use_point_alpha and cell_alpha is None:
        raise RuntimeError("surface polygon lacks cell alpha.water and no point alpha is available")
    point_normals_array = polydata.GetPointData().GetNormals()
    point_normals = (
        vtk_to_numpy(point_normals_array).astype(np.float64, copy=False)
        if point_normals_array is not None
        else None
    )
    face_count = len(offsets) - 1
    faces = []
    alpha = np.empty(face_count, dtype=np.float64)
    centroids = np.empty((face_count, 3), dtype=np.float64)
    normals = np.empty((face_count, 3), dtype=np.float64)
    for index, (start, stop) in enumerate(zip(offsets[:-1], offsets[1:], strict=True)):
        point_ids = connectivity[start:stop]
        face = points[point_ids]
        faces.append(face)
        alpha[index] = (
            float(point_alpha[point_ids].mean()) if use_point_alpha else cell_alpha[index]
        )
        centroids[index] = face.mean(axis=0)
        if point_normals is not None:
            interpolated_normal = point_normals[point_ids].mean(axis=0)
            normal_magnitude = float(np.linalg.norm(interpolated_normal))
            if normal_magnitude > 0:
                normals[index] = interpolated_normal / normal_magnitude
                continue
        # Newell's normal, computed from the actual native exterior polygon.
        following = np.roll(face, -1, axis=0)
        normal = np.array(
            [
                np.sum((face[:, 1] - following[:, 1]) * (face[:, 2] + following[:, 2])),
                np.sum((face[:, 2] - following[:, 2]) * (face[:, 0] + following[:, 0])),
                np.sum((face[:, 0] - following[:, 0]) * (face[:, 1] + following[:, 1])),
            ],
            dtype=np.float64,
        )
        norm = float(np.linalg.norm(normal))
        normals[index] = normal / norm if norm > 0 else 0.0
    return faces, alpha, centroids, normals


def project_box(
    bounds: tuple[tuple[float, float], ...], focus: np.ndarray, right: np.ndarray, up: np.ndarray
):
    corners = np.array(
        [[x, y, z] for x in bounds[0] for y in bounds[1] for z in bounds[2]],
        dtype=np.float64,
    )
    delta = corners - focus
    return delta @ right, delta @ up


def render_oblique(
    polydata,
    destination: Path,
    *,
    title: str,
    crop_note: str,
    bounds: tuple[tuple[float, float], ...],
    focus: tuple[float, float, float],
    show_facets: bool,
    show_nozzle: bool,
    fixed_material: bool = False,
    prefer_point_alpha: bool = False,
) -> dict:
    faces, alpha, centroids, normals = vtp_polygons(polydata, prefer_point_alpha=prefer_point_alpha)
    focus_vector = np.asarray(focus, dtype=np.float64)
    camera = unit(np.array([0.29, 0.25, 1.0], dtype=np.float64))
    right = unit(np.cross(np.array([0.0, 1.0, 0.0]), camera))
    up = unit(np.cross(camera, right))
    screen_x, screen_y = project_box(bounds, focus_vector, right, up)
    padding_x = (float(screen_x.max()) - float(screen_x.min())) * 0.035
    padding_y = (float(screen_y.max()) - float(screen_y.min())) * 0.035

    light = unit(camera + 0.42 * up - 0.18 * right)
    diffuse = np.clip(np.abs(normals @ light), 0.0, 1.0)
    if fixed_material:
        material = np.array([0.24, 0.84, 0.91, 1.0])
        face_colors = np.repeat(material[None, :], len(alpha), axis=0)
        face_colors[:, :3] *= (0.24 + 0.76 * np.sqrt(diffuse))[:, None]
    else:
        face_colors = CMAP(NORM(alpha))
        # Mild directional variation adds depth while hue still represents
        # alpha.water. This changes lighting only, never the field or geometry.
        illumination = 0.72 + 0.28 * diffuse
        face_colors[:, :3] *= illumination[:, None]

    depth = centroids @ camera
    order = np.argsort(depth, kind="stable")
    screen_polygons = [
        np.column_stack(((face - focus_vector) @ right, (face - focus_vector) @ up))
        for face in faces
    ]

    fig = plt.figure(figsize=(15.5, 10.2), facecolor="#071521")
    header(fig, title, crop_note)
    ax = fig.add_axes([0.055, 0.105, 0.79, 0.69], facecolor="#071521")
    collection = PolyCollection(
        [screen_polygons[index] for index in order],
        facecolors=face_colors[order],
        edgecolors="#0b3546" if show_facets else "none",
        linewidths=0.12 if show_facets else 0.0,
        antialiaseds=True,
        zorder=2,
    )
    collection.set_rasterized(True)
    ax.add_collection(collection)
    ax.set_xlim(float(screen_x.min()) - padding_x, float(screen_x.max()) + padding_x)
    ax.set_ylim(float(screen_y.min()) - padding_y, float(screen_y.max()) + padding_y)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("orthographic projected distance (m)", color="#c4dce2", labelpad=10)
    ax.set_ylabel("orthographic projected distance (m)", color="#c4dce2", labelpad=10)
    ax.tick_params(colors="#9cc0c9", labelsize=9)
    for spine in ax.spines.values():
        spine.set_color("#34515e")
    ax.grid(color="#25414f", linewidth=0.5, alpha=0.42)

    if show_nozzle:
        nozzle_xy = np.array([-focus_vector @ right, -focus_vector @ up])
        ax.scatter(
            [nozzle_xy[0]],
            [nozzle_xy[1]],
            s=54,
            marker="+",
            linewidths=1.8,
            color="#ffd98b",
            zorder=5,
        )
        ax.annotate(
            "nozzle origin",
            nozzle_xy,
            xytext=(7, 9),
            textcoords="offset points",
            color="#ffe9bd",
            fontsize=8.5,
            zorder=6,
        )

    # One projected metre is a true one-metre world displacement along +x.
    bar_origin = np.array([ax.get_xlim()[0] + 0.18, ax.get_ylim()[0] + 0.20])
    projected_x_length = float(np.dot(np.array([1.0, 0.0, 0.0]), right))
    ax.plot(
        [bar_origin[0], bar_origin[0] + projected_x_length],
        [bar_origin[1], bar_origin[1]],
        color="#fff1cc",
        linewidth=2.2,
        solid_capstyle="round",
        zorder=7,
    )
    ax.text(
        bar_origin[0] + projected_x_length / 2,
        bar_origin[1] + 0.10,
        "1 m along +x",
        color="#fff1cc",
        ha="center",
        fontsize=8.5,
        zorder=7,
    )

    if fixed_material:
        fig.text(
            0.88,
            0.61,
            "INTERPOLATED\nα.water = 0.01\n\nSurface color shows\nnormal-based lighting",
            color="#bceef0",
            fontsize=10,
            linespacing=1.5,
            ha="left",
            va="center",
            bbox={"boxstyle": "round,pad=0.7", "facecolor": "#102b39", "edgecolor": "#3b7380"},
        )
    else:
        scalar = ScalarMappable(norm=NORM, cmap=CMAP)
        scalar.set_array(alpha)
        cax = fig.add_axes([0.885, 0.22, 0.022, 0.45])
        colorbar = fig.colorbar(scalar, cax=cax, ticks=[0.01, 0.03, 0.1, 0.3, 1.0])
        colorbar.set_label("native cell α.water  (log scale)", color="#c4dce2", labelpad=12)
        colorbar.ax.tick_params(colors="#a9cbd3", labelsize=8)
        colorbar.outline.set_edgecolor("#45616c")
    fig.savefig(destination, dpi=220, facecolor=fig.get_facecolor())
    plt.close(fig)
    return {
        "path": str(destination),
        "sha256": sha256(destination),
        "bytes": destination.stat().st_size,
        "surface_polygons": len(alpha),
        "alpha_min": float(alpha.min()),
        "alpha_max": float(alpha.max()),
        "world_crop_bounds_m": {axis: list(pair) for axis, pair in zip("xyz", bounds, strict=True)},
        "camera_projection": "orthographic; 3D vertices projected to an orthonormal screen basis",
        "facets_visible": show_facets,
        "nozzle_origin_marker": show_nozzle,
        "fixed_surface_material_with_normal_lighting": fixed_material,
        "gpu_or_opengl_used": False,
    }


def make_surface(grid: vtkUnstructuredGrid, threshold: float, destination: Path, helper):
    polydata, receipt = helper.make_threshold_surface(grid, threshold, destination)
    if polydata.GetCellData().GetArray("alpha.water") is None:
        raise RuntimeError(f"{destination} did not retain native alpha.water values")
    return polydata, receipt


def make_interpolated_contour(
    grid: vtkUnstructuredGrid, destination: Path
) -> tuple[vtkPolyData, dict]:
    cell_to_point = vtkCellDataToPointData()
    cell_to_point.SetInputData(grid)
    cell_to_point.ProcessAllArraysOn()
    cell_to_point.PassCellDataOn()
    cell_to_point.Update()
    point_alpha = cell_to_point.GetOutput().GetPointData().GetArray("alpha.water")
    if point_alpha is None:
        raise RuntimeError("cell-to-point filter did not produce alpha.water")
    point_values = vtk_to_numpy(point_alpha)
    point_min = float(point_values.min())
    point_max = float(point_values.max())
    if point_min < -1e-12 or point_max > 1.0 + 1e-12:
        raise RuntimeError("cell-to-point interpolation produced values outside [0, 1]")

    contour = vtkContourFilter()
    contour.SetInputConnection(cell_to_point.GetOutputPort())
    contour.SetValue(0, THRESHOLD)
    contour.ComputeNormalsOff()
    contour.Update()
    contour_output = vtkPolyData.SafeDownCast(contour.GetOutput())
    if contour_output is None or contour_output.GetNumberOfPolys() == 0:
        raise RuntimeError("cell-to-point contour did not produce a polygonal isosurface")

    normals = vtkPolyDataNormals()
    normals.SetInputData(contour_output)
    normals.ConsistencyOn()
    normals.AutoOrientNormalsOn()
    normals.SplittingOff()
    normals.ComputePointNormalsOn()
    normals.ComputeCellNormalsOff()
    normals.Update()
    output = vtkPolyData.SafeDownCast(normals.GetOutput())
    if output is None or output.GetNumberOfPolys() == 0:
        raise RuntimeError("normal generation changed the contour into an empty surface")
    if output.GetPointData().GetArray("alpha.water") is None:
        raise RuntimeError("contour output did not retain interpolated point alpha.water")
    if output.GetPointData().GetNormals() is None:
        raise RuntimeError("contour output has no lighting normals")

    destination.parent.mkdir(parents=True, exist_ok=True)
    writer = vtkXMLPolyDataWriter()
    writer.SetFileName(str(destination))
    writer.SetInputData(output)
    writer.SetDataModeToBinary()
    writer.SetCompressorTypeToZLib()
    if writer.Write() != 1:
        raise RuntimeError(f"could not save interpolated contour {destination}")
    return output, {
        "path": str(destination),
        "sha256": sha256(destination),
        "bytes": destination.stat().st_size,
        "source": "mapped full-grid alpha.water cell data on exact native volume mesh",
        "interpolation": "vtkCellDataToPointData cell-to-point averaging; no clipping",
        "contour_filter": "vtkContourFilter at alpha.water = 0.01",
        "point_alpha_min_before_contour": point_min,
        "point_alpha_max_before_contour": point_max,
        "iso_surface_points": int(output.GetNumberOfPoints()),
        "iso_surface_polygons": int(output.GetNumberOfPolys()),
        "point_alpha_preserved": True,
        "normal_calculation": "vtkPolyDataNormals point normals; geometry points unchanged",
        "geometry_smoothing_or_decimation": False,
    }


def extract_midplane(grid: vtkUnstructuredGrid):
    selected = vtkThreshold()
    selected.SetInputData(grid)
    selected.SetInputArrayToProcess(0, 0, 0, vtkDataObject.FIELD_ASSOCIATION_CELLS, "alpha.water")
    selected.SetUpperThreshold(THRESHOLD)
    selected.SetThresholdFunction(vtkThreshold.THRESHOLD_UPPER)
    selected.Update()
    selected_cells = int(selected.GetOutput().GetNumberOfCells())

    plane = vtkPlane()
    plane.SetOrigin(0.0, 0.0, 0.0)
    plane.SetNormal(0.0, 0.0, 1.0)
    cutter = vtkCutter()
    cutter.SetInputConnection(selected.GetOutputPort())
    cutter.SetCutFunction(plane)
    cutter.GenerateTrianglesOff()
    cutter.Update()
    output = cutter.GetOutput()
    alpha_array = output.GetCellData().GetArray("alpha.water")
    if alpha_array is None:
        raise RuntimeError("z=0 cutter did not preserve cell-associated alpha.water")
    cut_alpha = vtk_to_numpy(alpha_array).astype(np.float64, copy=False)
    if len(cut_alpha) != output.GetNumberOfCells():
        raise RuntimeError("z=0 cut polygons and alpha.water cell values differ")
    polygons = output.GetPolys()
    offsets = vtk_to_numpy(polygons.GetOffsetsArray())
    connectivity = vtk_to_numpy(polygons.GetConnectivityArray())
    points = vtk_to_numpy(output.GetPoints().GetData()).astype(np.float64, copy=False)
    if len(offsets) - 1 != len(cut_alpha):
        raise RuntimeError("z=0 cutter returned non-polygon cells; refusing to fake a filled slice")
    polys_xy = []
    for start, stop in zip(offsets[:-1], offsets[1:], strict=True):
        polys_xy.append(points[connectivity[start:stop], :2].copy())
    if not polys_xy:
        raise RuntimeError("z=0 native-cell slice is empty")
    if np.any(cut_alpha < THRESHOLD - 1e-12) or np.any(cut_alpha > 1.0 + 1e-12):
        raise RuntimeError("z=0 slice contains unexpected alpha.water values")
    return (
        polys_xy,
        cut_alpha,
        {
            "plane_origin_m": [0.0, 0.0, 0.0],
            "plane_normal": [0.0, 0.0, 1.0],
            "threshold": THRESHOLD,
            "threshold_semantics": "native volume cells with alpha.water >= 0.01",
            "selected_native_cells": selected_cells,
            "cut_polygons": len(polys_xy),
            "alpha_min": float(cut_alpha.min()),
            "alpha_max": float(cut_alpha.max()),
            "geometry_method": "vtkCutter on thresholded native volume cells; cell alpha values retained",
        },
    )


def render_slice(
    polygons: list[np.ndarray], alpha: np.ndarray, destination: Path, slice_receipt: dict
):
    fig = plt.figure(figsize=(16.2, 7.6), facecolor="#071521")
    header(
        fig,
        "Full-span central cut • exact native-cell intersections at z = 0 m",
        "x=[−0.45, 12.8] m, y=[−3.0, 0.28] m • α.water ≥ 0.01 • cell color uses the native field value.",
    )
    ax = fig.add_axes([0.075, 0.18, 0.82, 0.60], facecolor="#071521")
    collection = PolyCollection(
        polygons,
        array=alpha,
        cmap=CMAP,
        norm=NORM,
        edgecolors="#113a4a",
        linewidths=0.14,
        antialiaseds=True,
    )
    collection.set_rasterized(True)
    ax.add_collection(collection)
    ax.set_xlim(-0.45, 12.8)
    ax.set_ylim(-3.0, 0.28)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("x crossflow (m)", color="#c4dce2", labelpad=8)
    ax.set_ylabel("y upward (m)", color="#c4dce2", labelpad=8)
    ax.tick_params(colors="#9cc0c9", labelsize=8)
    ax.grid(color="#25414f", linewidth=0.5, alpha=0.45)
    for spine in ax.spines.values():
        spine.set_color("#34515e")
    ax.scatter([0], [0], marker="+", s=46, linewidths=1.6, color="#ffd98b", zorder=5)
    ax.annotate(
        "nozzle (0, 0)",
        (0, 0),
        xytext=(8, 8),
        textcoords="offset points",
        color="#ffe9bd",
        fontsize=8,
    )
    cax = fig.add_axes([0.925, 0.26, 0.022, 0.42])
    scalar = ScalarMappable(norm=NORM, cmap=CMAP)
    scalar.set_array(alpha)
    colorbar = fig.colorbar(scalar, cax=cax, ticks=[0.01, 0.03, 0.1, 0.3, 1.0])
    colorbar.set_label("native cell α.water  (log scale)", color="#c4dce2", labelpad=12)
    colorbar.ax.tick_params(colors="#a9cbd3", labelsize=8)
    colorbar.outline.set_edgecolor("#45616c")
    fig.savefig(destination, dpi=220, facecolor=fig.get_facecolor())
    plt.close(fig)
    return {
        "path": str(destination),
        "sha256": sha256(destination),
        "bytes": destination.stat().st_size,
        **slice_receipt,
        "gpu_or_opengl_used": False,
    }


def main() -> None:
    if not SOURCE_ALPHA.is_file() or sha256(SOURCE_ALPHA) != REMOTE_FIELD_SHA:
        raise RuntimeError("copied checkpoint alpha.water hash does not match remote readback")
    mapping = json.loads(MAP_JSON.read_text(encoding="utf-8"))
    if mapping["source_alpha_field"]["sha256"] != REMOTE_FIELD_SHA:
        raise RuntimeError("mapped field receipt does not identify the copied checkpoint")
    if not mapping["mapping"]["exact_global_cell_cover"]:
        raise RuntimeError("rank-local cell map is not an exact global cover")
    if mapping["mapping"]["alpha_values_clipped"]:
        raise RuntimeError("mapping receipt reports clipped alpha values")

    with np.load(MAP_NPZ) as mapped:
        alpha = mapped["alpha_water_global"].astype(np.float64, copy=False)
    with np.load(GEOMETRY_NPZ) as geometry:
        centres = geometry["centres_m"]
        volumes = geometry["volumes_m3"]
    if (
        len(alpha) != EXPECTED_CELLS
        or len(centres) != EXPECTED_CELLS
        or len(volumes) != EXPECTED_CELLS
    ):
        raise RuntimeError("checkpoint field and native geometry cell counts do not agree")
    if float(alpha.min()) < 0.0 or float(alpha.max()) > 1.0:
        raise RuntimeError("raw alpha.water is outside [0, 1]; values are not modified here")
    water_volume = float(np.dot(alpha, volumes))
    difference = water_volume - REMOTE_LOG_VOLUME_M3
    relative_difference = difference / REMOTE_LOG_VOLUME_M3
    if abs(relative_difference) > 1e-6:
        raise RuntimeError(
            f"mapped water integral disagrees with solver log: {relative_difference:g}"
        )
    water_weights = alpha * volumes
    centroid = np.einsum("i,ij->j", water_weights, centres) / water_volume

    helper = load_helper()
    reader, grid, order_receipt = helper.read_native_grid(centres, volumes)
    if order_receipt["max_abs_centre_difference_m"] != 0.0:
        raise RuntimeError("native VTK reader cell centres differ from mapped global order")
    alpha_vtk = numpy_to_vtk(alpha, deep=True)
    alpha_vtk.SetName("alpha.water")
    grid.GetCellData().AddArray(alpha_vtk)
    grid.GetCellData().SetActiveScalars("alpha.water")

    surfaces_dir = SUMMARY / "surfaces-t0215"
    surfaces_dir.mkdir(parents=True, exist_ok=True)
    surface_001, receipt_001 = make_surface(
        grid, 0.01, surfaces_dir / "alpha-ge-0.01-t0.2150.vtp", helper
    )
    surface_01, receipt_01 = make_surface(
        grid, 0.1, surfaces_dir / "alpha-ge-0.1-t0.2150.vtp", helper
    )
    interpolated_surface, interpolated_receipt = make_interpolated_contour(
        grid, surfaces_dir / "alpha-interpolated-contour-0.01-t0.2150.vtp"
    )

    all_mask = alpha >= 0.01
    core_mask = alpha >= 0.1
    metric = {}
    for threshold, mask in ((0.01, all_mask), (0.1, core_mask)):
        weights = alpha[mask] * volumes[mask]
        metric[str(threshold)] = {
            "native_cell_count": int(mask.sum()),
            "alpha_weighted_water_volume_m3": float(weights.sum()),
            "cell_centre_bounds_m": {
                axis: [float(centres[mask, index].min()), float(centres[mask, index].max())]
                for index, axis in enumerate("xyz")
            },
        }
    tail_x = metric["0.01"]["cell_centre_bounds_m"]["x"][1]

    fig_dir = SUMMARY
    figure_1 = render_oblique(
        surface_001,
        fig_dir / "01-water-plume-oblique-t0215.png",
        title="Oblique orthographic view • native α ≥ 0.01 exterior surface",
        crop_note=(
            "Near-field crop x=[−0.4, 4.2] m, y=[−2.9, 0.35] m, z=[−1.3, 1.3] m; "
            f"full α≥0.01 cell-centre support reaches x={tail_x:.2f} m."
        ),
        bounds=((-0.4, 4.2), (-2.9, 0.35), (-1.3, 1.3)),
        focus=(1.8, -1.25, 0.0),
        show_facets=False,
        show_nozzle=True,
    )
    figure_2 = render_oblique(
        surface_001,
        fig_dir / "02-cell-facets-closeup-t0215.png",
        title="Cell-scale detail • native polygon facets preserved",
        crop_note=(
            "Close crop x=[0.6, 3.9] m, y=[−2.9, −1.15] m, z=[−1.25, 1.25] m; "
            "no smoothing, decimation, or reconstructed interface."
        ),
        bounds=((0.6, 3.9), (-2.9, -1.15), (-1.25, 1.25)),
        focus=(2.25, -2.03, 0.0),
        show_facets=True,
        show_nozzle=False,
    )
    slice_polygons, slice_alpha, slice_receipt = extract_midplane(grid)
    figure_3 = render_slice(
        slice_polygons,
        slice_alpha,
        fig_dir / "03-native-cell-cut-z0-t0215.png",
        slice_receipt,
    )
    figure_4 = render_oblique(
        interpolated_surface,
        fig_dir / "04-interpolated-isosurface-t0215.png",
        title="Interpolated α=.01 isosurface • cell-to-point contour",
        crop_note=(
            "Same oblique camera and crop x=[−0.4, 4.2], y=[−2.9, 0.35], z=[−1.3, 1.3] m as Figure 01; "
            "cell-to-point interpolation is visualization only."
        ),
        bounds=((-0.4, 4.2), (-2.9, 0.35), (-1.3, 1.3)),
        focus=(1.8, -1.25, 0.0),
        show_facets=False,
        show_nozzle=True,
        fixed_material=True,
        prefer_point_alpha=True,
    )

    output = {
        "schema_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "polished CPU-rendered views of one genuine computed Rouaix checkpoint",
        "state": {
            "field_time_s": TIME_S,
            "checkpoint_role": "saved intermediate checkpoint from an active PCG-DIC continuation",
            "job_id": 14705632,
            "run_case_id": "rouaix-restart-pressure-total-pcgdic-0255",
            "not_terminal_or_validated": True,
            "native_cells": EXPECTED_CELLS,
            "solver_log_water_volume_m3": REMOTE_LOG_VOLUME_M3,
            "mapped_field_water_volume_m3": water_volume,
            "water_volume_difference_m3": difference,
            "water_volume_relative_difference": relative_difference,
            "alpha_raw_min": float(alpha.min()),
            "alpha_raw_max": float(alpha.max()),
            "alpha_values_clipped": False,
            "water_centroid_m": [float(value) for value in centroid],
            "threshold_metrics": metric,
            "remote_checkpoint": {
                "path": "/project/nk_meshapplied/bene/fire-track2-hpc/rouaix-pressure-pcgdic-restart-20261028/rouaix-restart-pressure-total-pcgdic-14705632/attempt/case/processors120/0.215000000000/alpha.water",
                "bytes": 93_327_552,
                "sha256": REMOTE_FIELD_SHA,
                "remote_pre_post_stat_identical": True,
                "remote_pre_post_size_mtime_inode": [
                    93_327_552,
                    1_793_204_554,
                    144_123_862_232_147_258,
                ],
                "local_sha256_matches_remote": sha256(SOURCE_ALPHA) == REMOTE_FIELD_SHA,
                "exact_solver_log_volume_row": "volIntegrate(region0) of alpha.water = 0.269713860359 at Time = 0.215000000000",
                "run_manifest_sha256": "020cd8f8056a45594856d25542519f71af7588fd4d87b6a481ac29907ba4ad71",
                "case_inputs_sha256": "0a24f1eeb69c0ae84bef651437b6a91e870c317dca8045dedfcee54cfb12bb00",
                "native_source_evidence_sha256": "2e92d4f8374ca04471f3f4abe44b3cfdc5831d29db4e15921f88c7caabe7738e",
                "solver_binary_sha256": "1907a33483b27dcca0bf17b36e8b8165983a2bbf39f7bde660860b7fe27e3549",
                "solver": "interIsoFoam v2512; PCG/DIC p_rgh solver sensitivity",
            },
        },
        "mesh_and_mapping": {
            "native_mesh_manifest_sha256": "4347c663a52b3dda878f0b32d60b4ff485a767417b784e89145c6adc0298d670",
            "cellProcAddressing_sha256": CELL_MAP_HASH,
            "cell_map_exact_global_cover": True,
            "native_cell_order_check": order_receipt,
            "source_mesh_path": str(MESH_CASE),
            "coordinate_frame": {"x": "crossflow", "y": "upward", "z": "lateral"},
        },
        "surface_vtp": [receipt_001, receipt_01],
        "interpolated_contour_vtp": interpolated_receipt,
        "figures": [figure_1, figure_2, figure_3, figure_4],
        "rendering": {
            "method": "Matplotlib Agg orthographic polygon projection and exact native-cell cut plane",
            "paraview_render_called": False,
            "opengl_or_gpu_used": False,
            "source_thresholds": "native volume cells alpha.water >= 0.01 and >= 0.1",
            "color_scale": "logarithmic from native cell alpha.water 0.01 to 1",
            "surface_smoothing_or_decimation": False,
            "alternative_contour": "cell-to-point interpolation then vtkContourFilter at alpha.water=0.01; visualization only",
            "peak_rss_gib": float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (1024**3)),
        },
    }
    summary_path = SUMMARY / "figure-provenance.json"
    summary_path.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2), flush=True)
    del reader


if __name__ == "__main__":
    main()
